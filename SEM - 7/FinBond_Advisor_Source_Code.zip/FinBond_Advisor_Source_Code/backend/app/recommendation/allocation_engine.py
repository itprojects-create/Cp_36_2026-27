from datetime import datetime
from app.models import (
    FinancialGoal,
    GoalType,
    RiskAssessment,
    RiskCategory,
    UserProfile,
)
from app.recommendation.constants import SEGMENTS
from app.recommendation.derived_features import DerivedFeatures, calculate_derived_features
from app.recommendation.recommendation_builder import (
    build_recommendation_response,
    normalize_allocation,
)
from app.recommendation.types import AllocationInput

__all__ = ["AllocationInput", "compute_rule_based_allocation", "generate_recommendation", "BASE_ALLOCATION"]

BASE_ALLOCATION: dict[RiskCategory, dict[str, float]] = {
    RiskCategory.LOW: {
        "G-Sec/Debt": 50.0,
        "Large Cap": 25.0,
        "Mid Cap": 5.0,
        "Small Cap": 0.0,
        "Gold": 10.0,
        "ETF": 10.0,
    },
    RiskCategory.MODERATE: {
        "G-Sec/Debt": 30.0,
        "Large Cap": 30.0,
        "Mid Cap": 15.0,
        "Small Cap": 10.0,
        "Gold": 10.0,
        "ETF": 5.0,
    },
    RiskCategory.HIGH: {
        "G-Sec/Debt": 15.0,
        "Large Cap": 30.0,
        "Mid Cap": 20.0,
        "Small Cap": 20.0,
        "Gold": 10.0,
        "ETF": 5.0,
    },
}


def _horizon_bucket(years: int) -> str:
    if years < 3:
        return "short"
    if years <= 7:
        return "medium"
    return "long"


def _primary_goal(goals: list[FinancialGoal]) -> FinancialGoal:
    return sorted(goals, key=lambda g: (g.priority, g.target_year))[0]


def _apply_goal_adjustments(allocation: dict[str, float], goal: FinancialGoal) -> dict[str, float]:
    adjusted = allocation.copy()
    equity_segments = ["Large Cap", "Mid Cap", "Small Cap", "ETF"]
    debt_segment = "G-Sec/Debt"

    if goal.goal_type == GoalType.RETIREMENT:
        adjusted[debt_segment] += 5.0
        adjusted["Large Cap"] -= 3.0
        adjusted["Mid Cap"] -= 2.0
    elif goal.goal_type in (GoalType.CAR, GoalType.HOUSE):
        shift = 15.0
        for seg in equity_segments:
            share = adjusted[seg] / max(sum(adjusted[s] for s in equity_segments), 1)
            adjusted[seg] -= shift * share
        adjusted[debt_segment] += shift
    elif goal.goal_type == GoalType.WEALTH_CREATION:
        shift = 10.0
        adjusted[debt_segment] = max(0, adjusted[debt_segment] - shift)
        adjusted["Large Cap"] += 4.0
        adjusted["Mid Cap"] += 3.0
        adjusted["Small Cap"] += 3.0
    elif goal.goal_type == GoalType.EMERGENCY:
        shift = 20.0
        for seg in equity_segments + ["Gold"]:
            if adjusted[seg] >= shift / 4:
                adjusted[seg] -= shift / 4
        adjusted[debt_segment] += shift

    for seg in SEGMENTS:
        adjusted[seg] = max(0.0, adjusted[seg])
    return adjusted


def _apply_horizon_adjustments(allocation: dict[str, float], years: int) -> dict[str, float]:
    adjusted = allocation.copy()
    bucket = _horizon_bucket(years)

    if bucket == "short":
        adjusted["G-Sec/Debt"] += 10.0
        adjusted["Small Cap"] = max(0, adjusted["Small Cap"] - 5.0)
        adjusted["Mid Cap"] = max(0, adjusted["Mid Cap"] - 5.0)
    elif bucket == "long":
        adjusted["G-Sec/Debt"] = max(5.0, adjusted["G-Sec/Debt"] - 10.0)
        adjusted["Large Cap"] += 4.0
        adjusted["Mid Cap"] += 3.0
        adjusted["Small Cap"] += 3.0

    for seg in SEGMENTS:
        adjusted[seg] = max(0.0, adjusted[seg])
    return adjusted


def _apply_liquidity_adjustments(
    allocation: dict[str, float], emergency_fund_months: float, debt_burden_ratio: float
) -> dict[str, float]:
    adjusted = allocation.copy()

    if emergency_fund_months < 3:
        adjusted["G-Sec/Debt"] += 10.0
        adjusted["Large Cap"] = max(0, adjusted["Large Cap"] - 5.0)
        adjusted["Mid Cap"] = max(0, adjusted["Mid Cap"] - 5.0)
    elif emergency_fund_months >= 6:
        adjusted["Large Cap"] += 3.0
        adjusted["G-Sec/Debt"] = max(5.0, adjusted["G-Sec/Debt"] - 3.0)

    if debt_burden_ratio > 40:
        adjusted["G-Sec/Debt"] += 5.0
        adjusted["Small Cap"] = max(0, adjusted["Small Cap"] - 5.0)

    for seg in SEGMENTS:
        adjusted[seg] = max(0.0, adjusted[seg])
    return adjusted


def compute_rule_based_allocation(
    profile: UserProfile,
    goals: list[FinancialGoal],
    risk: RiskAssessment,
    features: DerivedFeatures,
) -> dict[str, float]:
    goal = _primary_goal(goals)
    horizon_years = max(1, goal.target_year - datetime.now().year)

    allocation = BASE_ALLOCATION[risk.risk_category].copy()
    allocation = _apply_goal_adjustments(allocation, goal)
    allocation = _apply_horizon_adjustments(allocation, horizon_years)
    allocation = _apply_liquidity_adjustments(
        allocation, features.emergency_fund_coverage, features.debt_burden_ratio
    )
    return normalize_allocation(allocation)


def generate_recommendation(data: AllocationInput) -> dict:
    profile = data.profile
    features = calculate_derived_features(
        monthly_income=profile.monthly_income or 0,
        monthly_expenses=profile.monthly_expenses or 0,
        savings=profile.savings or 0,
        existing_investments=profile.existing_investments or 0,
        emergency_fund_months=profile.emergency_fund_months or 0,
        emi=profile.emi or 0,
    )

    allocation = compute_rule_based_allocation(profile, data.goals, data.risk, features)
    return build_recommendation_response(allocation, data, features, engine="rule_based")
