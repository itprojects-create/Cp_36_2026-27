"""Shared recommendation pipeline — instrument ranking, explanation, response assembly."""

from datetime import datetime

from app.models import FinancialGoal, RiskAssessment, RiskCategory, UserProfile
from app.recommendation.types import AllocationInput
from app.recommendation.constants import DISCLAIMER, SEGMENTS, SEGMENT_TO_CATEGORY
from app.recommendation.derived_features import DerivedFeatures
from app.recommendation.instrument_ranker import rank_instruments


def normalize_allocation(allocation: dict[str, float]) -> dict[str, float]:
    total = sum(allocation.values())
    if total <= 0:
        return {k: 0.0 for k in SEGMENTS}
    return {k: round(v / total * 100, 2) for k, v in allocation.items()}


def _horizon_bucket(years: int) -> str:
    if years < 3:
        return "short"
    if years <= 7:
        return "medium"
    return "long"


def _primary_goal(goals: list[FinancialGoal]) -> FinancialGoal:
    return sorted(goals, key=lambda g: (g.priority, g.target_year))[0]


def _split_segment_across_instruments(
    segment_pct: float,
    segment_amount: float,
    ranked: list[tuple],
) -> list[dict]:
    if not ranked:
        return []

    scores = [score for _, score, _ in ranked]
    total_score = sum(scores)
    weights = [1.0 / len(ranked)] * len(ranked) if total_score <= 0 else [s / total_score for s in scores]

    instruments_out = []
    allocated_pct = 0.0
    allocated_amount = 0.0

    for i, (inst, _, reason) in enumerate(ranked):
        if i == len(ranked) - 1:
            inst_pct = round(segment_pct - allocated_pct, 2)
            inst_amount = round(segment_amount - allocated_amount, 2)
        else:
            inst_pct = round(segment_pct * weights[i], 2)
            inst_amount = round(segment_amount * weights[i], 2)
            allocated_pct += inst_pct
            allocated_amount += inst_amount

        instruments_out.append(
            {
                "name": inst.name,
                "cagr_3y": inst.cagr_3y,
                "expense_ratio": inst.expense_ratio,
                "allocation_pct": inst_pct,
                "amount": inst_amount,
                "reason": reason,
                "source": inst.source,
                "last_updated": inst.last_updated.isoformat() if inst.last_updated else None,
            }
        )

    return instruments_out


def build_explanation(
    profile: UserProfile,
    goal: FinancialGoal,
    risk: RiskAssessment,
    features: DerivedFeatures,
    horizon_years: int,
    engine_note: str | None = None,
) -> str:
    horizon_label = _horizon_bucket(horizon_years)
    base = (
        f"At age {profile.age}, your primary goal is {goal.goal_type.value.replace('_', ' ')} "
        f"targeted for {goal.target_year} ({horizon_years} years away, {horizon_label}-term horizon). "
        f"Your risk score is {risk.risk_score} ({risk.risk_category.value.title()}). "
        f"With {features.emergency_fund_coverage:.1f} months of emergency fund coverage, "
        f"a savings rate of {features.savings_rate:.1f}%, and a debt burden of "
        f"{features.debt_burden_ratio:.1f}% of income, this allocation balances "
        f"{'stability and growth' if risk.risk_category == RiskCategory.MODERATE else 'capital preservation' if risk.risk_category == RiskCategory.LOW else 'growth potential'} "
        f"while keeping appropriate debt/liquid exposure for your liquidity needs."
    )
    if engine_note:
        return f"{base} {engine_note}"
    return base


def build_portfolio_from_allocation(
    allocation: dict[str, float],
    data: AllocationInput,
    risk: RiskAssessment,
) -> list[dict]:
    active_instruments = [i for i in data.instruments if i.is_active]
    portfolio = []

    for segment, pct in allocation.items():
        if pct <= 0:
            continue
        category = SEGMENT_TO_CATEGORY[segment]
        segment_instruments = [i for i in active_instruments if i.category == category]
        ranked = rank_instruments(segment_instruments, risk.risk_category, top_n=2)
        amount = round(data.investable_amount * pct / 100, 2)
        instruments_out = _split_segment_across_instruments(pct, amount, ranked)

        portfolio.append(
            {
                "segment": segment,
                "allocation_pct": pct,
                "amount": amount,
                "instruments": instruments_out,
            }
        )

    return portfolio


def build_recommendation_response(
    allocation: dict[str, float],
    data: AllocationInput,
    features: DerivedFeatures,
    engine: str = "rule_based",
    engine_note: str | None = None,
) -> dict:
    goal = _primary_goal(data.goals)
    risk = data.risk
    horizon_years = max(1, goal.target_year - datetime.now().year)

    portfolio = build_portfolio_from_allocation(allocation, data, risk)
    explanation = build_explanation(
        data.profile, goal, risk, features, horizon_years, engine_note=engine_note
    )

    return {
        "engine": engine,
        "risk": {"score": risk.risk_score, "category": risk.risk_category.value},
        "portfolio": portfolio,
        "explanation": explanation,
        "disclaimer": DISCLAIMER,
        "derived_features": features.to_dict(),
        "assumed_annual_return_pct": 10.0,
    }
