"""
Rebalancing engine — compares stored recommendation snapshots.

ACADEMIC SIMPLIFICATION: "current allocation" = target from the user's second-most-recent
recommendation; "target allocation" = target from the latest recommendation.
No real brokerage/holdings integration — see REBALANCE_ASSUMPTION in crash_constants.py.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.market.crash_constants import REBALANCE_ASSUMPTION, REBALANCE_DRIFT_THRESHOLD_PP
from app.models import Recommendation
from app.recommendation.constants import SEGMENTS


@dataclass
class SegmentDrift:
    segment: str
    current_pct: float
    target_pct: float
    drift_pp: float
    flagged: bool
    suggestion: str | None


@dataclass
class RebalanceResult:
    status: str
    assumption_note: str
    drift_threshold_pp: float
    segments: list[SegmentDrift]
    flagged_segments: list[SegmentDrift]
    explanation: str


def _extract_segment_pcts(allocation: dict) -> dict[str, float]:
    portfolio = allocation.get("portfolio") or []
    pcts = {seg: 0.0 for seg in SEGMENTS}
    for item in portfolio:
        segment = item.get("segment")
        if segment in pcts:
            pcts[segment] = float(item.get("allocation_pct") or 0)
    return pcts


def check_rebalancing(
    db: Session,
    user_id: int,
    *,
    drift_threshold_pp: float = REBALANCE_DRIFT_THRESHOLD_PP,
) -> RebalanceResult:
    recs = (
        db.query(Recommendation)
        .filter(Recommendation.user_id == user_id)
        .order_by(Recommendation.generated_at.desc())
        .limit(2)
        .all()
    )

    if len(recs) < 2:
        return RebalanceResult(
            status="insufficient_history",
            assumption_note=REBALANCE_ASSUMPTION,
            drift_threshold_pp=drift_threshold_pp,
            segments=[],
            flagged_segments=[],
            explanation=(
                "Rebalancing check requires at least two stored recommendations to compare. "
                "Generate another recommendation after your profile or goals change to enable drift analysis."
            ),
        )

    latest, previous = recs[0], recs[1]
    current_pcts = _extract_segment_pcts(previous.allocation)
    target_pcts = _extract_segment_pcts(latest.allocation)

    segments: list[SegmentDrift] = []
    flagged: list[SegmentDrift] = []

    for segment in SEGMENTS:
        current = current_pcts[segment]
        target = target_pcts[segment]
        drift = round(current - target, 2)
        is_flagged = abs(drift) > drift_threshold_pp

        suggestion = None
        if is_flagged:
            if drift > 0:
                suggestion = (
                    f"Your prior recommendation had {segment} at {current:.1f}% vs a new target of "
                    f"{target:.1f}%. Consider reducing new contributions to {segment} until it moves "
                    f"closer to target — no forced selling suggested."
                )
            else:
                suggestion = (
                    f"Your prior recommendation had {segment} at {current:.1f}% vs a new target of "
                    f"{target:.1f}%. Consider increasing new contributions toward {segment} to "
                    f"gradually close the gap — no forced selling suggested."
                )

        row = SegmentDrift(
            segment=segment,
            current_pct=current,
            target_pct=target,
            drift_pp=drift,
            flagged=is_flagged,
            suggestion=suggestion,
        )
        segments.append(row)
        if is_flagged:
            flagged.append(row)

    if not flagged:
        return RebalanceResult(
            status="within_target_range",
            assumption_note=REBALANCE_ASSUMPTION,
            drift_threshold_pp=drift_threshold_pp,
            segments=segments,
            flagged_segments=[],
            explanation=(
                f"Portfolio allocation drift is within ±{drift_threshold_pp:.0f} percentage points "
                "across all segments when comparing your last two recommendation snapshots."
            ),
        )

    flagged_names = ", ".join(s.segment for s in flagged)
    return RebalanceResult(
        status="rebalance_suggested",
        assumption_note=REBALANCE_ASSUMPTION,
        drift_threshold_pp=drift_threshold_pp,
        segments=segments,
        flagged_segments=flagged,
        explanation=(
            f"Drift exceeds ±{drift_threshold_pp:.0f} pp for: {flagged_names}. "
            "Suggestions focus on adjusting future contributions, not forced selling."
        ),
    )
