"""ML-based allocation engine wrapper (Phase 2)."""

import sys
from pathlib import Path

# Ensure backend root is on path for ml.predict imports when loaded as app module
BACKEND_ROOT = Path(__file__).resolve().parents[2]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from app.recommendation.types import AllocationInput
from app.recommendation.derived_features import calculate_derived_features
from app.recommendation.recommendation_builder import build_recommendation_response
from ml.predict import ModelLoadError, ModelNotFoundError, load_active_model, predict_segment_allocation

ML_ENGINE_NOTE = (
    "This allocation was produced by the ML-based engine (XGBoost), trained on synthetically "
    "generated data derived from rule-based logic with added noise — not from independent "
    "historical ground truth."
)


def generate_ml_recommendation(data: AllocationInput) -> dict:
    profile = data.profile
    features = calculate_derived_features(
        monthly_income=profile.monthly_income or 0,
        monthly_expenses=profile.monthly_expenses or 0,
        savings=profile.savings or 0,
        existing_investments=profile.existing_investments or 0,
        emergency_fund_months=profile.emergency_fund_months or 0,
        emi=profile.emi or 0,
    )

    _pipeline, metadata = load_active_model()
    engine = metadata.get("engine", "ml_v1")
    allocation = predict_segment_allocation(profile, data.goals, data.risk)

    return build_recommendation_response(
        allocation,
        data,
        features,
        engine=engine,
        engine_note=ML_ENGINE_NOTE,
    )


__all__ = [
    "generate_ml_recommendation",
    "ModelNotFoundError",
    "ModelLoadError",
]
