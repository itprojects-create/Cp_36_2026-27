"""ML feature engineering — shared between dataset generation, training, and live inference."""

from datetime import datetime

import pandas as pd

from app.models import FinancialGoal, InvestmentExperience, RiskAssessment, UserProfile
from app.recommendation.derived_features import calculate_derived_features
from app.recommendation.risk_scoring import REQUIRED_QUESTIONS

CATEGORICAL_FEATURES = ["goal_type", "investment_experience", "risk_category"]
NUMERIC_FEATURES = [
    "age",
    "dependents",
    "monthly_income",
    "monthly_expenses",
    "savings",
    "existing_investments",
    "emergency_fund_months",
    "emi",
    "monthly_sip",
    "target_amount",
    "target_year",
    "horizon_years",
    "risk_score",
    "savings_rate",
    "debt_burden_ratio",
    "emergency_fund_coverage",
    "investable_assets",
    "net_monthly_surplus",
]
QUESTIONNAIRE_FEATURES = [f"q_{q}" for q in REQUIRED_QUESTIONS]

FEATURE_COLUMNS = NUMERIC_FEATURES + CATEGORICAL_FEATURES + QUESTIONNAIRE_FEATURES


def _primary_goal(goals: list[FinancialGoal]) -> FinancialGoal:
    return sorted(goals, key=lambda g: (g.priority, g.target_year))[0]


def build_ml_features(
    profile: UserProfile,
    goals: list[FinancialGoal],
    risk: RiskAssessment,
) -> dict:
    goal = _primary_goal(goals)
    current_year = datetime.now().year
    horizon_years = max(1, goal.target_year - current_year)

    derived = calculate_derived_features(
        monthly_income=profile.monthly_income or 0,
        monthly_expenses=profile.monthly_expenses or 0,
        savings=profile.savings or 0,
        existing_investments=profile.existing_investments or 0,
        emergency_fund_months=profile.emergency_fund_months or 0,
        emi=profile.emi or 0,
    )

    experience = profile.investment_experience
    if isinstance(experience, InvestmentExperience):
        experience = experience.value

    row = {
        "age": profile.age,
        "dependents": profile.dependents or 0,
        "monthly_income": profile.monthly_income,
        "monthly_expenses": profile.monthly_expenses,
        "savings": profile.savings or 0,
        "existing_investments": profile.existing_investments or 0,
        "emergency_fund_months": profile.emergency_fund_months or 0,
        "emi": profile.emi or 0,
        "monthly_sip": profile.monthly_sip or 0,
        "target_amount": goal.target_amount,
        "target_year": goal.target_year,
        "horizon_years": horizon_years,
        "risk_score": risk.risk_score,
        "savings_rate": derived.savings_rate,
        "debt_burden_ratio": derived.debt_burden_ratio,
        "emergency_fund_coverage": derived.emergency_fund_coverage,
        "investable_assets": derived.investable_assets,
        "net_monthly_surplus": derived.net_monthly_surplus,
        "goal_type": goal.goal_type.value,
        "investment_experience": experience,
        "risk_category": risk.risk_category.value,
    }

    for question_id in REQUIRED_QUESTIONS:
        row[f"q_{question_id}"] = risk.responses.get(question_id, 3)

    return row


def build_ml_features_dataframe(
    profile: UserProfile,
    goals: list[FinancialGoal],
    risk: RiskAssessment,
) -> pd.DataFrame:
    return pd.DataFrame([build_ml_features(profile, goals, risk)])
