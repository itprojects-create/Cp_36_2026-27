"""Rank instruments within a segment using a transparent scoring formula."""

from app.models import InvestmentInstrument, RiskCategory


def _normalize(values: list[float | None], higher_is_better: bool) -> list[float]:
    clean = [v for v in values if v is not None]
    if not clean:
        return [0.5] * len(values)
    min_v, max_v = min(clean), max(clean)
    result = []
    for v in values:
        if v is None:
            result.append(0.5)
        elif max_v == min_v:
            result.append(1.0)
        else:
            norm = (v - min_v) / (max_v - min_v)
            result.append(norm if higher_is_better else 1.0 - norm)
    return result


def _risk_match_score(instrument_risk: int, category: RiskCategory) -> float:
    target = {"LOW": 2, "MODERATE": 3, "HIGH": 4}[category.value]
    diff = abs(instrument_risk - target)
    return max(0.0, 1.0 - diff * 0.25)


def rank_instruments(
    instruments: list[InvestmentInstrument],
    risk_category: RiskCategory,
    top_n: int = 2,
) -> list[tuple[InvestmentInstrument, float, str]]:
    if not instruments:
        return []

    cagrs = _normalize([i.cagr_3y for i in instruments], higher_is_better=True)
    expenses = _normalize([i.expense_ratio for i in instruments], higher_is_better=False)

    scored: list[tuple[InvestmentInstrument, float, str]] = []
    for idx, inst in enumerate(instruments):
        risk_match = _risk_match_score(inst.risk_level, risk_category)
        score = 0.5 * cagrs[idx] + 0.3 * expenses[idx] + 0.2 * risk_match

        reasons = []
        if inst.expense_ratio is not None and inst.expense_ratio <= 0.6:
            reasons.append("competitive expense ratio")
        if inst.cagr_3y is not None and inst.cagr_3y >= 12:
            reasons.append("strong 3-year CAGR track record")
        reasons.append(f"risk profile aligned with your {risk_category.value.lower()} category")
        reason_text = ", ".join(reasons).capitalize() + f" for {inst.category.value} exposure"

        scored.append((inst, score, reason_text))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:top_n]
