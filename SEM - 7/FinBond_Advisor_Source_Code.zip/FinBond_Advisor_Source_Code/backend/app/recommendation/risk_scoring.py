"""Risk questionnaire scoring — 8–10 questions mapped to a 1–10 score."""

from app.models import RiskCategory

QUESTION_WEIGHTS: dict[str, float] = {
    "portfolio_drop_reaction": 1.2,
    "income_stability": 1.0,
    "emergency_fund_presence": 0.9,
    "debt_load": 1.0,
    "investment_horizon": 1.1,
    "capital_preservation": 1.0,
    "investment_experience": 0.8,
    "preferred_style": 0.9,
    "dependents_obligations": 0.7,
    "volatility_tolerance": 1.0,
}

REQUIRED_QUESTIONS = list(QUESTION_WEIGHTS.keys())


def score_to_category(score: float) -> RiskCategory:
    if score <= 3.0:
        return RiskCategory.LOW
    if score <= 7.0:
        return RiskCategory.MODERATE
    return RiskCategory.HIGH


def calculate_risk_score(responses: dict[str, int]) -> tuple[float, RiskCategory]:
    missing = [q for q in REQUIRED_QUESTIONS if q not in responses]
    if missing:
        raise ValueError(f"Missing questionnaire responses: {', '.join(missing)}")

    total_weight = 0.0
    weighted_sum = 0.0

    for question_id, weight in QUESTION_WEIGHTS.items():
        answer = responses[question_id]
        if not 1 <= answer <= 5:
            raise ValueError(f"Response for {question_id} must be between 1 and 5")
        # Map Likert 1–5 to risk appetite 1–10 (higher = more risk tolerance)
        normalized = 1.0 + (answer - 1) * (9.0 / 4.0)
        weighted_sum += normalized * weight
        total_weight += weight

    score = round(weighted_sum / total_weight, 1)
    score = max(1.0, min(10.0, score))
    return score, score_to_category(score)


def get_questionnaire() -> list[dict]:
    """Return questionnaire metadata for the frontend."""
    return [
        {
            "id": "portfolio_drop_reaction",
            "text": "If your portfolio dropped 20% in a month, what would you do?",
            "options": [
                {"value": 1, "label": "Sell everything immediately"},
                {"value": 2, "label": "Sell some holdings to reduce risk"},
                {"value": 3, "label": "Hold and wait for recovery"},
                {"value": 4, "label": "Hold and consider buying more"},
                {"value": 5, "label": "Aggressively buy more at lower prices"},
            ],
        },
        {
            "id": "income_stability",
            "text": "How stable is your primary source of income?",
            "options": [
                {"value": 1, "label": "Highly unstable / irregular"},
                {"value": 2, "label": "Somewhat unstable"},
                {"value": 3, "label": "Moderately stable"},
                {"value": 4, "label": "Stable with minor fluctuations"},
                {"value": 5, "label": "Very stable and predictable"},
            ],
        },
        {
            "id": "emergency_fund_presence",
            "text": "Do you have an adequate emergency fund?",
            "options": [
                {"value": 1, "label": "No emergency fund at all"},
                {"value": 2, "label": "Less than 1 month of expenses"},
                {"value": 3, "label": "1–3 months of expenses"},
                {"value": 4, "label": "3–6 months of expenses"},
                {"value": 5, "label": "More than 6 months of expenses"},
            ],
        },
        {
            "id": "debt_load",
            "text": "How would you describe your current debt/EMI burden?",
            "options": [
                {"value": 1, "label": "Very high — EMIs strain my budget"},
                {"value": 2, "label": "High — limits my ability to invest"},
                {"value": 3, "label": "Moderate — manageable but noticeable"},
                {"value": 4, "label": "Low — EMIs are a small portion of income"},
                {"value": 5, "label": "Minimal or no debt"},
            ],
        },
        {
            "id": "investment_horizon",
            "text": "What is your primary investment time horizon?",
            "options": [
                {"value": 1, "label": "Less than 2 years"},
                {"value": 2, "label": "2–5 years"},
                {"value": 3, "label": "5–10 years"},
                {"value": 4, "label": "10–15 years"},
                {"value": 5, "label": "More than 15 years"},
            ],
        },
        {
            "id": "capital_preservation",
            "text": "How important is preserving your invested capital?",
            "options": [
                {"value": 5, "label": "Not important — I prioritize growth"},
                {"value": 4, "label": "Slightly important"},
                {"value": 3, "label": "Moderately important"},
                {"value": 2, "label": "Very important"},
                {"value": 1, "label": "Extremely important — capital must be protected"},
            ],
        },
        {
            "id": "investment_experience",
            "text": "What is your experience with investing in equities/mutual funds?",
            "options": [
                {"value": 1, "label": "No experience"},
                {"value": 2, "label": "Less than 1 year"},
                {"value": 3, "label": "1–3 years"},
                {"value": 4, "label": "3–7 years"},
                {"value": 5, "label": "More than 7 years"},
            ],
        },
        {
            "id": "preferred_style",
            "text": "Which investment style do you prefer?",
            "options": [
                {"value": 1, "label": "Fixed income and capital protection"},
                {"value": 2, "label": "Mostly debt with some equity"},
                {"value": 3, "label": "Balanced mix of debt and equity"},
                {"value": 4, "label": "Mostly equity with some debt"},
                {"value": 5, "label": "Aggressive growth through equity"},
            ],
        },
        {
            "id": "dependents_obligations",
            "text": "How many financial dependents do you support?",
            "options": [
                {"value": 5, "label": "None"},
                {"value": 4, "label": "1 dependent"},
                {"value": 3, "label": "2 dependents"},
                {"value": 2, "label": "3–4 dependents"},
                {"value": 1, "label": "5 or more dependents"},
            ],
        },
        {
            "id": "volatility_tolerance",
            "text": "How comfortable are you with short-term market volatility?",
            "options": [
                {"value": 1, "label": "Very uncomfortable — avoid volatility"},
                {"value": 2, "label": "Somewhat uncomfortable"},
                {"value": 3, "label": "Neutral — can tolerate moderate swings"},
                {"value": 4, "label": "Comfortable with significant swings"},
                {"value": 5, "label": "Very comfortable — volatility is opportunity"},
            ],
        },
    ]
