"""Shared types for recommendation engines."""

from dataclasses import dataclass

from app.models import FinancialGoal, InvestmentInstrument, RiskAssessment, UserProfile


@dataclass
class AllocationInput:
    profile: UserProfile
    goals: list[FinancialGoal]
    risk: RiskAssessment
    instruments: list[InvestmentInstrument]
    investable_amount: float
