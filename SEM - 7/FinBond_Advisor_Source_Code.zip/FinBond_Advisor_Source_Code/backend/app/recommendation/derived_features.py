"""Derived financial feature calculations from user profile."""

from dataclasses import dataclass


@dataclass
class DerivedFeatures:
    savings_rate: float
    debt_burden_ratio: float
    emergency_fund_coverage: float
    investable_assets: float
    net_monthly_surplus: float

    def to_dict(self) -> dict:
        return {
            "savings_rate": round(self.savings_rate, 2),
            "debt_burden_ratio": round(self.debt_burden_ratio, 2),
            "emergency_fund_coverage": round(self.emergency_fund_coverage, 2),
            "investable_assets": round(self.investable_assets, 2),
            "net_monthly_surplus": round(self.net_monthly_surplus, 2),
        }


def calculate_derived_features(
    monthly_income: float,
    monthly_expenses: float,
    savings: float,
    existing_investments: float,
    emergency_fund_months: float,
    emi: float,
) -> DerivedFeatures:
    if monthly_income <= 0:
        raise ValueError("monthly_income must be positive")

    net_surplus = monthly_income - monthly_expenses - emi
    savings_rate = (net_surplus / monthly_income) * 100 if monthly_income else 0.0
    debt_burden_ratio = (emi / monthly_income) * 100 if monthly_income else 0.0
    emergency_fund_coverage = emergency_fund_months
    investable_assets = savings + existing_investments

    return DerivedFeatures(
        savings_rate=savings_rate,
        debt_burden_ratio=debt_burden_ratio,
        emergency_fund_coverage=emergency_fund_coverage,
        investable_assets=investable_assets,
        net_monthly_surplus=net_surplus,
    )
