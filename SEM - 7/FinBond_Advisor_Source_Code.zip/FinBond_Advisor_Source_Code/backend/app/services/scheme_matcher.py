"""
Government scheme eligibility matcher — screening aid, not a legal determination.

Uses existing user profile fields only (age, occupation, monthly_income).
Gender and social category are not collected in onboarding — schemes requiring
them are classified as MAY BE ELIGIBLE rather than guessed.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from app.models import GovernmentScheme, UserProfile

VERIFY_LINE = "Verify eligibility on the official government portal before applying."

CLOSED_KEYWORDS = ("closed for new", "closed to new", "not accepted")


class EligibilityClass(str, Enum):
    ELIGIBLE = "ELIGIBLE"
    MAY_BE_ELIGIBLE = "MAY BE ELIGIBLE"
    NOT_ELIGIBLE = "NOT ELIGIBLE"


@dataclass
class SchemeMatchResult:
    scheme_id: int
    scheme_name: str
    classification: EligibilityClass
    reason: str
    official_portal_url: str
    verify_notice: str = VERIFY_LINE


def _annual_income(profile: UserProfile) -> float | None:
    if profile.monthly_income is None:
        return None
    return float(profile.monthly_income) * 12


def _occupation_matches(user_occupation: str | None, scheme_occupation: str | None) -> bool | None:
    """Return True/False if determinable, None if user occupation missing."""
    if not scheme_occupation or scheme_occupation.lower() == "any":
        return True
    if not user_occupation:
        return None

    occ = user_occupation.lower()
    scheme = scheme_occupation.lower()

    if scheme == "salaried":
        salaried_hints = (
            "salaried", "employee", "engineer", "developer", "manager", "analyst",
            "consultant employed", "executive", "officer", "teacher", "nurse",
        )
        self_hints = ("self-employed", "freelance", "business owner", "entrepreneur", "proprietor")
        if any(h in occ for h in self_hints):
            return False
        if any(h in occ for h in salaried_hints):
            return True
        return None

    if scheme == "self-employed":
        self_hints = ("self-employed", "freelance", "business", "entrepreneur", "proprietor", "consultant")
        if any(h in occ for h in self_hints):
            return True
        salaried_hints = ("salaried", "employee at", "software engineer", "bank officer")
        if any(h in occ for h in salaried_hints):
            return False
        return None

    return None


def _is_closed_scheme(scheme: GovernmentScheme) -> bool:
    notes = (scheme.eligibility_notes or "").lower()
    return any(kw in notes for kw in CLOSED_KEYWORDS)


def _has_unverifiable_notes(scheme: GovernmentScheme) -> bool:
    return bool(scheme.eligibility_notes and scheme.eligibility_notes.strip())


def match_scheme(profile: UserProfile | None, scheme: GovernmentScheme) -> SchemeMatchResult:
    base = SchemeMatchResult(
        scheme_id=scheme.id,
        scheme_name=scheme.name,
        classification=EligibilityClass.MAY_BE_ELIGIBLE,
        reason="",
        official_portal_url=scheme.official_portal_url,
    )

    if _is_closed_scheme(scheme):
        base.classification = EligibilityClass.NOT_ELIGIBLE
        base.reason = (
            f"{scheme.name} is closed for new enrollment. "
            f"{scheme.eligibility_notes or ''} {VERIFY_LINE}"
        )
        return base

    if profile is None:
        base.reason = f"Complete your profile to check structured eligibility criteria. {VERIFY_LINE}"
        return base

    failures: list[str] = []
    may_reasons: list[str] = []

    if scheme.eligibility_min_age is not None:
        if profile.age is None:
            may_reasons.append("age not provided in profile")
        elif profile.age < scheme.eligibility_min_age:
            failures.append(f"minimum age is {scheme.eligibility_min_age} (you are {profile.age})")

    if scheme.eligibility_max_age is not None:
        if profile.age is None:
            may_reasons.append("age not provided in profile")
        elif profile.age > scheme.eligibility_max_age:
            failures.append(f"maximum age is {scheme.eligibility_max_age} (you are {profile.age})")

    annual = _annual_income(profile)
    if scheme.eligibility_min_income is not None:
        if annual is None:
            may_reasons.append("income not provided in profile")
        elif annual < scheme.eligibility_min_income:
            failures.append(
                f"minimum annual income is ₹{scheme.eligibility_min_income:,.0f} "
                f"(estimated ₹{annual:,.0f} from monthly income)"
            )

    if scheme.eligibility_max_income is not None:
        if annual is None:
            may_reasons.append("income not provided in profile")
        elif annual > scheme.eligibility_max_income:
            failures.append(
                f"maximum annual income is ₹{scheme.eligibility_max_income:,.0f} "
                f"(estimated ₹{annual:,.0f} from monthly income)"
            )

    occ_match = _occupation_matches(profile.occupation, scheme.eligibility_occupation)
    if occ_match is False:
        failures.append(
            f"occupation criterion not met (scheme expects: {scheme.eligibility_occupation})"
        )
    elif occ_match is None and scheme.eligibility_occupation and scheme.eligibility_occupation.lower() != "any":
        may_reasons.append(
            f"occupation could not be matched to scheme requirement ({scheme.eligibility_occupation})"
        )

    if scheme.eligibility_gender and scheme.eligibility_gender.lower() != "any":
        may_reasons.append(
            f"scheme restricts by gender ({scheme.eligibility_gender}) — gender not stored in profile"
        )

    if scheme.eligibility_category and scheme.eligibility_category.lower() != "any":
        may_reasons.append(
            f"scheme may restrict by category ({scheme.eligibility_category}) — category not stored in profile"
        )

    if failures:
        base.classification = EligibilityClass.NOT_ELIGIBLE
        base.reason = f"Structured criteria not met: {'; '.join(failures)}. {VERIFY_LINE}"
        return base

    if may_reasons or _has_unverifiable_notes(scheme):
        base.classification = EligibilityClass.MAY_BE_ELIGIBLE
        parts = may_reasons.copy()
        if scheme.eligibility_notes:
            parts.append(f"additional conditions apply: {scheme.eligibility_notes}")
        base.reason = f"{'; '.join(parts)}. {VERIFY_LINE}"
        return base

    base.classification = EligibilityClass.ELIGIBLE
    base.reason = (
        f"Your stored profile satisfies the structured criteria we can check for {scheme.name}. {VERIFY_LINE}"
    )
    return base


def match_all_schemes(profile: UserProfile | None, schemes: list[GovernmentScheme]) -> list[SchemeMatchResult]:
    return [match_scheme(profile, s) for s in schemes if s.is_active]
