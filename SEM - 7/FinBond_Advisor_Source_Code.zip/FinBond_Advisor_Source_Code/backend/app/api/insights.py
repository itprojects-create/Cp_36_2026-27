from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import get_current_user
from app.db.session import get_db
from app.market.crash_engine import generate_crash_signal
from app.market.schemas import CrashSignalResponse, RebalanceCheckResponse, SegmentDriftItem, CrashSegmentSplit, CrashInstrumentSuggestion
from app.models import InvestmentInstrument, RiskAssessment, User, UserProfile
from app.recommendation.rebalancing_engine import check_rebalancing

router = APIRouter(tags=["insights"])


def _to_crash_response(result) -> CrashSignalResponse:
    return CrashSignalResponse(
        status=result.status,
        drawdown_pct=result.drawdown_pct,
        correction_tier=result.correction_tier,
        deployment_pct_of_cash=result.deployment_pct_of_cash,
        available_cash=result.available_cash,
        suggested_deployment_amount=result.suggested_deployment_amount,
        segment_split=[
            CrashSegmentSplit(
                segment=s["segment"],
                allocation_pct=s["allocation_pct"],
                amount=s["amount"],
                instruments=[
                    CrashInstrumentSuggestion(**inst) for inst in s.get("instruments", [])
                ],
            )
            for s in result.segment_split
        ],
        explanation=result.explanation,
        disclaimer=result.disclaimer,
        risk_category=result.risk_category,
    )


@router.get("/crash-signal", response_model=CrashSignalResponse)
def get_crash_signal(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    risk = (
        db.query(RiskAssessment)
        .filter(RiskAssessment.user_id == current_user.id)
        .order_by(RiskAssessment.created_at.desc())
        .first()
    )
    instruments = db.query(InvestmentInstrument).all()

    result = generate_crash_signal(
        db,
        current_user.id,
        profile,
        risk,
        instruments,
        tier_mild_pct=settings.CRASH_TIER_MILD_PCT,
        tier_deep_pct=settings.CRASH_TIER_DEEP_PCT,
        tier_major_pct=settings.CRASH_TIER_MAJOR_PCT,
    )
    return _to_crash_response(result)


@router.post("/rebalance-check", response_model=RebalanceCheckResponse)
def rebalance_check(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = check_rebalancing(
        db,
        current_user.id,
        drift_threshold_pp=settings.REBALANCE_DRIFT_THRESHOLD_PP,
    )
    return RebalanceCheckResponse(
        status=result.status,
        assumption_note=result.assumption_note,
        drift_threshold_pp=result.drift_threshold_pp,
        segments=[SegmentDriftItem(**s.__dict__) for s in result.segments],
        flagged_segments=[SegmentDriftItem(**s.__dict__) for s in result.flagged_segments],
        explanation=result.explanation,
    )
