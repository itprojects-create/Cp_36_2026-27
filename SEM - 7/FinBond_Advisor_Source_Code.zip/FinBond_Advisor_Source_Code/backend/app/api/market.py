from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.market.cache_service import build_pulse_item, get_latest_snapshot, is_stale
from app.market.constants import REGIME_DISCLAIMER, YFINANCE_TICKERS
from app.market.regime_detector import classify_regime
from app.market.schemas import (
    FiiDiiStatus,
    GsecYieldResponse,
    MarketPulseItem,
    MarketPulseResponse,
    MarketRegimeResponse,
    MutualFundNavItem,
)
from app.models import GsecYieldSetting, InvestmentInstrument, User

router = APIRouter(tags=["market"])

MARKET_DISCLAIMER = (
    "Market data is fetched from third-party sources (Yahoo Finance via yfinance, AMFI NAV file). "
    "Values may be delayed or unavailable. For informational display only — not used in allocation engines."
)


def _get_gsec(db: Session) -> GsecYieldResponse:
    row = db.query(GsecYieldSetting).order_by(GsecYieldSetting.updated_at.desc()).first()
    if not row:
        return GsecYieldResponse(
            yield_pct=None,
            updated_at=None,
            status="unavailable",
            message="G-Sec yield not configured — admin must enter manually",
        )
    return GsecYieldResponse(
        yield_pct=row.yield_pct,
        updated_at=row.updated_at.isoformat(),
        status="available",
    )


@router.get("/market-pulse", response_model=MarketPulseResponse)
def get_market_pulse(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    indices: list[MarketPulseItem] = []
    commodities: list[MarketPulseItem] = []
    volatility: MarketPulseItem | None = None

    for key, info in YFINANCE_TICKERS.items():
        item = build_pulse_item(
            db,
            symbol=key,
            label=info["label"],
            source="yfinance",
            ticker=info["ticker"],
        )
        pulse = MarketPulseItem(**item)
        if key == "INDIA_VIX":
            volatility = pulse
        elif key == "CRUDE_OIL":
            commodities.append(pulse)
        else:
            indices.append(pulse)

    gsec = _get_gsec(db)
    gsec_item = MarketPulseItem(
        symbol="GSEC_10Y",
        label="10Y G-Sec Yield",
        value=gsec.yield_pct,
        source="admin_manual",
        ticker=None,
        last_updated=gsec.updated_at,
        is_stale=False,
        status=gsec.status,
        message=gsec.message,
        meta={},
    )

    mf_navs: list[MutualFundNavItem] = []
    instruments = (
        db.query(InvestmentInstrument)
        .filter(
            InvestmentInstrument.is_active.is_(True),
            InvestmentInstrument.amfi_code.isnot(None),
        )
        .order_by(InvestmentInstrument.category, InvestmentInstrument.name)
        .all()
    )
    for inst in instruments:
        symbol = f"AMFI_{inst.amfi_code}"
        snap = get_latest_snapshot(db, symbol)
        if snap is None:
            mf_navs.append(
                MutualFundNavItem(
                    instrument_id=inst.id,
                    instrument_name=inst.name,
                    amfi_code=inst.amfi_code,
                    status="unavailable",
                    message="No cached NAV available yet",
                )
            )
        else:
            stale = is_stale(snap.fetched_at)
            mf_navs.append(
                MutualFundNavItem(
                    instrument_id=inst.id,
                    instrument_name=inst.name,
                    amfi_code=inst.amfi_code,
                    nav=snap.value,
                    nav_date=(snap.meta or {}).get("nav_date"),
                    last_updated=snap.fetched_at.isoformat(),
                    is_stale=stale,
                    status="available",
                    message="Serving stale cached NAV" if stale else None,
                )
            )

    return MarketPulseResponse(
        indices=indices,
        volatility=volatility,
        commodities=commodities,
        gsec_yield=gsec_item,
        mutual_fund_navs=mf_navs,
        fii_dii=FiiDiiStatus(),
        disclaimer=MARKET_DISCLAIMER,
    )


@router.get("/market-regime", response_model=MarketRegimeResponse)
def get_market_regime(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    nifty = get_latest_snapshot(db, "NIFTY50")
    vix = get_latest_snapshot(db, "INDIA_VIX")
    crude = get_latest_snapshot(db, "CRUDE_OIL")

    if nifty is None:
        return MarketRegimeResponse(
            regime="UNAVAILABLE",
            classification_basis="Market regime cannot be classified — Nifty 50 data is not available.",
            inputs={},
            disclaimer=REGIME_DISCLAIMER,
            data_status="unavailable",
        )

    nifty_meta = nifty.meta or {}
    crude_meta = (crude.meta or {}) if crude else {}

    result = classify_regime(
        nifty_drawdown_pct=nifty_meta.get("drawdown_from_52w_high_pct"),
        india_vix=vix.value if vix else None,
        crude_change_30d_pct=crude_meta.get("change_30d_pct"),
        nifty_trend_up=bool(nifty_meta.get("nifty_trend_up")),
    )

    stale = is_stale(nifty.fetched_at) or (vix is not None and is_stale(vix.fetched_at))

    return MarketRegimeResponse(
        regime=result.regime.value,
        classification_basis=result.classification_basis,
        inputs=result.inputs,
        disclaimer=result.disclaimer,
        data_status="stale" if stale else "available",
        is_stale=stale,
    )


@router.get("/gsec", response_model=GsecYieldResponse)
def get_gsec_yield(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return _get_gsec(db)
