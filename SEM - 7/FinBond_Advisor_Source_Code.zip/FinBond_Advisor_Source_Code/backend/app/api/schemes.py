from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import GovernmentScheme, User, UserProfile
from app.schemas import GovernmentSchemeResponse, SchemeEligibilityItem, SchemeEligibilityResponse
from app.services.scheme_matcher import match_all_schemes

router = APIRouter(prefix="/schemes", tags=["government-schemes"])


@router.get("", response_model=list[GovernmentSchemeResponse])
def list_active_schemes(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return (
        db.query(GovernmentScheme)
        .filter(GovernmentScheme.is_active.is_(True))
        .order_by(GovernmentScheme.name)
        .all()
    )


@router.post("/check-eligibility", response_model=SchemeEligibilityResponse)
def check_eligibility(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Complete your profile before checking scheme eligibility",
        )

    schemes = (
        db.query(GovernmentScheme)
        .filter(GovernmentScheme.is_active.is_(True))
        .order_by(GovernmentScheme.name)
        .all()
    )
    results = match_all_schemes(profile, schemes)

    return SchemeEligibilityResponse(
        results=[
            SchemeEligibilityItem(
                scheme_id=r.scheme_id,
                scheme_name=r.scheme_name,
                classification=r.classification.value,
                reason=r.reason,
                official_portal_url=r.official_portal_url,
                verify_notice=r.verify_notice,
            )
            for r in results
        ]
    )
