from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import FinancialGoal, RiskAssessment, User, UserProfile
from app.recommendation.derived_features import calculate_derived_features
from app.recommendation.risk_scoring import calculate_risk_score, get_questionnaire
from app.schemas import (
    DisclaimerAccept,
    FinancialGoalResponse,
    GoalsSubmit,
    RiskAssessmentResponse,
    RiskAssessmentSubmit,
    UserProfileCreate,
    UserProfileResponse,
)

router = APIRouter(prefix="/user", tags=["user"])


@router.post("/disclaimer", status_code=status.HTTP_200_OK)
def accept_disclaimer(
    payload: DisclaimerAccept,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not payload.accepted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Disclaimer must be accepted")
    current_user.disclaimer_accepted_at = datetime.now(timezone.utc)
    db.commit()
    return {"message": "Disclaimer accepted", "accepted_at": current_user.disclaimer_accepted_at}


def _require_disclaimer(user: User) -> None:
    if user.disclaimer_accepted_at is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Disclaimer must be accepted before continuing onboarding",
        )


@router.get("/profile", response_model=UserProfileResponse)
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")

    derived = calculate_derived_features(
        monthly_income=profile.monthly_income or 0,
        monthly_expenses=profile.monthly_expenses or 0,
        savings=profile.savings or 0,
        existing_investments=profile.existing_investments or 0,
        emergency_fund_months=profile.emergency_fund_months or 0,
        emi=profile.emi or 0,
    )
    response = UserProfileResponse.model_validate(profile)
    response.derived_features = derived.to_dict()
    return response


@router.post("/profile", response_model=UserProfileResponse)
def upsert_profile(
    payload: UserProfileCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_disclaimer(current_user)

    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if profile:
        for key, value in payload.model_dump().items():
            setattr(profile, key, value)
    else:
        profile = UserProfile(user_id=current_user.id, **payload.model_dump())
        db.add(profile)

    db.commit()
    db.refresh(profile)

    derived = calculate_derived_features(
        monthly_income=profile.monthly_income or 0,
        monthly_expenses=profile.monthly_expenses or 0,
        savings=profile.savings or 0,
        existing_investments=profile.existing_investments or 0,
        emergency_fund_months=profile.emergency_fund_months or 0,
        emi=profile.emi or 0,
    )
    response = UserProfileResponse.model_validate(profile)
    response.derived_features = derived.to_dict()
    return response


@router.get("/goals", response_model=list[FinancialGoalResponse])
def get_goals(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    goals = db.query(FinancialGoal).filter(FinancialGoal.user_id == current_user.id).all()
    return goals


@router.post("/goals", response_model=list[FinancialGoalResponse])
def submit_goals(
    payload: GoalsSubmit,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_disclaimer(current_user)

    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Complete profile first")

    db.query(FinancialGoal).filter(FinancialGoal.user_id == current_user.id).delete()
    created = []
    for goal_data in payload.goals:
        goal = FinancialGoal(user_id=current_user.id, **goal_data.model_dump())
        db.add(goal)
        created.append(goal)
    db.commit()
    for goal in created:
        db.refresh(goal)
    return created


@router.get("/risk-questionnaire")
def risk_questionnaire():
    return {"questions": get_questionnaire()}


@router.post("/risk-assessment", response_model=RiskAssessmentResponse)
def submit_risk_assessment(
    payload: RiskAssessmentSubmit,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_disclaimer(current_user)

    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Complete profile first")

    goals = db.query(FinancialGoal).filter(FinancialGoal.user_id == current_user.id).count()
    if goals == 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Add at least one goal first")

    try:
        score, category = calculate_risk_score(payload.responses)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    assessment = RiskAssessment(
        user_id=current_user.id,
        responses=payload.responses,
        risk_score=score,
        risk_category=category,
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)
    return assessment
