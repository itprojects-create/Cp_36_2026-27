from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models import FinancialGoal, InvestmentInstrument, Recommendation, RiskAssessment, User, UserProfile
from app.recommendation.allocation_engine import generate_recommendation
from app.recommendation.types import AllocationInput
from app.schemas import RecommendRequest, RecommendationOutput, RecommendationResponse

router = APIRouter(prefix="/recommend", tags=["recommendations"])


@router.get("/latest", response_model=RecommendationOutput)
def get_latest_recommendation(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rec = (
        db.query(Recommendation)
        .filter(Recommendation.user_id == current_user.id)
        .order_by(Recommendation.generated_at.desc())
        .first()
    )
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No recommendation found")
    allocation = rec.allocation.copy()
    allocation["recommendation_id"] = rec.id
    return allocation


@router.post("", response_model=RecommendationOutput)
def create_recommendation(
    payload: RecommendRequest | None = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Complete profile first")

    goals = db.query(FinancialGoal).filter(FinancialGoal.user_id == current_user.id).all()
    if not goals:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Add at least one goal first")

    risk = (
        db.query(RiskAssessment)
        .filter(RiskAssessment.user_id == current_user.id)
        .order_by(RiskAssessment.created_at.desc())
        .first()
    )
    if not risk:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Complete risk assessment first")

    instruments = db.query(InvestmentInstrument).all()
    default_amount = (profile.savings or 0) + (profile.existing_investments or 0)
    investable = payload.investable_amount if payload and payload.investable_amount else default_amount
    if investable <= 0:
        investable = max(default_amount, 100000.0)

    result = generate_recommendation(
        AllocationInput(
            profile=profile,
            goals=goals,
            risk=risk,
            instruments=instruments,
            investable_amount=investable,
        )
    )

    snapshot = {
        "profile": {
            "age": profile.age,
            "monthly_income": profile.monthly_income,
            "monthly_expenses": profile.monthly_expenses,
            "savings": profile.savings,
            "existing_investments": profile.existing_investments,
            "emergency_fund_months": profile.emergency_fund_months,
            "emi": profile.emi,
            "monthly_sip": profile.monthly_sip,
        },
        "goals": [
            {
                "goal_type": g.goal_type.value,
                "target_amount": g.target_amount,
                "target_year": g.target_year,
                "priority": g.priority,
            }
            for g in goals
        ],
        "risk": {"score": risk.risk_score, "category": risk.risk_category.value},
        "investable_amount": investable,
    }

    rec = Recommendation(
        user_id=current_user.id,
        input_snapshot=snapshot,
        allocation=result,
        explanation=result["explanation"],
    )
    db.add(rec)
    db.commit()
    db.refresh(rec)

    result["recommendation_id"] = rec.id
    return result


@router.get("/{recommendation_id}", response_model=RecommendationResponse)
def get_recommendation(
    recommendation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rec = db.query(Recommendation).filter(Recommendation.id == recommendation_id).first()
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recommendation not found")
    if rec.user_id != current_user.id and current_user.role.value != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    return rec
