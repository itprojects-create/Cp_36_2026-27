from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_optional_user
from app.db.session import get_db
from app.models import User
from app.schemas import AssistantAskRequest, AssistantResponseSchema
from app.services.faq_assistant import ASSISTANT_LABEL, answer

router = APIRouter(tags=["assistant"])


@router.post("/assistant/ask", response_model=AssistantResponseSchema)
def ask_assistant(
    payload: AssistantAskRequest,
    db: Session = Depends(get_db),
    current_user: User | None = Depends(get_optional_user),
):
    result = answer(payload.question, current_user.id if current_user else None, db)
    return AssistantResponseSchema(
        answer=result.answer,
        category=result.category,
        matched=result.matched,
        label=ASSISTANT_LABEL,
    )
