from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import require_admin
from app.db.session import get_db
from app.market.schemas import (
    AdminMarketStatusResponse,
    AdminSystemHealthResponse,
    GsecYieldResponse,
    GsecYieldUpdate,
    MarketSourceStatus,
    ThresholdSettings,
)
from app.models import GsecYieldSetting, GovernmentScheme, InvestmentInstrument, MarketFetchLog, User
from app.schemas import (
    AdminUserResponse,
    GovernmentSchemeCreate,
    GovernmentSchemeResponse,
    GovernmentSchemeUpdate,
    InstrumentCreate,
    InstrumentResponse,
    InstrumentUpdate,
    ModelMetricsResponse,
    UserToggleResponse,
)
from ml.predict import ModelNotFoundError, get_active_model_metadata

router = APIRouter(prefix="/admin", tags=["admin"])


def _market_source_rows(db: Session) -> list[MarketSourceStatus]:
    logs = db.query(MarketFetchLog).order_by(MarketFetchLog.source).all()
    return [
        MarketSourceStatus(
            source=log.source,
            last_success_at=log.last_success_at.isoformat() if log.last_success_at else None,
            last_attempt_at=log.last_attempt_at.isoformat() if log.last_attempt_at else None,
            last_error=log.last_error,
            used_stale_fallback=log.used_stale_fallback,
        )
        for log in logs
    ]


def _threshold_settings() -> ThresholdSettings:
    return ThresholdSettings(
        crash_tier_mild_pct=settings.CRASH_TIER_MILD_PCT,
        crash_tier_deep_pct=settings.CRASH_TIER_DEEP_PCT,
        crash_tier_major_pct=settings.CRASH_TIER_MAJOR_PCT,
        rebalance_drift_threshold_pp=settings.REBALANCE_DRIFT_THRESHOLD_PP,
    )


@router.get("/users", response_model=list[AdminUserResponse])
def list_users(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return db.query(User).order_by(User.created_at.desc()).all()


@router.patch("/users/{user_id}/toggle", response_model=UserToggleResponse)
def toggle_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.id == admin.id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot disable your own admin account")

    user.is_active = not user.is_active
    db.commit()
    state = "enabled" if user.is_active else "disabled"
    return UserToggleResponse(id=user.id, is_active=user.is_active, message=f"User {state} successfully")


@router.get("/instruments", response_model=list[InstrumentResponse])
def list_instruments(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return db.query(InvestmentInstrument).order_by(InvestmentInstrument.category, InvestmentInstrument.name).all()


@router.post("/instruments", response_model=InstrumentResponse, status_code=status.HTTP_201_CREATED)
def create_instrument(
    payload: InstrumentCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    instrument = InvestmentInstrument(
        **payload.model_dump(),
        last_updated=datetime.now(timezone.utc),
    )
    db.add(instrument)
    db.commit()
    db.refresh(instrument)
    return instrument


@router.put("/instruments/{instrument_id}", response_model=InstrumentResponse)
def update_instrument(
    instrument_id: int,
    payload: InstrumentUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    instrument = db.query(InvestmentInstrument).filter(InvestmentInstrument.id == instrument_id).first()
    if not instrument:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Instrument not found")

    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(instrument, key, value)
    instrument.last_updated = datetime.now(timezone.utc)
    db.commit()
    db.refresh(instrument)
    return instrument


@router.delete("/instruments/{instrument_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_instrument(
    instrument_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    instrument = db.query(InvestmentInstrument).filter(InvestmentInstrument.id == instrument_id).first()
    if not instrument:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Instrument not found")
    instrument.is_active = False
    instrument.last_updated = datetime.now(timezone.utc)
    db.commit()
    return None


@router.get("/model/metrics", response_model=ModelMetricsResponse)
def get_model_metrics(_: User = Depends(require_admin)):
    try:
        metadata = get_active_model_metadata()
    except ModelNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No trained ML model found. Run: python ml/train_model.py",
        ) from exc

    return ModelMetricsResponse(
        version=metadata.get("version", "unknown"),
        engine=metadata.get("engine", "ml_unknown"),
        training_date=metadata.get("training_date", ""),
        dataset_size=metadata.get("dataset_size"),
        noise_std_used=metadata.get("noise_std_used"),
        feature_columns=metadata.get("feature_columns", []),
        target_columns=metadata.get("target_columns", []),
        metrics=metadata.get("metrics", {}),
        model_file=metadata.get("model_file", ""),
        status="active",
    )


@router.get("/market/status", response_model=AdminMarketStatusResponse)
def get_market_status(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return AdminMarketStatusResponse(sources=_market_source_rows(db))


@router.get("/system-health", response_model=AdminSystemHealthResponse)
def get_system_health(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return AdminSystemHealthResponse(
        market_sources=_market_source_rows(db),
        thresholds=_threshold_settings(),
    )


@router.put("/gsec", response_model=GsecYieldResponse)
def update_gsec_yield(
    payload: GsecYieldUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_admin),
):
    row = GsecYieldSetting(
        yield_pct=payload.yield_pct,
        updated_at=datetime.now(timezone.utc),
        updated_by_admin_id=admin.id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return GsecYieldResponse(
        yield_pct=row.yield_pct,
        updated_at=row.updated_at.isoformat(),
        status="available",
    )


@router.get("/schemes", response_model=list[GovernmentSchemeResponse])
def list_schemes_admin(
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return db.query(GovernmentScheme).order_by(GovernmentScheme.name).all()


@router.post("/schemes", response_model=GovernmentSchemeResponse, status_code=status.HTTP_201_CREATED)
def create_scheme(
    payload: GovernmentSchemeCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    scheme = GovernmentScheme(
        **payload.model_dump(),
        last_updated=datetime.now(timezone.utc),
    )
    db.add(scheme)
    db.commit()
    db.refresh(scheme)
    return scheme


@router.put("/schemes/{scheme_id}", response_model=GovernmentSchemeResponse)
def update_scheme(
    scheme_id: int,
    payload: GovernmentSchemeUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    scheme = db.query(GovernmentScheme).filter(GovernmentScheme.id == scheme_id).first()
    if not scheme:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scheme not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(scheme, key, value)
    scheme.last_updated = datetime.now(timezone.utc)
    db.commit()
    db.refresh(scheme)
    return scheme


@router.delete("/schemes/{scheme_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_scheme(
    scheme_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    scheme = db.query(GovernmentScheme).filter(GovernmentScheme.id == scheme_id).first()
    if not scheme:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scheme not found")
    scheme.is_active = False
    scheme.last_updated = datetime.now(timezone.utc)
    db.commit()
    return None
