"""
Manually curated government scheme registry for academic demo.
Rates and availability verified against public sources where possible (Aug 2026).
Not live-fetched — admin-managed, same honesty pattern as instrument registry.
"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models import GovernmentScheme

VERIFY_PORTAL = "Verify current rate, eligibility, and enrollment status on the official portal."

SCHEME_SEED_DATA = [
    {
        "name": "Public Provident Fund (PPF)",
        "department": "Ministry of Finance / National Savings Institute",
        "description": "Long-term small-savings scheme for resident individuals with tax benefits under Section 80C. Resident individual status assumed for this demo screening.",
        "eligibility_min_age": 18,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": None,
        "benefits": "Tax deduction under 80C; interest compounded annually; partial withdrawal after 5 years.",
        "interest_or_return": "~7.1% p.a. (quarterly notified rate — verify current)",
        "lock_in_period": "15 years (extendable in blocks of 5 years)",
        "official_portal_url": "https://www.indiapost.gov.in/Financial/Pages/Content/PPF.aspx",
    },
    {
        "name": "National Savings Certificate (NSC VIII Issue)",
        "department": "Ministry of Finance / India Post",
        "description": "Fixed-income savings certificate available through post offices for resident individuals. Resident individual status assumed for this demo screening.",
        "eligibility_min_age": 18,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": None,
        "benefits": "80C deduction; interest deemed reinvested for tax purposes.",
        "interest_or_return": "~7.7% p.a. (quarterly notified rate — verify current)",
        "lock_in_period": "5 years",
        "official_portal_url": "https://www.indiapost.gov.in/Financial/Pages/Content/National-Savings-Certificate.aspx",
    },
    {
        "name": "National Pension System (NPS) — All Citizen Model",
        "department": "PFRDA",
        "description": "Voluntary defined-contribution pension scheme open to all citizens aged 18–70.",
        "eligibility_min_age": 18,
        "eligibility_max_age": 70,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "KYC and PRAN registration required. Tier I/Tier II rules apply. Tax treatment varies by section.",
        "benefits": "Market-linked retirement corpus; additional 80CCD(1B) deduction up to ₹50,000 for Tier I.",
        "interest_or_return": "Market-linked (not fixed)",
        "lock_in_period": "Till age 60 (partial withdrawal rules apply)",
        "official_portal_url": "https://www.npscra.nsdl.co.in/all-citizens.php",
    },
    {
        "name": "Atal Pension Yojana (APY)",
        "department": "PFRDA / Ministry of Finance",
        "description": "Guaranteed minimum pension scheme aimed at unorganised sector workers with a savings bank account.",
        "eligibility_min_age": 18,
        "eligibility_max_age": 40,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "Must hold a valid savings bank account. Not a member of any statutory social security scheme. Government co-contribution rules have changed — verify current terms.",
        "benefits": "Fixed minimum pension of ₹1,000–₹5,000/month from age 60 depending on contribution tier.",
        "interest_or_return": "Defined pension (not an interest product)",
        "lock_in_period": "Till age 60",
        "official_portal_url": "https://www.npscra.nsdl.co.in/apy.php",
    },
    {
        "name": "Senior Citizens Savings Scheme (SCSS)",
        "department": "Ministry of Finance / India Post & authorised banks",
        "description": "Savings scheme for resident individuals aged 60+ (or eligible early retirees) with quarterly interest payout.",
        "eligibility_min_age": 60,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "Early entry at 55+ allowed for VRS/superannuation in specific cases. Aggregate deposit cap applies (verify current limit on portal).",
        "benefits": "Quarterly interest; 80C deduction on deposit; senior-friendly fixed return.",
        "interest_or_return": "~8.2% p.a. (quarterly notified rate — verify current)",
        "lock_in_period": "5 years (extendable once by 3 years)",
        "official_portal_url": "https://www.indiapost.gov.in/Financial/Pages/Content/Senior-Citizens-Savings-Scheme.aspx",
    },
    {
        "name": "Sukanya Samriddhi Yojana (SSY)",
        "department": "Ministry of Finance / India Post & authorised banks",
        "description": "Small-deposit scheme for the girl child with tax benefits, intended for education/marriage expenses.",
        "eligibility_min_age": None,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "female",
        "eligibility_category": "any",
        "eligibility_notes": "Account opened by guardian for a girl child aged below 10 years at account opening. One account per eligible girl child. Age of the beneficiary child is not stored in this app's profile — verify on portal.",
        "benefits": "80C deduction; tax-free maturity; higher notified interest vs many small-savings schemes.",
        "interest_or_return": "~8.2% p.a. (quarterly notified rate — verify current)",
        "lock_in_period": "21 years from account opening (partial withdrawal rules apply)",
        "official_portal_url": "https://www.indiapost.gov.in/Financial/Pages/Content/Sukanya-Samriddhi-Account.aspx",
    },
    {
        "name": "Sovereign Gold Bond (SGB) Scheme",
        "department": "Ministry of Finance / RBI",
        "description": "Government securities denominated in grams of gold, issued in periodic tranches.",
        "eligibility_min_age": 18,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "Resident individuals, HUFs, trusts, and others as notified. Issuance is tranche-based — not continuously open. Check current tranche dates on RBI portal.",
        "benefits": "2.5% p.a. interest on initial investment; capital gains tax benefits if held to maturity.",
        "interest_or_return": "2.5% p.a. + gold price linked redemption",
        "lock_in_period": "8 years (early exit from 5th year on interest dates)",
        "official_portal_url": "https://www.rbi.org.in/Scripts/BS_ViewMas.aspx?masid=521",
    },
    {
        "name": "Pradhan Mantri Jeevan Jyoti Bima Yojana (PMJJBY)",
        "department": "Ministry of Finance / LIC (implementing agency)",
        "description": "Renewable term life insurance scheme offering ₹2 lakh cover for a low annual premium.",
        "eligibility_min_age": 18,
        "eligibility_max_age": 50,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "Must have an active savings bank account and consent for auto-debit. Aadhaar-linked account typically required.",
        "benefits": "₹2 lakh life cover for nominal annual premium; auto-renewable yearly.",
        "interest_or_return": None,
        "lock_in_period": "1 year (auto-renewable)",
        "official_portal_url": "https://financialservices.gov.in/beta/en/page/pmjjby",
    },
    {
        "name": "Pradhan Mantri Suraksha Bima Yojana (PMSBY)",
        "department": "Ministry of Finance",
        "description": "Accident insurance scheme offering ₹2 lakh accidental death/disability cover.",
        "eligibility_min_age": 18,
        "eligibility_max_age": 70,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": "Must have an active savings bank account and consent for auto-debit.",
        "benefits": "₹2 lakh accidental death/total disability; ₹1 lakh partial disability cover.",
        "interest_or_return": None,
        "lock_in_period": "1 year (auto-renewable)",
        "official_portal_url": "https://financialservices.gov.in/beta/en/page/pmsby",
    },
    {
        "name": "Pradhan Mantri Vaya Vandana Yojana (PMVVY)",
        "department": "Ministry of Finance / LIC",
        "description": "Pension scheme for senior citizens that provided assured returns — retained for registry transparency.",
        "eligibility_min_age": 60,
        "eligibility_max_age": None,
        "eligibility_min_income": None,
        "eligibility_max_income": None,
        "eligibility_occupation": "any",
        "eligibility_gender": "any",
        "eligibility_category": "any",
        "eligibility_notes": (
            "CLOSED for new subscriptions since March 31, 2023 — fresh applications are not accepted. "
            "Existing policyholders continue until term end. "
            "For new senior-citizen fixed-income investment, see Senior Citizens Savings Scheme (SCSS) as the active alternative."
        ),
        "benefits": "Was: assured pension for 10 years (historical — closed to new enrollment).",
        "interest_or_return": "Was: up to ~7.4% p.a. (historical — closed to new enrollment)",
        "lock_in_period": "10 years (for existing policies)",
        "official_portal_url": "https://financialservices.gov.in/beta/en/page/pmvvy",
    },
]


def seed_government_schemes(db: Session) -> None:
    if db.query(GovernmentScheme).count() > 0:
        return

    curated_date = datetime(2026, 8, 1, tzinfo=timezone.utc)
    for item in SCHEME_SEED_DATA:
        db.add(GovernmentScheme(**item, last_updated=curated_date, is_active=True))
    db.commit()
