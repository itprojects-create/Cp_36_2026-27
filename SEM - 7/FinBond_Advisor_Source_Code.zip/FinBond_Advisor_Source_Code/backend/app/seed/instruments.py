"""
DEMO DATA — manually curated instrument registry for academic demo purposes.
Values (CAGR, expense ratio) are approximate and NOT fetched from live market APIs.
Last curated: 2024-08-01
"""

from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.models import InstrumentCategory, InvestmentInstrument

# fmt: off
INSTRUMENT_SEED_DATA = [
    # Debt / G-Sec
    {"name": "SBI Magnum Gilt Fund", "category": InstrumentCategory.DEBT, "subtype": "Gilt", "amfi_code": "119707", "cagr_3y": 8.5, "expense_ratio": 0.68, "risk_level": 2, "liquidity": "T+1", "minimum_investment": 500},
    {"name": "HDFC Corporate Bond Fund", "category": InstrumentCategory.DEBT, "subtype": "Corporate Bond", "amfi_code": "118284", "cagr_3y": 7.8, "expense_ratio": 0.42, "risk_level": 2, "liquidity": "T+1", "minimum_investment": 500},
    {"name": "ICICI Prudential Liquid Fund", "category": InstrumentCategory.DEBT, "subtype": "Liquid", "amfi_code": "120586", "cagr_3y": 6.2, "expense_ratio": 0.20, "risk_level": 1, "liquidity": "T+0", "minimum_investment": 500},
    {"name": "Axis Banking & PSU Debt Fund", "category": InstrumentCategory.DEBT, "subtype": "Banking & PSU", "amfi_code": "128954", "cagr_3y": 7.5, "expense_ratio": 0.35, "risk_level": 2, "liquidity": "T+1", "minimum_investment": 500},
    # Large Cap
    {"name": "Mirae Asset Large Cap Fund", "category": InstrumentCategory.LARGE_CAP, "subtype": "Large Cap", "amfi_code": "118834", "cagr_3y": 14.2, "expense_ratio": 0.50, "risk_level": 3, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Nippon India Large Cap Fund", "category": InstrumentCategory.LARGE_CAP, "subtype": "Large Cap", "amfi_code": "100033", "cagr_3y": 13.8, "expense_ratio": 0.68, "risk_level": 3, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "UTI Nifty 50 Index Fund", "category": InstrumentCategory.LARGE_CAP, "subtype": "Index", "amfi_code": "120716", "cagr_3y": 12.5, "expense_ratio": 0.20, "risk_level": 3, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Canara Robeco Large Cap Fund", "category": InstrumentCategory.LARGE_CAP, "subtype": "Large Cap", "amfi_code": "113221", "cagr_3y": 13.1, "expense_ratio": 0.55, "risk_level": 3, "liquidity": "T+3", "minimum_investment": 500},
    # Mid Cap
    {"name": "HDFC Mid-Cap Opportunities Fund", "category": InstrumentCategory.MID_CAP, "subtype": "Mid Cap", "amfi_code": "118989", "cagr_3y": 18.5, "expense_ratio": 0.76, "risk_level": 4, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Kotak Emerging Equity Fund", "category": InstrumentCategory.MID_CAP, "subtype": "Mid Cap", "amfi_code": "100646", "cagr_3y": 17.2, "expense_ratio": 0.58, "risk_level": 4, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Axis Midcap Fund", "category": InstrumentCategory.MID_CAP, "subtype": "Mid Cap", "amfi_code": "120505", "cagr_3y": 16.8, "expense_ratio": 0.55, "risk_level": 4, "liquidity": "T+3", "minimum_investment": 500},
    # Small Cap
    {"name": "Nippon India Small Cap Fund", "category": InstrumentCategory.SMALL_CAP, "subtype": "Small Cap", "amfi_code": "118778", "cagr_3y": 22.1, "expense_ratio": 0.85, "risk_level": 5, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "SBI Small Cap Fund", "category": InstrumentCategory.SMALL_CAP, "subtype": "Small Cap", "amfi_code": "125497", "cagr_3y": 20.5, "expense_ratio": 0.72, "risk_level": 5, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Quant Small Cap Fund", "category": InstrumentCategory.SMALL_CAP, "subtype": "Small Cap", "amfi_code": "120828", "cagr_3y": 24.0, "expense_ratio": 0.62, "risk_level": 5, "liquidity": "T+3", "minimum_investment": 500},
    # Gold
    {"name": "Nippon India Gold ETF", "category": InstrumentCategory.GOLD, "subtype": "Gold ETF", "ticker": "GOLDBEES", "amfi_code": "115132", "cagr_3y": 11.5, "expense_ratio": 0.55, "risk_level": 3, "liquidity": "Exchange traded", "minimum_investment": 1000},
    {"name": "HDFC Gold ETF", "category": InstrumentCategory.GOLD, "subtype": "Gold ETF", "ticker": "HDFCGOLD", "amfi_code": "113049", "cagr_3y": 11.2, "expense_ratio": 0.50, "risk_level": 3, "liquidity": "Exchange traded", "minimum_investment": 1000},
    # ETF / Index
    {"name": "Motilal Oswal Nifty 500 Index Fund", "category": InstrumentCategory.ETF, "subtype": "Broad Index", "amfi_code": "147946", "cagr_3y": 13.0, "expense_ratio": 0.20, "risk_level": 3, "liquidity": "T+3", "minimum_investment": 500},
    {"name": "Bharat 22 ETF", "category": InstrumentCategory.ETF, "subtype": "PSU ETF", "ticker": "BHARAT22", "amfi_code": "141957", "cagr_3y": 10.5, "expense_ratio": 0.07, "risk_level": 3, "liquidity": "Exchange traded", "minimum_investment": 1000},
    {"name": "Nippon India Nifty Next 50 Index Fund", "category": InstrumentCategory.ETF, "subtype": "Index", "amfi_code": "147727", "cagr_3y": 14.5, "expense_ratio": 0.25, "risk_level": 4, "liquidity": "T+3", "minimum_investment": 500},
]
# fmt: on


def seed_instruments(db: Session) -> None:
    if db.query(InvestmentInstrument).count() > 0:
        return

    curated_date = datetime(2024, 8, 1, tzinfo=timezone.utc)
    for item in INSTRUMENT_SEED_DATA:
        db.add(
            InvestmentInstrument(
                **item,
                source="Manually curated for academic demo — not live market data",
                last_updated=curated_date,
            )
        )
    db.commit()
