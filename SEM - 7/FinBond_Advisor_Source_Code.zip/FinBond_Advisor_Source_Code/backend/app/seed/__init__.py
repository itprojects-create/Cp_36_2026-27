from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import get_password_hash
from app.models import User, UserRole
from app.seed.government_schemes import seed_government_schemes
from app.seed.instruments import seed_instruments


def seed_admin(db: Session) -> None:
    existing = db.query(User).filter(User.email == settings.ADMIN_EMAIL).first()
    if existing:
        return
    admin = User(
        email=settings.ADMIN_EMAIL,
        password_hash=get_password_hash(settings.ADMIN_PASSWORD),
        role=UserRole.ADMIN,
        is_active=True,
        disclaimer_accepted_at=datetime.now(timezone.utc),
    )
    db.add(admin)
    db.commit()


def run_seed(db: Session) -> None:
    seed_admin(db)
    seed_instruments(db)
    seed_government_schemes(db)
