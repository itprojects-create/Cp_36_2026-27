from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import admin, assistant, auth, insights, market, recommend, recommend_v2, schemes, user
from app.core.config import settings
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.market.refresh_scheduler import start_market_scheduler, stop_market_scheduler
from app.seed import run_seed

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
        force=True,
    )
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        run_seed(db)
    finally:
        db.close()

    yf_task = amfi_task = None
    if settings.MARKET_REFRESH_ENABLED:
        yf_task, amfi_task = await start_market_scheduler()
    else:
        logger.warning(
            "MARKET_REFRESH_ENABLED=false — market scheduler not started; "
            "Market Pulse will serve cache only (stale/unavailable if empty)"
        )

    yield

    if settings.MARKET_REFRESH_ENABLED:
        await stop_market_scheduler(yf_task, amfi_task)


app = FastAPI(
    title="FinBond Advisor API",
    description="Financial planning and investment recommendation system (rule-based + ML + market pulse)",
    version="5.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_PREFIX = "/api/v1"

app.include_router(auth.router, prefix=API_PREFIX)
app.include_router(user.router, prefix=API_PREFIX)
app.include_router(recommend.router, prefix=API_PREFIX)
app.include_router(admin.router, prefix=API_PREFIX)
app.include_router(recommend_v2.router, prefix="/api/v2")
app.include_router(market.router, prefix="/api")
app.include_router(insights.router, prefix="/api")
app.include_router(schemes.router, prefix="/api")
app.include_router(assistant.router, prefix="/api")


@app.get("/health")
def health_check():
    return {"status": "ok", "service": "finbond-advisor", "version": "5.0.0"}
