from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserRole(str, Enum):
    USER = "user"
    ADMIN = "admin"


class GoalType(str, Enum):
    RETIREMENT = "retirement"
    HOUSE = "house"
    CAR = "car"
    EDUCATION = "education"
    WEALTH_CREATION = "wealth_creation"
    EMERGENCY = "emergency"


class InvestmentExperience(str, Enum):
    NONE = "none"
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class RiskCategory(str, Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"


class InstrumentCategory(str, Enum):
    DEBT = "Debt"
    LARGE_CAP = "Large Cap"
    MID_CAP = "Mid Cap"
    SMALL_CAP = "Small Cap"
    GOLD = "Gold"
    ETF = "ETF"


# Auth
class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    role: UserRole
    is_active: bool
    disclaimer_accepted_at: datetime | None
    created_at: datetime
    has_profile: bool = False
    has_goals: bool = False
    has_risk_assessment: bool = False


# Profile
class UserProfileCreate(BaseModel):
    age: int = Field(ge=18, le=100)
    occupation: str = Field(min_length=1, max_length=255)
    dependents: int = Field(ge=0, le=20)
    monthly_income: float = Field(gt=0)
    monthly_expenses: float = Field(ge=0)
    savings: float = Field(ge=0)
    existing_investments: float = Field(ge=0)
    emergency_fund_months: float = Field(ge=0, le=24)
    emi: float = Field(ge=0)
    monthly_sip: float = Field(ge=0, default=0)
    investment_experience: InvestmentExperience


class UserProfileResponse(UserProfileCreate):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    derived_features: dict | None = None


class DisclaimerAccept(BaseModel):
    accepted: bool = True


# Goals
class FinancialGoalCreate(BaseModel):
    goal_type: GoalType
    target_amount: float = Field(gt=0)
    target_year: int = Field(ge=2024, le=2070)
    priority: int = Field(ge=1, le=5, default=1)
    current_saved: float = Field(ge=0, default=0)


class FinancialGoalResponse(FinancialGoalCreate):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int


class GoalsSubmit(BaseModel):
    goals: list[FinancialGoalCreate] = Field(min_length=1)


# Risk
class RiskAssessmentSubmit(BaseModel):
    responses: dict[str, int] = Field(min_length=8)


class RiskAssessmentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    responses: dict
    risk_score: float
    risk_category: RiskCategory
    created_at: datetime


# Instruments
class InstrumentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    category: InstrumentCategory
    subtype: str | None = None
    ticker: str | None = None
    amfi_code: str | None = None
    cagr_3y: float | None = None
    expense_ratio: float | None = None
    risk_level: int = Field(ge=1, le=5, default=3)
    liquidity: str | None = None
    minimum_investment: float = Field(ge=0, default=500)
    is_active: bool = True
    source: str = "Manually curated for academic demo"


class InstrumentUpdate(BaseModel):
    name: str | None = None
    category: InstrumentCategory | None = None
    subtype: str | None = None
    ticker: str | None = None
    amfi_code: str | None = None
    cagr_3y: float | None = None
    expense_ratio: float | None = None
    risk_level: int | None = Field(default=None, ge=1, le=5)
    liquidity: str | None = None
    minimum_investment: float | None = Field(default=None, ge=0)
    is_active: bool | None = None
    source: str | None = None


class InstrumentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: InstrumentCategory
    subtype: str | None
    ticker: str | None
    amfi_code: str | None
    cagr_3y: float | None
    expense_ratio: float | None
    risk_level: int
    liquidity: str | None
    minimum_investment: float | None
    is_active: bool
    source: str
    last_updated: datetime


# Recommendations
class RecommendRequest(BaseModel):
    investable_amount: float | None = None


class InstrumentRecommendation(BaseModel):
    name: str
    cagr_3y: float | None
    expense_ratio: float | None
    allocation_pct: float
    amount: float
    reason: str


class PortfolioSegment(BaseModel):
    segment: str
    allocation_pct: float
    amount: float
    instruments: list[InstrumentRecommendation]


class RecommendationOutput(BaseModel):
    engine: str = "rule_based"
    risk: dict
    portfolio: list[PortfolioSegment]
    explanation: str
    disclaimer: str


class RecommendationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    generated_at: datetime
    input_snapshot: dict
    allocation: dict
    explanation: str


# Admin
class AdminUserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    role: UserRole
    is_active: bool
    created_at: datetime
    disclaimer_accepted_at: datetime | None


class UserToggleResponse(BaseModel):
    id: int
    is_active: bool
    message: str


class ModelMetricsResponse(BaseModel):
    version: str
    engine: str
    training_date: str
    dataset_size: int | None = None
    noise_std_used: float | None = None
    feature_columns: list[str] = []
    target_columns: list[str] = []
    metrics: dict = {}
    model_file: str
    status: str = "active"


# Government schemes (Phase 5)
class GovernmentSchemeCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    department: str = Field(min_length=1, max_length=255)
    description: str = Field(min_length=1)
    eligibility_min_age: int | None = Field(default=None, ge=0, le=120)
    eligibility_max_age: int | None = Field(default=None, ge=0, le=120)
    eligibility_min_income: float | None = Field(default=None, ge=0)
    eligibility_max_income: float | None = Field(default=None, ge=0)
    eligibility_occupation: str | None = None
    eligibility_gender: str | None = None
    eligibility_category: str | None = None
    eligibility_notes: str | None = None
    benefits: str = Field(min_length=1)
    interest_or_return: str | None = None
    lock_in_period: str | None = None
    official_portal_url: str = Field(min_length=1, max_length=500)
    is_active: bool = True


class GovernmentSchemeUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    department: str | None = None
    description: str | None = None
    eligibility_min_age: int | None = None
    eligibility_max_age: int | None = None
    eligibility_min_income: float | None = None
    eligibility_max_income: float | None = None
    eligibility_occupation: str | None = None
    eligibility_gender: str | None = None
    eligibility_category: str | None = None
    eligibility_notes: str | None = None
    benefits: str | None = None
    interest_or_return: str | None = None
    lock_in_period: str | None = None
    official_portal_url: str | None = None
    is_active: bool | None = None


class GovernmentSchemeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    department: str
    description: str
    eligibility_min_age: int | None
    eligibility_max_age: int | None
    eligibility_min_income: float | None
    eligibility_max_income: float | None
    eligibility_occupation: str | None
    eligibility_gender: str | None
    eligibility_category: str | None
    eligibility_notes: str | None
    benefits: str
    interest_or_return: str | None
    lock_in_period: str | None
    official_portal_url: str
    source: str
    last_updated: datetime
    is_active: bool


class SchemeEligibilityItem(BaseModel):
    scheme_id: int
    scheme_name: str
    classification: str
    reason: str
    official_portal_url: str
    verify_notice: str


class SchemeEligibilityResponse(BaseModel):
    results: list[SchemeEligibilityItem]
    disclaimer: str = (
        "Eligibility classifications are a screening aid based on stored profile data only — "
        "not a legal determination. Verify eligibility on the official government portal before applying."
    )


# Help assistant (rule-based FAQ)
class AssistantAskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=500)


class AssistantResponseSchema(BaseModel):
    answer: str
    category: str
    matched: bool
    label: str
