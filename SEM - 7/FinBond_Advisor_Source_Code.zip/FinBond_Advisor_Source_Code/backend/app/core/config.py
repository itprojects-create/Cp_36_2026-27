from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    DATABASE_URL: str = "sqlite:///./finbond.db"
    SECRET_KEY: str = "dev-secret-key-change-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    ALGORITHM: str = "HS256"

    ADMIN_EMAIL: str = "admin@finbond.demo"
    ADMIN_PASSWORD: str = "Admin@FinBond2024"

    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    YFINANCE_REFRESH_MINUTES: int = 30
    AMFI_REFRESH_HOURS: int = 24
    MARKET_DATA_STALE_MINUTES: int = 60
    MARKET_REFRESH_ENABLED: bool = True

    CRASH_TIER_MILD_PCT: float = 5.0
    CRASH_TIER_DEEP_PCT: float = 10.0
    CRASH_TIER_MAJOR_PCT: float = 15.0
    REBALANCE_DRIFT_THRESHOLD_PP: float = 5.0

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]


settings = Settings()
