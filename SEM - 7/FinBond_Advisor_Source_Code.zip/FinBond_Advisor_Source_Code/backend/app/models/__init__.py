import enum
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum, Float, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import JSON

from app.db.base import Base


class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"


class GoalType(str, enum.Enum):
    RETIREMENT = "retirement"
    HOUSE = "house"
    CAR = "car"
    EDUCATION = "education"
    WEALTH_CREATION = "wealth_creation"
    EMERGENCY = "emergency"


class InvestmentExperience(str, enum.Enum):
    NONE = "none"
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class RiskCategory(str, enum.Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"


class InstrumentCategory(str, enum.Enum):
    DEBT = "Debt"
    LARGE_CAP = "Large Cap"
    MID_CAP = "Mid Cap"
    SMALL_CAP = "Small Cap"
    GOLD = "Gold"
    ETF = "ETF"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.USER, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    disclaimer_accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    profile: Mapped["UserProfile | None"] = relationship(back_populates="user", uselist=False)
    goals: Mapped[list["FinancialGoal"]] = relationship(back_populates="user")
    risk_assessments: Mapped[list["RiskAssessment"]] = relationship(back_populates="user")
    recommendations: Mapped[list["Recommendation"]] = relationship(back_populates="user")


class UserProfile(Base):
    __tablename__ = "user_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True, nullable=False)
    age: Mapped[int | None] = mapped_column(Integer, nullable=True)
    occupation: Mapped[str | None] = mapped_column(String(255), nullable=True)
    dependents: Mapped[int | None] = mapped_column(Integer, default=0)
    monthly_income: Mapped[float | None] = mapped_column(Float, nullable=True)
    monthly_expenses: Mapped[float | None] = mapped_column(Float, nullable=True)
    savings: Mapped[float | None] = mapped_column(Float, default=0.0)
    existing_investments: Mapped[float | None] = mapped_column(Float, default=0.0)
    emergency_fund_months: Mapped[float | None] = mapped_column(Float, default=0.0)
    emi: Mapped[float | None] = mapped_column(Float, default=0.0)
    monthly_sip: Mapped[float | None] = mapped_column(Float, default=0.0)
    investment_experience: Mapped[InvestmentExperience | None] = mapped_column(
        Enum(InvestmentExperience), nullable=True
    )

    user: Mapped["User"] = relationship(back_populates="profile")


class FinancialGoal(Base):
    __tablename__ = "financial_goals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    goal_type: Mapped[GoalType] = mapped_column(Enum(GoalType), nullable=False)
    target_amount: Mapped[float] = mapped_column(Float, nullable=False)
    target_year: Mapped[int] = mapped_column(Integer, nullable=False)
    priority: Mapped[int] = mapped_column(Integer, default=1)
    current_saved: Mapped[float] = mapped_column(Float, default=0.0)

    user: Mapped["User"] = relationship(back_populates="goals")


class RiskAssessment(Base):
    __tablename__ = "risk_assessments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    responses: Mapped[dict] = mapped_column(JSON, nullable=False)
    risk_score: Mapped[float] = mapped_column(Float, nullable=False)
    risk_category: Mapped[RiskCategory] = mapped_column(Enum(RiskCategory), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="risk_assessments")


class InvestmentInstrument(Base):
    __tablename__ = "investment_instruments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    category: Mapped[InstrumentCategory] = mapped_column(Enum(InstrumentCategory), nullable=False)
    subtype: Mapped[str | None] = mapped_column(String(100), nullable=True)
    ticker: Mapped[str | None] = mapped_column(String(50), nullable=True)
    amfi_code: Mapped[str | None] = mapped_column(String(20), nullable=True)
    cagr_3y: Mapped[float | None] = mapped_column(Float, nullable=True)
    expense_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk_level: Mapped[int] = mapped_column(Integer, default=3)
    liquidity: Mapped[str | None] = mapped_column(String(50), nullable=True)
    minimum_investment: Mapped[float | None] = mapped_column(Float, default=500.0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    source: Mapped[str] = mapped_column(
        String(255),
        default="Manually curated for academic demo",
        nullable=False,
    )
    last_updated: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    __table_args__ = (
        # DEMO DATA — instrument metrics are manually curated, not fetched from live APIs.
    )


class Recommendation(Base):
    __tablename__ = "recommendations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    generated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    input_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False)
    allocation: Mapped[dict] = mapped_column(JSON, nullable=False)
    explanation: Mapped[str] = mapped_column(Text, nullable=False)

    user: Mapped["User"] = relationship(back_populates="recommendations")


class MarketSnapshot(Base):
    __tablename__ = "market_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    symbol: Mapped[str] = mapped_column(String(50), index=True, nullable=False)
    source: Mapped[str] = mapped_column(String(50), nullable=False)
    value: Mapped[float | None] = mapped_column(Float, nullable=True)
    meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    fetch_success: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class MarketFetchLog(Base):
    __tablename__ = "market_fetch_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    source: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_attempt_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    used_stale_fallback: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class GsecYieldSetting(Base):
    __tablename__ = "gsec_yield_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    yield_pct: Mapped[float] = mapped_column(Float, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_by_admin_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class GovernmentScheme(Base):
    __tablename__ = "government_schemes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    department: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    eligibility_min_age: Mapped[int | None] = mapped_column(Integer, nullable=True)
    eligibility_max_age: Mapped[int | None] = mapped_column(Integer, nullable=True)
    eligibility_min_income: Mapped[float | None] = mapped_column(Float, nullable=True)
    eligibility_max_income: Mapped[float | None] = mapped_column(Float, nullable=True)
    eligibility_occupation: Mapped[str | None] = mapped_column(String(50), nullable=True)
    eligibility_gender: Mapped[str | None] = mapped_column(String(20), nullable=True)
    eligibility_category: Mapped[str | None] = mapped_column(String(50), nullable=True)
    eligibility_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    benefits: Mapped[str] = mapped_column(Text, nullable=False)
    interest_or_return: Mapped[str | None] = mapped_column(String(100), nullable=True)
    lock_in_period: Mapped[str | None] = mapped_column(String(100), nullable=True)
    official_portal_url: Mapped[str] = mapped_column(String(500), nullable=False)
    source: Mapped[str] = mapped_column(
        String(255),
        default="Manually curated for academic demo",
        nullable=False,
    )
    last_updated: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
