"""Configurable crash/dip engine thresholds and risk-adjusted deployment tables."""

from app.models import RiskCategory

# Drawdown tiers (from Nifty 52-week high — sourced from Phase 3 cache, not recomputed)
CRASH_TIER_MILD_PCT = 5.0
CRASH_TIER_DEEP_PCT = 10.0
CRASH_TIER_MAJOR_PCT = 15.0

# Rebalancing drift threshold (percentage points)
REBALANCE_DRIFT_THRESHOLD_PP = 5.0

CRASH_DISCLAIMER = (
    "Phased deployment suggestion only — not a prediction of market direction or a bottom call. "
    "Markets can continue declining after a correction begins. "
    "Decision-support platform; does not execute trades. "
    "Consult registered professionals before investing."
)

# % of available cash to suggest deploying per correction tier × risk category.
# Capped below 100% intentionally — phased deployment, never all-in at once.
DEPLOYMENT_PCT: dict[str, dict[RiskCategory, float]] = {
    "mild": {RiskCategory.LOW: 10.0, RiskCategory.MODERATE: 20.0, RiskCategory.HIGH: 30.0},
    "deep": {RiskCategory.LOW: 15.0, RiskCategory.MODERATE: 30.0, RiskCategory.HIGH: 40.0},
    "major": {RiskCategory.LOW: 20.0, RiskCategory.MODERATE: 40.0, RiskCategory.HIGH: 50.0},
}

# Segment split for the suggested deployment portion (sums to 100 per tier × risk).
CRASH_SEGMENT_SPLITS: dict[str, dict[RiskCategory, dict[str, float]]] = {
    "mild": {
        RiskCategory.LOW: {
            "G-Sec/Debt": 45.0,
            "Gold": 25.0,
            "Large Cap": 15.0,
            "ETF": 10.0,
            "Mid Cap": 5.0,
            "Small Cap": 0.0,
        },
        RiskCategory.MODERATE: {
            "G-Sec/Debt": 30.0,
            "Large Cap": 30.0,
            "ETF": 15.0,
            "Gold": 15.0,
            "Mid Cap": 10.0,
            "Small Cap": 0.0,
        },
        RiskCategory.HIGH: {
            "Large Cap": 35.0,
            "ETF": 20.0,
            "Mid Cap": 20.0,
            "G-Sec/Debt": 15.0,
            "Gold": 10.0,
            "Small Cap": 0.0,
        },
    },
    "deep": {
        RiskCategory.LOW: {
            "G-Sec/Debt": 40.0,
            "Gold": 25.0,
            "Large Cap": 20.0,
            "ETF": 10.0,
            "Mid Cap": 5.0,
            "Small Cap": 0.0,
        },
        RiskCategory.MODERATE: {
            "G-Sec/Debt": 25.0,
            "Large Cap": 30.0,
            "Mid Cap": 15.0,
            "ETF": 15.0,
            "Gold": 15.0,
            "Small Cap": 0.0,
        },
        RiskCategory.HIGH: {
            "Large Cap": 35.0,
            "Mid Cap": 25.0,
            "ETF": 20.0,
            "G-Sec/Debt": 10.0,
            "Gold": 10.0,
            "Small Cap": 0.0,
        },
    },
    "major": {
        RiskCategory.LOW: {
            "G-Sec/Debt": 40.0,
            "Gold": 30.0,
            "Large Cap": 20.0,
            "ETF": 5.0,
            "Mid Cap": 5.0,
            "Small Cap": 0.0,
        },
        RiskCategory.MODERATE: {
            "G-Sec/Debt": 20.0,
            "Large Cap": 30.0,
            "Mid Cap": 20.0,
            "ETF": 15.0,
            "Gold": 15.0,
            "Small Cap": 0.0,
        },
        RiskCategory.HIGH: {
            "Large Cap": 35.0,
            "Mid Cap": 25.0,
            "Small Cap": 10.0,
            "ETF": 15.0,
            "G-Sec/Debt": 10.0,
            "Gold": 5.0,
        },
    },
}

REBALANCE_ASSUMPTION = (
    "Current allocation is approximated from your previous recommendation's target "
    "(stored snapshot). This project does not track real brokerage holdings — "
    "rebalancing suggestions compare recommendation history, not live portfolio positions."
)
