"""Fetch and parse AMFI daily NAV file for registry instruments."""

from __future__ import annotations

import io
import logging
import re

import httpx

from app.market.constants import AMFI_NAV_URL

logger = logging.getLogger(__name__)


def _parse_amfi_nav_text(content: str) -> dict[str, dict]:
    """Parse AMFI NAVAll.txt into {amfi_code: {nav, nav_date, scheme_name}}."""
    results: dict[str, dict] = {}
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("Scheme Code") or line.startswith("Open Ended"):
            continue
        parts = [p.strip() for p in line.split(";")]
        if len(parts) < 5:
            continue
        code = parts[0]
        if not re.match(r"^\d+$", code):
            continue
        try:
            nav = float(parts[4]) if parts[4] else None
        except ValueError:
            nav = None
        results[code] = {
            "nav": nav,
            "nav_date": parts[7] if len(parts) > 7 else None,
            "scheme_name": parts[3] if len(parts) > 3 else None,
        }
    return results


def fetch_amfi_navs(amfi_codes: list[str]) -> dict[str, dict | None]:
    """
    Download AMFI NAV file and extract NAVs for given scheme codes.
    Returns {amfi_code: {nav, nav_date, scheme_name}} or None per code on failure.
    """
    if not amfi_codes:
        return {}

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.get(AMFI_NAV_URL)
            response.raise_for_status()
        parsed = _parse_amfi_nav_text(response.text)
        return {
            code: parsed.get(code)
            for code in amfi_codes
        }
    except Exception as exc:
        logger.exception("AMFI NAV fetch failed: %s", exc)
        return {code: None for code in amfi_codes}
