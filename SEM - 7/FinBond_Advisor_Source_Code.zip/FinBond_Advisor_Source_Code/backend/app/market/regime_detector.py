"""
Market regime classifier — rule-based thresholds (not ML).

Simplified academic-project thresholds — not validated trading signals.
"""

from dataclasses import dataclass
from enum import Enum

from app.market.constants import (
    CRUDE_TREND_BEARISH_PCT,
    DRAWDOWN_BEAR_MAX,
    DRAWDOWN_BULL_MAX,
    DRAWDOWN_SIDEWAYS_MAX,
    REGIME_DISCLAIMER,
    VIX_HIGH,
    VIX_MODERATE,
)


class MarketRegime(str, Enum):
    BULL = "BULL"
    SIDEWAYS = "SIDEWAYS"
    BEAR = "BEAR"
    CRASH = "CRASH"


@dataclass
class RegimeResult:
    regime: MarketRegime
    classification_basis: str
    inputs: dict
    disclaimer: str = REGIME_DISCLAIMER


def classify_regime(
    nifty_drawdown_pct: float | None,
    india_vix: float | None,
    crude_change_30d_pct: float | None,
    nifty_trend_up: bool = False,
) -> RegimeResult:
    drawdown = nifty_drawdown_pct if nifty_drawdown_pct is not None else 0.0
    vix = india_vix if india_vix is not None else 0.0
    crude_chg = crude_change_30d_pct if crude_change_30d_pct is not None else 0.0

    inputs = {
        "nifty_drawdown_pct": drawdown,
        "india_vix": vix,
        "crude_change_30d_pct": crude_chg,
        "nifty_trend_up": nifty_trend_up,
    }

    if drawdown >= DRAWDOWN_BEAR_MAX or vix >= VIX_HIGH:
        regime = MarketRegime.CRASH
        basis = (
            f"The market is currently classified as CRASH — Nifty is {drawdown:.1f}% below its "
            f"52-week high with India VIX at {vix:.1f}."
        )
    elif drawdown >= DRAWDOWN_SIDEWAYS_MAX or (vix >= VIX_MODERATE and crude_chg >= CRUDE_TREND_BEARISH_PCT):
        regime = MarketRegime.BEAR
        basis = (
            f"The market is currently classified as BEAR — Nifty is {drawdown:.1f}% below its "
            f"52-week high with India VIX at {vix:.1f} and crude oil 30-day change at {crude_chg:.1f}%."
        )
    elif drawdown < DRAWDOWN_BULL_MAX and vix < VIX_MODERATE and nifty_trend_up:
        regime = MarketRegime.BULL
        basis = (
            f"The market is currently classified as BULL — Nifty is {drawdown:.1f}% below its "
            f"52-week high with India VIX at a moderate {vix:.1f} and a positive recent trend."
        )
    else:
        regime = MarketRegime.SIDEWAYS
        basis = (
            f"The market is currently classified as SIDEWAYS — Nifty is {drawdown:.1f}% below its "
            f"52-week high with India VIX at a moderate {vix:.1f}."
        )

    return RegimeResult(regime=regime, classification_basis=basis, inputs=inputs)
