"""Market data cache read/write and staleness handling."""

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import MarketFetchLog, MarketSnapshot


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def get_latest_snapshot(db: Session, symbol: str) -> MarketSnapshot | None:
    return (
        db.query(MarketSnapshot)
        .filter(MarketSnapshot.symbol == symbol, MarketSnapshot.fetch_success.is_(True))
        .order_by(MarketSnapshot.fetched_at.desc())
        .first()
    )


def is_stale(fetched_at: datetime) -> bool:
    if fetched_at.tzinfo is None:
        fetched_at = fetched_at.replace(tzinfo=timezone.utc)
    age = _utcnow() - fetched_at
    return age > timedelta(minutes=settings.MARKET_DATA_STALE_MINUTES)


def save_snapshot(
    db: Session,
    symbol: str,
    source: str,
    value: float | None,
    meta: dict | None,
    fetch_success: bool,
) -> MarketSnapshot:
    row = MarketSnapshot(
        symbol=symbol,
        source=source,
        value=value,
        meta=meta or {},
        fetched_at=_utcnow(),
        fetch_success=fetch_success,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def update_fetch_log(
    db: Session,
    source: str,
    success: bool,
    error: str | None = None,
    used_stale_fallback: bool = False,
) -> None:
    log = db.query(MarketFetchLog).filter(MarketFetchLog.source == source).first()
    now = _utcnow()
    if not log:
        log = MarketFetchLog(source=source)
        db.add(log)
    log.last_attempt_at = now
    log.last_error = error
    log.used_stale_fallback = used_stale_fallback
    if success:
        log.last_success_at = now
        log.last_error = None
    db.commit()


def get_fetch_log(db: Session, source: str) -> MarketFetchLog | None:
    return db.query(MarketFetchLog).filter(MarketFetchLog.source == source).first()


def build_pulse_item(
    db: Session,
    symbol: str,
    label: str,
    source: str,
    ticker: str | None = None,
) -> dict:
    snap = get_latest_snapshot(db, symbol)
    if snap is None:
        return {
            "symbol": symbol,
            "label": label,
            "value": None,
            "source": source,
            "ticker": ticker,
            "last_updated": None,
            "is_stale": False,
            "status": "unavailable",
            "message": "No cached data available yet",
            "meta": {},
        }

    stale = is_stale(snap.fetched_at)
    return {
        "symbol": symbol,
        "label": label,
        "value": snap.value,
        "source": snap.source,
        "ticker": ticker,
        "last_updated": snap.fetched_at.isoformat(),
        "is_stale": stale,
        "status": "available",
        "message": "Serving stale cached data" if stale else None,
        "meta": snap.meta or {},
    }
