"""Pydantic schemas for market data API responses."""

from pydantic import BaseModel, Field


class MarketPulseItem(BaseModel):
    symbol: str
    label: str
    value: float | None = None
    source: str
    ticker: str | None = None
    last_updated: str | None = None
    is_stale: bool = False
    status: str
    message: str | None = None
    meta: dict = Field(default_factory=dict)


class MutualFundNavItem(BaseModel):
    instrument_id: int
    instrument_name: str
    amfi_code: str
    nav: float | None = None
    nav_date: str | None = None
    last_updated: str | None = None
    is_stale: bool = False
    status: str
    message: str | None = None


class FiiDiiStatus(BaseModel):
    status: str = "unavailable"
    message: str = "FII/DII flow data skipped — no reliable free API source available for this demo."


class MarketPulseResponse(BaseModel):
    indices: list[MarketPulseItem]
    volatility: MarketPulseItem | None = None
    commodities: list[MarketPulseItem]
    gsec_yield: MarketPulseItem
    mutual_fund_navs: list[MutualFundNavItem]
    fii_dii: FiiDiiStatus
    disclaimer: str


class MarketRegimeResponse(BaseModel):
    regime: str
    classification_basis: str
    inputs: dict
    disclaimer: str
    data_status: str
    is_stale: bool = False


class GsecYieldResponse(BaseModel):
    yield_pct: float | None = None
    updated_at: str | None = None
    status: str
    message: str | None = None


class GsecYieldUpdate(BaseModel):
    yield_pct: float = Field(..., ge=0, le=20, description="10-year G-Sec yield in percent")


class MarketSourceStatus(BaseModel):
    source: str
    last_success_at: str | None = None
    last_attempt_at: str | None = None
    last_error: str | None = None
    used_stale_fallback: bool = False


class AdminMarketStatusResponse(BaseModel):
    sources: list[MarketSourceStatus]
    note: str = "FII/DII flows are not integrated — no reliable free source for academic demo."


class ThresholdSettings(BaseModel):
    crash_tier_mild_pct: float
    crash_tier_deep_pct: float
    crash_tier_major_pct: float
    rebalance_drift_threshold_pp: float


class AdminSystemHealthResponse(BaseModel):
    market_sources: list[MarketSourceStatus]
    thresholds: ThresholdSettings
    note: str = "FII/DII flows are not integrated — no reliable free source for academic demo."


class CrashInstrumentSuggestion(BaseModel):
    name: str
    allocation_pct: float
    amount: float
    reason: str


class CrashSegmentSplit(BaseModel):
    segment: str
    allocation_pct: float
    amount: float
    instruments: list[CrashInstrumentSuggestion] = Field(default_factory=list)


class CrashSignalResponse(BaseModel):
    status: str
    drawdown_pct: float | None = None
    correction_tier: str | None = None
    deployment_pct_of_cash: float | None = None
    available_cash: float = 0.0
    suggested_deployment_amount: float | None = None
    segment_split: list[CrashSegmentSplit] = Field(default_factory=list)
    explanation: str
    disclaimer: str
    risk_category: str | None = None


class SegmentDriftItem(BaseModel):
    segment: str
    current_pct: float
    target_pct: float
    drift_pp: float
    flagged: bool
    suggestion: str | None = None


class RebalanceCheckResponse(BaseModel):
    status: str
    assumption_note: str
    drift_threshold_pp: float
    segments: list[SegmentDriftItem] = Field(default_factory=list)
    flagged_segments: list[SegmentDriftItem] = Field(default_factory=list)
    explanation: str
