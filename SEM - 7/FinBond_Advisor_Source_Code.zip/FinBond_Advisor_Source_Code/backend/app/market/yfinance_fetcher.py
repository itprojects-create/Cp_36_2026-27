"""Fetch index and commodity data via yfinance (unofficial Yahoo Finance wrapper)."""

from __future__ import annotations

import logging

import yfinance as yf

from app.market.constants import YFINANCE_TICKERS

logger = logging.getLogger(__name__)


def _safe_float(val) -> float | None:
    try:
        if val is None or val != val:  # NaN check
            return None
        return float(val)
    except (TypeError, ValueError):
        return None


def fetch_yfinance_symbol(symbol_key: str) -> dict | None:
    """
    Fetch one symbol's current value and metadata.
    Returns None on failure — caller must use cached fallback.
    """
    info = YFINANCE_TICKERS.get(symbol_key)
    if not info:
        return None

    ticker_str = info["ticker"]
    try:
        ticker = yf.Ticker(ticker_str)
        hist = ticker.history(period="1y")
        if hist.empty:
            logger.warning("yfinance returned empty history for %s (%s)", symbol_key, ticker_str)
            return None

        current = _safe_float(hist["Close"].iloc[-1])
        high_52w = _safe_float(hist["Close"].max())
        low_52w = _safe_float(hist["Close"].min())

        meta: dict = {
            "ticker": ticker_str,
            "high_52w": high_52w,
            "low_52w": low_52w,
        }

        if current and high_52w and high_52w > 0:
            meta["drawdown_from_52w_high_pct"] = round((1 - current / high_52w) * 100, 2)

        if len(hist) >= 2:
            prev = _safe_float(hist["Close"].iloc[-2])
            if current and prev and prev > 0:
                meta["change_1d_pct"] = round((current / prev - 1) * 100, 2)

        if symbol_key == "CRUDE_OIL" and len(hist) >= 22:
            past = _safe_float(hist["Close"].iloc[-22])
            if current and past and past > 0:
                meta["change_30d_pct"] = round((current / past - 1) * 100, 2)

        if symbol_key == "NIFTY50" and len(hist) >= 20:
            recent = hist["Close"].iloc[-20:]
            meta["nifty_trend_up"] = bool(recent.iloc[-1] > recent.iloc[0])

        return {
            "symbol": symbol_key,
            "value": current,
            "meta": meta,
            "source": "yfinance",
        }
    except Exception as exc:
        logger.exception("yfinance fetch failed for %s (%s): %s", symbol_key, ticker_str, exc)
        return None


def fetch_all_yfinance() -> dict[str, dict | None]:
    return {key: fetch_yfinance_symbol(key) for key in YFINANCE_TICKERS}
