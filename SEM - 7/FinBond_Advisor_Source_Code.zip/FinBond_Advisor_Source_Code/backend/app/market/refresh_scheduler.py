"""Background refresh for yfinance and AMFI market data."""

from __future__ import annotations

import asyncio
import logging

from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import SessionLocal
from app.market.amfi_fetcher import fetch_amfi_navs
from app.market.cache_service import get_latest_snapshot, save_snapshot, update_fetch_log
from app.market.yfinance_fetcher import fetch_all_yfinance
from app.models import InvestmentInstrument

logger = logging.getLogger(__name__)

_yfinance_task: asyncio.Task | None = None
_amfi_task: asyncio.Task | None = None


def refresh_yfinance(db: Session) -> None:
    logger.info("yfinance refresh started")
    results = fetch_all_yfinance()
    any_success = False
    ok_symbols: list[str] = []
    failed_symbols: list[str] = []

    for symbol_key, data in results.items():
        if data and data.get("value") is not None:
            save_snapshot(
                db,
                symbol=symbol_key,
                source="yfinance",
                value=data["value"],
                meta=data.get("meta"),
                fetch_success=True,
            )
            any_success = True
            ok_symbols.append(symbol_key)
        else:
            failed_symbols.append(symbol_key)

    stale_used = not any_success and any(
        get_latest_snapshot(db, key) is not None for key in results
    )
    update_fetch_log(
        db,
        source="yfinance",
        success=any_success,
        error=None if any_success else "All yfinance symbol fetches failed",
        used_stale_fallback=stale_used,
    )
    if any_success:
        logger.info(
            "yfinance refresh finished: ok=%s failed=%s stale_fallback=%s",
            ok_symbols,
            failed_symbols or "none",
            stale_used,
        )
    else:
        logger.warning(
            "yfinance refresh finished with no successful symbols: failed=%s stale_fallback=%s",
            failed_symbols,
            stale_used,
        )


def refresh_amfi(db: Session) -> None:
    logger.info("AMFI refresh started")
    instruments = (
        db.query(InvestmentInstrument)
        .filter(
            InvestmentInstrument.is_active.is_(True),
            InvestmentInstrument.amfi_code.isnot(None),
        )
        .all()
    )
    codes = [inst.amfi_code for inst in instruments if inst.amfi_code]
    if not codes:
        update_fetch_log(db, source="amfi", success=True)
        return

    nav_map = fetch_amfi_navs(codes)
    any_success = False

    for inst in instruments:
        if not inst.amfi_code:
            continue
        nav_data = nav_map.get(inst.amfi_code)
        symbol = f"AMFI_{inst.amfi_code}"
        if nav_data and nav_data.get("nav") is not None:
            save_snapshot(
                db,
                symbol=symbol,
                source="amfi",
                value=nav_data["nav"],
                meta={
                    "amfi_code": inst.amfi_code,
                    "instrument_name": inst.name,
                    "nav_date": nav_data.get("nav_date"),
                    "scheme_name": nav_data.get("scheme_name"),
                },
                fetch_success=True,
            )
            any_success = True

    stale_used = not any_success and any(
        get_latest_snapshot(db, f"AMFI_{c}") is not None for c in codes
    )
    update_fetch_log(
        db,
        source="amfi",
        success=any_success,
        error=None if any_success else "AMFI NAV fetch or parse failed",
        used_stale_fallback=stale_used,
    )
    logger.info(
        "AMFI refresh finished: success=%s stale_fallback=%s instruments=%s",
        any_success,
        stale_used,
        len(codes),
    )


def _run_refresh(fn) -> None:
    db = SessionLocal()
    try:
        fn(db)
    except Exception:
        logger.exception("Market refresh failed for %s", fn.__name__)
    finally:
        db.close()


async def _yfinance_loop() -> None:
    while True:
        await asyncio.to_thread(_run_refresh, refresh_yfinance)
        await asyncio.sleep(settings.YFINANCE_REFRESH_MINUTES * 60)


async def _amfi_loop() -> None:
    while True:
        await asyncio.to_thread(_run_refresh, refresh_amfi)
        await asyncio.sleep(settings.AMFI_REFRESH_HOURS * 3600)


async def start_market_scheduler() -> tuple[asyncio.Task, asyncio.Task]:
    """Run initial refresh then start interval loops."""
    logger.info(
        "Market scheduler starting (yfinance every %s min, AMFI every %s h)",
        settings.YFINANCE_REFRESH_MINUTES,
        settings.AMFI_REFRESH_HOURS,
    )
    await asyncio.to_thread(_run_refresh, refresh_yfinance)
    await asyncio.to_thread(_run_refresh, refresh_amfi)

    yf_task = asyncio.create_task(_yfinance_loop(), name="yfinance-refresh")
    amfi_task = asyncio.create_task(_amfi_loop(), name="amfi-refresh")
    logger.info("Market scheduler loops running")
    return yf_task, amfi_task


async def stop_market_scheduler(yf_task: asyncio.Task | None, amfi_task: asyncio.Task | None) -> None:
    for task in (yf_task, amfi_task):
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
