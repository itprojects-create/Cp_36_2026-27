"""
Crash/dip phased deployment engine.

Uses Nifty drawdown from Phase 3 market cache — does not recompute or alter regime logic.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.market.cache_service import get_latest_snapshot
from app.market.crash_constants import (
    CRASH_DISCLAIMER,
    CRASH_SEGMENT_SPLITS,
    CRASH_TIER_DEEP_PCT,
    CRASH_TIER_MAJOR_PCT,
    CRASH_TIER_MILD_PCT,
    DEPLOYMENT_PCT,
)
from app.market.constants import REGIME_DISCLAIMER
from app.models import InvestmentInstrument, Recommendation, RiskAssessment, RiskCategory, UserProfile
from app.recommendation.constants import SEGMENT_TO_CATEGORY
from app.recommendation.instrument_ranker import rank_instruments


@dataclass
class CrashSignalResult:
    status: str
    drawdown_pct: float | None
    correction_tier: str | None
    deployment_pct_of_cash: float | None
    available_cash: float
    suggested_deployment_amount: float | None
    segment_split: list[dict]
    explanation: str
    disclaimer: str
    risk_category: str | None = None
    is_stale: bool = False


def _classify_tier(drawdown_pct: float) -> str | None:
    if drawdown_pct < CRASH_TIER_MILD_PCT:
        return None
    if drawdown_pct < CRASH_TIER_DEEP_PCT:
        return "mild"
    if drawdown_pct < CRASH_TIER_MAJOR_PCT:
        return "deep"
    return "major"


def _resolve_available_cash(
    db: Session,
    user_id: int,
    profile: UserProfile | None,
) -> float:
    latest_rec = (
        db.query(Recommendation)
        .filter(Recommendation.user_id == user_id)
        .order_by(Recommendation.generated_at.desc())
        .first()
    )
    if latest_rec and latest_rec.input_snapshot:
        amount = latest_rec.input_snapshot.get("investable_amount")
        if amount is not None and float(amount) > 0:
            return float(amount)

    if profile:
        savings = float(profile.savings or 0)
        investments = float(profile.existing_investments or 0)
        total = savings + investments
        if total > 0:
            return total

    return 0.0


def _build_instruments_for_split(
    segment_split: dict[str, float],
    risk_category: RiskCategory,
    instruments: list[InvestmentInstrument],
    deployment_amount: float,
) -> list[dict]:
    active = [i for i in instruments if i.is_active]
    segments_out: list[dict] = []

    for segment, pct in segment_split.items():
        if pct <= 0:
            continue
        category = SEGMENT_TO_CATEGORY[segment]
        segment_instruments = [i for i in active if i.category == category]
        ranked = rank_instruments(segment_instruments, risk_category, top_n=2)
        seg_amount = round(deployment_amount * pct / 100, 2)

        instruments_out = []
        if ranked:
            per_inst = round(seg_amount / len(ranked), 2)
            for inst, _, reason in ranked:
                instruments_out.append(
                    {
                        "name": inst.name,
                        "allocation_pct": round(pct / len(ranked), 2),
                        "amount": per_inst,
                        "reason": reason,
                    }
                )

        segments_out.append(
            {
                "segment": segment,
                "allocation_pct": pct,
                "amount": seg_amount,
                "instruments": instruments_out,
            }
        )

    return segments_out


def generate_crash_signal(
    db: Session,
    user_id: int,
    profile: UserProfile | None,
    risk: RiskAssessment | None,
    instruments: list[InvestmentInstrument],
    *,
    tier_mild_pct: float = CRASH_TIER_MILD_PCT,
    tier_deep_pct: float = CRASH_TIER_DEEP_PCT,
    tier_major_pct: float = CRASH_TIER_MAJOR_PCT,
) -> CrashSignalResult:
    nifty = get_latest_snapshot(db, "NIFTY50")
    disclaimer = f"{REGIME_DISCLAIMER} {CRASH_DISCLAIMER}"

    if nifty is None or nifty.meta is None:
        return CrashSignalResult(
            status="drawdown_unavailable",
            drawdown_pct=None,
            correction_tier=None,
            deployment_pct_of_cash=None,
            available_cash=_resolve_available_cash(db, user_id, profile),
            suggested_deployment_amount=None,
            segment_split=[],
            explanation=(
                "Nifty drawdown data is not available yet — cannot assess correction status. "
                "Check Market Pulse once market data has been fetched."
            ),
            disclaimer=disclaimer,
        )

    drawdown = nifty.meta.get("drawdown_from_52w_high_pct")
    if drawdown is None:
        return CrashSignalResult(
            status="drawdown_unavailable",
            drawdown_pct=None,
            correction_tier=None,
            deployment_pct_of_cash=None,
            available_cash=_resolve_available_cash(db, user_id, profile),
            suggested_deployment_amount=None,
            segment_split=[],
            explanation="Nifty drawdown could not be read from cached market data.",
            disclaimer=disclaimer,
        )

    drawdown = float(drawdown)
    tier = _classify_tier_with_thresholds(drawdown, tier_mild_pct, tier_deep_pct, tier_major_pct)
    available_cash = _resolve_available_cash(db, user_id, profile)

    if tier is None:
        return CrashSignalResult(
            status="no_active_correction",
            drawdown_pct=drawdown,
            correction_tier=None,
            deployment_pct_of_cash=None,
            available_cash=available_cash,
            suggested_deployment_amount=None,
            segment_split=[],
            explanation=(
                f"No active market correction detected — Nifty is {drawdown:.1f}% below its 52-week high, "
                f"below the {tier_mild_pct:.0f}% threshold for phased deployment suggestions."
            ),
            disclaimer=disclaimer,
            risk_category=risk.risk_category.value if risk else None,
        )

    if not risk:
        return CrashSignalResult(
            status="risk_assessment_required",
            drawdown_pct=drawdown,
            correction_tier=tier,
            deployment_pct_of_cash=None,
            available_cash=available_cash,
            suggested_deployment_amount=None,
            segment_split=[],
            explanation=(
                f"A {tier} correction is active (Nifty {drawdown:.1f}% below 52-week high), "
                "but a risk assessment is required before generating a risk-adjusted suggestion."
            ),
            disclaimer=disclaimer,
        )

    if available_cash <= 0:
        return CrashSignalResult(
            status="insufficient_cash",
            drawdown_pct=drawdown,
            correction_tier=tier,
            deployment_pct_of_cash=None,
            available_cash=0.0,
            suggested_deployment_amount=None,
            segment_split=[],
            explanation=(
                f"A {tier} market correction is active (Nifty {drawdown:.1f}% below its 52-week high), "
                "but no deployable cash was found in your profile or latest recommendation. "
                "Update your savings/investment figures or regenerate a recommendation with an investable amount."
            ),
            disclaimer=disclaimer,
            risk_category=risk.risk_category.value,
        )

    deployment_pct = DEPLOYMENT_PCT[tier][risk.risk_category]
    deployment_amount = round(available_cash * deployment_pct / 100, 2)
    segment_split = CRASH_SEGMENT_SPLITS[tier][risk.risk_category]
    segments_out = _build_instruments_for_split(
        segment_split, risk.risk_category, instruments, deployment_amount
    )

    tier_label = {"mild": "mild", "deep": "deeper", "major": "major"}[tier]
    explanation = (
        f"Nifty is currently {drawdown:.1f}% below its 52-week high ({tier_label} correction tier). "
        f"For your {risk.risk_category.value} risk profile, a phased deployment suggestion of "
        f"{deployment_pct:.0f}% of your available cash (₹{deployment_amount:,.0f} of ₹{available_cash:,.0f}) "
        f"is shown — not an all-in deployment. Remaining cash stays undeployed by design so additions "
        f"can be spread over time if markets fall further. Segment mix favours "
        f"{'debt and gold' if risk.risk_category == RiskCategory.LOW else 'a balanced mix' if risk.risk_category == RiskCategory.MODERATE else 'equity with controlled mid-cap exposure'} "
        f"appropriate to your risk category."
    )

    return CrashSignalResult(
        status="active_correction",
        drawdown_pct=drawdown,
        correction_tier=tier,
        deployment_pct_of_cash=deployment_pct,
        available_cash=available_cash,
        suggested_deployment_amount=deployment_amount,
        segment_split=segments_out,
        explanation=explanation,
        disclaimer=disclaimer,
        risk_category=risk.risk_category.value,
    )


def _classify_tier_with_thresholds(
    drawdown_pct: float,
    mild: float,
    deep: float,
    major: float,
) -> str | None:
    if drawdown_pct < mild:
        return None
    if drawdown_pct < deep:
        return "mild"
    if drawdown_pct < major:
        return "deep"
    return "major"
