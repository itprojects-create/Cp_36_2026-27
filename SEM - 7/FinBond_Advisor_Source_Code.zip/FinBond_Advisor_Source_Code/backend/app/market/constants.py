"""Market data constants — tickers, thresholds, refresh intervals."""

# yfinance tickers (unofficial Yahoo Finance wrappers — may change without notice)
YFINANCE_TICKERS = {
    "NIFTY50": {"ticker": "^NSEI", "label": "Nifty 50"},
    "SENSEX": {"ticker": "^BSESN", "label": "Sensex"},
    "INDIA_VIX": {"ticker": "^INDIAVIX", "label": "India VIX"},
    "CRUDE_OIL": {"ticker": "CL=F", "label": "Crude Oil (WTI)"},
}

# AMFI daily NAV file (public, updated once daily)
AMFI_NAV_URL = "https://portal.amfiindia.com/spages/NAVAll.txt"

# Refresh intervals (overridden by env in config)
DEFAULT_YFINANCE_REFRESH_MINUTES = 30
DEFAULT_AMFI_REFRESH_HOURS = 24
DEFAULT_MARKET_DATA_STALE_MINUTES = 60

# Regime thresholds — simplified academic-project rules, NOT validated trading signals
DRAWDOWN_BULL_MAX = 5.0
DRAWDOWN_SIDEWAYS_MAX = 10.0
DRAWDOWN_BEAR_MAX = 20.0
VIX_MODERATE = 18.0
VIX_HIGH = 25.0
CRUDE_TREND_BEARISH_PCT = 10.0
NIFTY_TREND_DAYS = 20

REGIME_DISCLAIMER = (
    "Current market environment classification only — not a prediction of future market direction."
)
