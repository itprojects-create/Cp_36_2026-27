#!/usr/bin/env python3
"""Train XGBoost multi-output allocation model on synthetic dataset."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.multioutput import MultiOutputRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor

BACKEND_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_ROOT))

from app.recommendation.constants import SEGMENTS, SEGMENT_TO_TARGET
from app.recommendation.feature_engineering import (  # noqa: E402
    CATEGORICAL_FEATURES,
    FEATURE_COLUMNS,
    NUMERIC_FEATURES,
    QUESTIONNAIRE_FEATURES,
)
from app.recommendation.recommendation_builder import normalize_allocation  # noqa: E402

DEFAULT_DATA_PATH = BACKEND_ROOT / "data" / "synthetic_training_data.csv"


def _models_dir() -> Path:
    return Path(os.getenv("FINBOND_MODELS_DIR", str(BACKEND_ROOT / "models")))

TARGET_COLUMNS = [SEGMENT_TO_TARGET[s] for s in SEGMENTS]

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def postprocess_predictions(raw: np.ndarray) -> np.ndarray:
    """Clamp negatives and renormalize each row to sum to 100%."""
    processed = []
    for row in raw:
        allocation = {seg: max(0.0, float(row[i])) for i, seg in enumerate(SEGMENTS)}
        normalized = normalize_allocation(allocation)
        processed.append([normalized[seg] for seg in SEGMENTS])
    return np.array(processed)


def next_version(models_dir: Path) -> str:
    existing = sorted(models_dir.glob("allocation_model_v*.joblib"))
    if not existing:
        return "v1"
    nums = []
    for path in existing:
        stem = path.stem.replace("allocation_model_v", "")
        if stem.isdigit():
            nums.append(int(stem))
    return f"v{max(nums) + 1}"


def build_pipeline() -> Pipeline:
    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL_FEATURES),
            ("num", "passthrough", NUMERIC_FEATURES + QUESTIONNAIRE_FEATURES),
        ]
    )
    model = MultiOutputRegressor(
        XGBRegressor(
            n_estimators=200,
            max_depth=6,
            learning_rate=0.08,
            subsample=0.85,
            colsample_bytree=0.85,
            random_state=42,
            n_jobs=-1,
        )
    )
    return Pipeline(steps=[("preprocessor", preprocessor), ("model", model)])


def evaluate(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    mae = mean_absolute_error(y_true, y_pred)
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    r2 = r2_score(y_true, y_pred)
    per_segment = {}
    for i, seg in enumerate(SEGMENTS):
        per_segment[seg] = {
            "mae": round(float(mean_absolute_error(y_true[:, i], y_pred[:, i])), 4),
            "rmse": round(float(np.sqrt(mean_squared_error(y_true[:, i], y_pred[:, i]))), 4),
            "r2": round(float(r2_score(y_true[:, i], y_pred[:, i])), 4),
        }
    return {
        "overall_mae": round(float(mae), 4),
        "overall_rmse": round(rmse, 4),
        "overall_r2": round(float(r2), 4),
        "per_segment": per_segment,
    }


def train(
    data_path: Path,
    models_dir: Path,
    sample_size: int | None = None,
    noise_std: float | None = None,
    version: str | None = None,
) -> dict:
    if not data_path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {data_path}. Run: python ml/generate_dataset.py"
        )

    df = pd.read_csv(data_path)
    if sample_size:
        df = df.sample(n=min(sample_size, len(df)), random_state=42)

    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMNS].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)

    raw_pred = pipeline.predict(X_test)
    y_pred = postprocess_predictions(raw_pred)
    metrics = evaluate(y_test, y_pred)

    models_dir.mkdir(parents=True, exist_ok=True)
    version = version or next_version(models_dir)
    model_file = models_dir / f"allocation_model_{version}.joblib"
    metadata_file = models_dir / f"allocation_model_{version}_metadata.json"

    joblib.dump(pipeline, model_file)

    metadata = {
        "version": version,
        "engine": f"ml_{version}",
        "training_date": datetime.now(timezone.utc).isoformat(),
        "dataset_path": str(data_path),
        "dataset_size": len(df),
        "noise_std_used": noise_std,
        "feature_columns": FEATURE_COLUMNS,
        "target_columns": TARGET_COLUMNS,
        "segments": SEGMENTS,
        "metrics": metrics,
        "model_file": model_file.name,
    }
    metadata_file.write_text(json.dumps(metadata, indent=2))

    active = {
        "active_version": version,
        "model_file": model_file.name,
        "metadata_file": metadata_file.name,
        "engine": f"ml_{version}",
    }
    (models_dir / "active_model.json").write_text(json.dumps(active, indent=2))

    logger.info("Saved model: %s", model_file)
    logger.info("Metrics — MAE: %.4f  RMSE: %.4f  R²: %.4f", metrics["overall_mae"], metrics["overall_rmse"], metrics["overall_r2"])
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description="Train ML allocation model")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA_PATH)
    parser.add_argument("--sample", type=int, default=None, help="Use subset for quick test runs")
    parser.add_argument("--noise-std", type=float, default=None)
    parser.add_argument("--version", type=str, default=None)
    args = parser.parse_args()

    train(
        data_path=args.data,
        models_dir=_models_dir(),
        sample_size=args.sample,
        noise_std=args.noise_std,
        version=args.version,
    )


if __name__ == "__main__":
    main()
