#!/usr/bin/env python3
"""
Generate synthetic training data for the ML allocation model.

This dataset is synthetically generated using the project's own rule-based
allocation logic as label source, with controlled Gaussian noise added per
segment. No public dataset mapping user financial profiles to portfolio
allocations exists, so we derive labels from our rule engine rather than
claiming real historical ground truth.
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

# Allow running as script from backend/
BACKEND_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_ROOT))

from app.models import (  # noqa: E402
    FinancialGoal,
    GoalType,
    InvestmentExperience,
    RiskAssessment,
    RiskCategory,
    UserProfile,
)
from app.recommendation.constants import SEGMENTS, SEGMENT_TO_TARGET
from app.recommendation.allocation_engine import compute_rule_based_allocation
from app.recommendation.derived_features import calculate_derived_features
from app.recommendation.feature_engineering import FEATURE_COLUMNS, build_ml_features
from app.recommendation.recommendation_builder import normalize_allocation
from app.recommendation.risk_scoring import calculate_risk_score

# --- Configurable constants ---
DATASET_SIZE = 7500
NOISE_STD = 4.0  # Gaussian noise std dev per segment (percentage points)
NOISE_SEED = 42
OUTPUT_PATH = BACKEND_ROOT / "data" / "synthetic_training_data.csv"

GOAL_TYPES = list(GoalType)
EXPERIENCE_LEVELS = list(InvestmentExperience)

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def sample_questionnaire(rng: np.random.Generator) -> dict[str, int]:
    """Sample moderate-centered Likert responses (1-5)."""
    responses = {}
    for q in [
        "portfolio_drop_reaction",
        "income_stability",
        "emergency_fund_presence",
        "debt_load",
        "investment_horizon",
        "investment_experience",
        "preferred_style",
        "volatility_tolerance",
    ]:
        val = int(round(_clip(rng.normal(3.0, 0.8), 1, 5)))
        responses[q] = val

    # Inverted scales — lower answer = higher risk tolerance for these two
    responses["capital_preservation"] = int(round(_clip(rng.normal(3.0, 0.8), 1, 5)))
    responses["dependents_obligations"] = int(round(_clip(rng.normal(3.0, 0.8), 1, 5)))
    return responses


def sample_profile_row(rng: np.random.Generator, current_year: int) -> tuple[UserProfile, FinancialGoal, RiskAssessment]:
    age = int(_clip(rng.normal(38, 10), 21, 65))
    monthly_income = float(_clip(rng.lognormal(mean=11.2, sigma=0.35), 25000, 500000))
    expense_ratio = float(_clip(rng.normal(0.55, 0.1), 0.35, 0.85))
    monthly_expenses = monthly_income * expense_ratio
    emi = float(_clip(rng.exponential(monthly_income * 0.08), 0, monthly_income * 0.45))
    savings = float(_clip(rng.lognormal(mean=12.5, sigma=0.6), 10000, monthly_income * 24))
    existing_investments = float(_clip(rng.lognormal(mean=12.8, sigma=0.7), 0, monthly_income * 60))
    emergency_fund_months = float(_clip(rng.beta(2.5, 2.0) * 12, 0, 18))
    monthly_sip = float(_clip(rng.exponential(monthly_income * 0.05), 0, monthly_income * 0.3))
    dependents = int(rng.choice([0, 1, 2, 3, 4], p=[0.4, 0.3, 0.15, 0.1, 0.05]))
    exp_idx = int(rng.choice(len(EXPERIENCE_LEVELS), p=[0.15, 0.35, 0.35, 0.15]))
    experience = EXPERIENCE_LEVELS[exp_idx]

    goal_idx = int(rng.choice(len(GOAL_TYPES), p=[0.25, 0.15, 0.08, 0.1, 0.27, 0.15]))
    goal_type = GOAL_TYPES[goal_idx]

    if goal_type in (GoalType.CAR, GoalType.HOUSE, GoalType.EMERGENCY):
        horizon = int(_clip(rng.integers(2, 8), 2, 10))
    elif goal_type == GoalType.RETIREMENT:
        horizon = int(_clip(rng.integers(10, 30), 5, 35))
    else:
        horizon = int(_clip(rng.integers(5, 20), 3, 25))

    target_year = current_year + horizon
    target_amount = float(_clip(rng.lognormal(mean=14.5, sigma=0.5), 500000, 20000000))

    responses = sample_questionnaire(rng)
    risk_score, risk_category = calculate_risk_score(responses)

    profile = UserProfile(
        user_id=0,
        age=age,
        occupation="synthetic",
        dependents=dependents,
        monthly_income=monthly_income,
        monthly_expenses=monthly_expenses,
        savings=savings,
        existing_investments=existing_investments,
        emergency_fund_months=emergency_fund_months,
        emi=emi,
        monthly_sip=monthly_sip,
        investment_experience=experience,
    )
    goal = FinancialGoal(
        user_id=0,
        goal_type=goal_type,
        target_amount=target_amount,
        target_year=target_year,
        priority=1,
        current_saved=savings * 0.3,
    )
    risk = RiskAssessment(
        user_id=0,
        responses=responses,
        risk_score=risk_score,
        risk_category=risk_category,
    )
    return profile, goal, risk


def add_noise_to_allocation(
    allocation: dict[str, float], rng: np.random.Generator, noise_std: float
) -> dict[str, float]:
    noisy = {}
    for segment in SEGMENTS:
        noisy[segment] = max(0.0, allocation[segment] + rng.normal(0, noise_std))
    return normalize_allocation(noisy)


def generate_dataset(size: int, noise_std: float, output_path: Path, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    current_year = datetime.now().year
    rows = []

    for _ in range(size):
        profile, goal, risk = sample_profile_row(rng, current_year)
        derived = calculate_derived_features(
            monthly_income=profile.monthly_income or 0,
            monthly_expenses=profile.monthly_expenses or 0,
            savings=profile.savings or 0,
            existing_investments=profile.existing_investments or 0,
            emergency_fund_months=profile.emergency_fund_months or 0,
            emi=profile.emi or 0,
        )
        rule_allocation = compute_rule_based_allocation(profile, [goal], risk, derived)
        label_allocation = add_noise_to_allocation(rule_allocation, rng, noise_std)

        features = build_ml_features(profile, [goal], risk)
        for segment, col in SEGMENT_TO_TARGET.items():
            features[col] = label_allocation[segment]

        rows.append(features)

    df = pd.DataFrame(rows)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    return df


def log_dataset_stats(df: pd.DataFrame) -> None:
    logger.info("Dataset rows: %d", len(df))
    logger.info("Feature columns: %d", len(FEATURE_COLUMNS))

    for col in ["age", "monthly_income", "risk_score", "horizon_years"]:
        if col in df.columns:
            logger.info(
                "  %s: min=%.2f max=%.2f mean=%.2f",
                col,
                df[col].min(),
                df[col].max(),
                df[col].mean(),
            )

    target_cols = list(SEGMENT_TO_TARGET.values())
    logger.info("Target distribution (segment %% mean / std):")
    for col in target_cols:
        logger.info("  %s: mean=%.2f std=%.2f", col, df[col].mean(), df[col].std())

    row_sums = df[target_cols].sum(axis=1)
    logger.info(
        "Target row sums: min=%.2f max=%.2f mean=%.2f (expect ~100)",
        row_sums.min(),
        row_sums.max(),
        row_sums.mean(),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate synthetic ML training dataset")
    parser.add_argument("--size", type=int, default=DATASET_SIZE)
    parser.add_argument("--noise-std", type=float, default=NOISE_STD)
    parser.add_argument("--output", type=Path, default=OUTPUT_PATH)
    parser.add_argument("--seed", type=int, default=NOISE_SEED)
    args = parser.parse_args()

    logger.info(
        "Generating %d synthetic profiles (noise_std=%.1f)...",
        args.size,
        args.noise_std,
    )
    df = generate_dataset(args.size, args.noise_std, args.output, args.seed)
    log_dataset_stats(df)
    logger.info("Saved to %s", args.output)


if __name__ == "__main__":
    main()
