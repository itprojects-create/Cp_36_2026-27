"""Load active ML model and predict segment allocations."""

from __future__ import annotations

import json
import os
from pathlib import Path

import joblib
import numpy as np

from app.models import FinancialGoal, RiskAssessment, UserProfile
from app.recommendation.constants import SEGMENTS
from app.recommendation.feature_engineering import build_ml_features_dataframe
from app.recommendation.recommendation_builder import normalize_allocation

BACKEND_ROOT = Path(__file__).resolve().parents[1]


def _models_dir() -> Path:
    return Path(os.getenv("FINBOND_MODELS_DIR", str(BACKEND_ROOT / "models")))


def _active_model_file() -> Path:
    return _models_dir() / "active_model.json"


class ModelNotFoundError(FileNotFoundError):
    """Raised when no trained model is available."""


class ModelLoadError(RuntimeError):
    """Raised when model file exists but fails to load."""


def get_active_model_paths() -> tuple[Path, Path]:
    if not _active_model_file().exists():
        raise ModelNotFoundError(
            "No active ML model found. Train one with: python ml/train_model.py"
        )

    active = json.loads(_active_model_file().read_text())
    model_path = _models_dir() / active["model_file"]
    metadata_path = _models_dir() / active["metadata_file"]

    if not model_path.exists():
        raise ModelNotFoundError(f"Model file missing: {model_path}")
    if not metadata_path.exists():
        raise ModelNotFoundError(f"Metadata file missing: {metadata_path}")

    return model_path, metadata_path


def load_active_model() -> tuple[object, dict]:
    model_path, metadata_path = get_active_model_paths()
    try:
        pipeline = joblib.load(model_path)
        metadata = json.loads(metadata_path.read_text())
        return pipeline, metadata
    except Exception as exc:
        raise ModelLoadError(f"Failed to load model from {model_path}: {exc}") from exc


def postprocess_prediction(raw: np.ndarray) -> dict[str, float]:
    allocation = {seg: max(0.0, float(raw[i])) for i, seg in enumerate(SEGMENTS)}
    return normalize_allocation(allocation)


def predict_segment_allocation(
    profile: UserProfile,
    goals: list[FinancialGoal],
    risk: RiskAssessment,
) -> dict[str, float]:
    pipeline, _metadata = load_active_model()
    features = build_ml_features_dataframe(profile, goals, risk)
    raw = pipeline.predict(features)[0]
    return postprocess_prediction(raw)


def get_active_model_metadata() -> dict:
    _model_path, metadata_path = get_active_model_paths()
    return json.loads(metadata_path.read_text())
