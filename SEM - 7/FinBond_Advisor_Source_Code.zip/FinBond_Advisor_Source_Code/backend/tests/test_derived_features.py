import pytest

from app.recommendation.derived_features import calculate_derived_features


def test_savings_rate():
    features = calculate_derived_features(
        monthly_income=100000,
        monthly_expenses=50000,
        savings=200000,
        existing_investments=100000,
        emergency_fund_months=6,
        emi=10000,
    )
    assert features.savings_rate == 40.0
    assert features.debt_burden_ratio == 10.0
    assert features.emergency_fund_coverage == 6.0
    assert features.investable_assets == 300000.0


def test_zero_income_raises():
    with pytest.raises(ValueError):
        calculate_derived_features(
            monthly_income=0,
            monthly_expenses=0,
            savings=0,
            existing_investments=0,
            emergency_fund_months=0,
            emi=0,
        )
