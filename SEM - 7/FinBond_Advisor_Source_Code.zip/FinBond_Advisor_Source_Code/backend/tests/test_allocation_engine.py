from datetime import datetime, timezone

from app.models import (
    FinancialGoal,
    GoalType,
    InstrumentCategory,
    InvestmentInstrument,
    RiskAssessment,
    RiskCategory,
    UserProfile,
)
from app.recommendation.allocation_engine import compute_rule_based_allocation, generate_recommendation
from app.recommendation.types import AllocationInput


def _make_profile(**overrides):
    defaults = dict(
        age=35,
        monthly_income=100000,
        monthly_expenses=50000,
        savings=200000,
        existing_investments=300000,
        emergency_fund_months=5,
        emi=10000,
    )
    defaults.update(overrides)
    profile = UserProfile(user_id=1, **defaults)
    return profile


def _make_goal(goal_type=GoalType.RETIREMENT, target_year=2045):
    return FinancialGoal(
        user_id=1,
        goal_type=goal_type,
        target_amount=5000000,
        target_year=target_year,
        priority=1,
        current_saved=300000,
    )


def _make_risk(category=RiskCategory.MODERATE, score=6.0):
    return RiskAssessment(
        user_id=1,
        responses={},
        risk_score=score,
        risk_category=category,
    )


def _sample_instruments():
    curated = datetime(2024, 8, 1, tzinfo=timezone.utc)
    templates = [
        ("Debt Fund", InstrumentCategory.DEBT, 2),
        ("Large Cap Fund", InstrumentCategory.LARGE_CAP, 3),
        ("Mid Cap Fund", InstrumentCategory.MID_CAP, 4),
        ("Small Cap Fund", InstrumentCategory.SMALL_CAP, 5),
        ("Gold ETF", InstrumentCategory.GOLD, 3),
        ("Index ETF", InstrumentCategory.ETF, 3),
    ]
    instruments = []
    for idx, (name, cat, risk) in enumerate(templates, start=1):
        instruments.append(
            InvestmentInstrument(
                id=idx,
                name=name,
                category=cat,
                cagr_3y=12.0 + idx,
                expense_ratio=0.5,
                risk_level=risk,
                is_active=True,
                source="test",
                last_updated=curated,
            )
        )
    return instruments


def _total_segment_allocation(result):
    return sum(seg["allocation_pct"] for seg in result["portfolio"])


def _total_instrument_allocation(result):
    return sum(
        inst["allocation_pct"]
        for seg in result["portfolio"]
        for inst in seg["instruments"]
    )


def _instruments_per_segment_instruments():
    """Two instruments per segment to exercise split logic."""
    curated = datetime(2024, 8, 1, tzinfo=timezone.utc)
    pairs = [
        ("Debt Fund A", "Debt Fund B", InstrumentCategory.DEBT),
        ("Large Cap A", "Large Cap B", InstrumentCategory.LARGE_CAP),
        ("Mid Cap A", "Mid Cap B", InstrumentCategory.MID_CAP),
        ("Small Cap A", "Small Cap B", InstrumentCategory.SMALL_CAP),
        ("Gold ETF A", "Gold ETF B", InstrumentCategory.GOLD),
        ("Index ETF A", "Index ETF B", InstrumentCategory.ETF),
    ]
    instruments = []
    idx = 1
    for name_a, name_b, cat in pairs:
        for name in (name_a, name_b):
            instruments.append(
                InvestmentInstrument(
                    id=idx,
                    name=name,
                    category=cat,
                    cagr_3y=12.0 + idx,
                    expense_ratio=0.4 + idx * 0.05,
                    risk_level=3,
                    is_active=True,
                    source="test",
                    last_updated=curated,
                )
            )
            idx += 1
    return instruments


def test_allocation_sums_to_100_low_risk():
    result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(emergency_fund_months=8),
            goals=[_make_goal()],
            risk=_make_risk(RiskCategory.LOW, 2.5),
            instruments=_sample_instruments(),
            investable_amount=500000,
        )
    )
    assert abs(_total_segment_allocation(result) - 100.0) < 0.1
    debt_pct = next(s["allocation_pct"] for s in result["portfolio"] if s["segment"] == "G-Sec/Debt")
    assert debt_pct >= 40


def test_allocation_sums_to_100_high_risk():
    result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(emergency_fund_months=8),
            goals=[_make_goal(GoalType.WEALTH_CREATION, 2048)],
            risk=_make_risk(RiskCategory.HIGH, 9.0),
            instruments=_sample_instruments(),
            investable_amount=500000,
        )
    )
    assert abs(_total_segment_allocation(result) - 100.0) < 0.1
    equity = sum(
        s["allocation_pct"]
        for s in result["portfolio"]
        if s["segment"] in ("Large Cap", "Mid Cap", "Small Cap", "ETF")
    )
    assert equity > 50


def test_short_horizon_increases_debt():
    long_result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(),
            goals=[_make_goal(GoalType.RETIREMENT, 2045)],
            risk=_make_risk(),
            instruments=_sample_instruments(),
            investable_amount=500000,
        )
    )
    short_result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(),
            goals=[_make_goal(GoalType.CAR, datetime.now().year + 2)],
            risk=_make_risk(),
            instruments=_sample_instruments(),
            investable_amount=500000,
        )
    )
    long_debt = next(s["allocation_pct"] for s in long_result["portfolio"] if s["segment"] == "G-Sec/Debt")
    short_debt = next(s["allocation_pct"] for s in short_result["portfolio"] if s["segment"] == "G-Sec/Debt")
    assert short_debt > long_debt


def test_explanation_uses_user_numbers():
    result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(age=42, emergency_fund_months=3),
            goals=[_make_goal()],
            risk=_make_risk(RiskCategory.MODERATE, 6.4),
            instruments=_sample_instruments(),
            investable_amount=500000,
        )
    )
    assert "42" in result["explanation"]
    assert "6.4" in result["explanation"]
    assert "3.0 months" in result["explanation"] or "3 months" in result["explanation"]


def test_instrument_allocation_sums_to_100():
    """Instrument-level allocation_pct across all cards must total 100%."""
    result = generate_recommendation(
        AllocationInput(
            profile=_make_profile(),
            goals=[_make_goal()],
            risk=_make_risk(RiskCategory.MODERATE, 6.0),
            instruments=_instruments_per_segment_instruments(),
            investable_amount=500000,
        )
    )
    instrument_total = _total_instrument_allocation(result)
    segment_total = _total_segment_allocation(result)
    assert abs(instrument_total - 100.0) < 0.15
    assert abs(segment_total - 100.0) < 0.1
    assert abs(instrument_total - segment_total) < 0.15

    for seg in result["portfolio"]:
        if len(seg["instruments"]) > 1:
            inst_sum = sum(i["allocation_pct"] for i in seg["instruments"])
            assert abs(inst_sum - seg["allocation_pct"]) < 0.05
            pct_values = [i["allocation_pct"] for i in seg["instruments"]]
            assert len(set(pct_values)) >= 1  # split applied (may be equal if scores tie)
