"""Tests for rule-based help assistant."""

from tests.conftest import complete_onboarding


class TestAssistantApi:
    def test_term_definition_expense_ratio(self, client):
        res = client.post("/api/assistant/ask", json={"question": "What is expense ratio?"})
        assert res.status_code == 200
        body = res.json()
        assert body["matched"] is True
        assert body["category"] == "terms"
        assert "expense ratio" in body["answer"].lower()
        assert "rule-based" in body["label"].lower()

    def test_personalized_debt_question_uses_stored_data(self, client, auth_headers):
        complete_onboarding(client, auth_headers)
        rec = client.post("/api/v1/recommend", headers=auth_headers).json()

        res = client.post(
            "/api/assistant/ask",
            json={"question": "Why is my debt allocation so high?"},
            headers=auth_headers,
        )
        assert res.status_code == 200
        body = res.json()
        assert body["matched"] is True
        assert body["category"] == "personalized"

        debt_pct = next(
            s["allocation_pct"] for s in rec["portfolio"] if s["segment"] == "G-Sec/Debt"
        )
        assert f"{debt_pct:.1f}" in body["answer"] or str(int(debt_pct)) in body["answer"]
        assert rec["risk"]["category"] in body["answer"]
        assert rec["explanation"] in body["answer"]

    def test_fallback_for_unmatched_question(self, client):
        res = client.post("/api/assistant/ask", json={"question": "What's the weather today?"})
        assert res.status_code == 200
        body = res.json()
        assert body["matched"] is False
        assert body["category"] == "fallback"
        assert "What is expense ratio?" in body["answer"]
        assert "What does risk score mean?" in body["answer"]
        assert "Is this guaranteed?" in body["answer"]

    def test_personalized_without_auth_returns_onboarding_guidance(self, client):
        res = client.post("/api/assistant/ask", json={"question": "What is my risk score?"})
        assert res.status_code == 200
        body = res.json()
        assert body["matched"] is True
        assert "onboarding" in body["answer"].lower()

    def test_personalized_authed_without_recommendation(self, client, auth_headers):
        res = client.post(
            "/api/assistant/ask",
            json={"question": "What is my risk score?"},
            headers=auth_headers,
        )
        assert res.status_code == 200
        assert "onboarding" in res.json()["answer"].lower()

    def test_safety_question_no_auth_required(self, client):
        res = client.post("/api/assistant/ask", json={"question": "Are returns guaranteed?"})
        assert res.status_code == 200
        body = res.json()
        assert body["category"] == "safety"
        assert "not guaranteed" in body["answer"].lower() or "not guarantees" in body["answer"].lower()
