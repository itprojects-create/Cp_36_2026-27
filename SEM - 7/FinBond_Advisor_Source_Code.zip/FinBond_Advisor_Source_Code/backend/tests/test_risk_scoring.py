import pytest

from app.recommendation.risk_scoring import calculate_risk_score, score_to_category


def _all_answers(value: int) -> dict[str, int]:
    return {
        "portfolio_drop_reaction": value,
        "income_stability": value,
        "emergency_fund_presence": value,
        "debt_load": value,
        "investment_horizon": value,
        "capital_preservation": 6 - value,  # inverted scale
        "investment_experience": value,
        "preferred_style": value,
        "dependents_obligations": 6 - value,
        "volatility_tolerance": value,
    }


def test_low_risk_category():
    score, category = calculate_risk_score(_all_answers(1))
    assert category.value == "LOW"
    assert score <= 3.0


def test_moderate_risk_category():
    score, category = calculate_risk_score(_all_answers(3))
    assert category.value == "MODERATE"
    assert 4.0 <= score <= 7.0


def test_high_risk_category():
    score, category = calculate_risk_score(_all_answers(5))
    assert category.value == "HIGH"
    assert score >= 8.0


def test_score_boundaries():
    assert score_to_category(3.0).value == "LOW"
    assert score_to_category(3.1).value == "MODERATE"
    assert score_to_category(7.0).value == "MODERATE"
    assert score_to_category(7.1).value == "HIGH"


def test_missing_question_raises():
    responses = _all_answers(3)
    del responses["debt_load"]
    with pytest.raises(ValueError, match="Missing"):
        calculate_risk_score(responses)
