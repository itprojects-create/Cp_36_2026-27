"""Unit and API tests for Phase 3 market data layer."""

from datetime import datetime, timedelta, timezone

import pytest

from app.market.cache_service import is_stale, save_snapshot
from app.market.regime_detector import MarketRegime, classify_regime


class TestRegimeDetector:
    def test_crash_on_high_drawdown(self):
        result = classify_regime(nifty_drawdown_pct=22.0, india_vix=20.0, crude_change_30d_pct=5.0)
        assert result.regime == MarketRegime.CRASH

    def test_crash_on_high_vix(self):
        result = classify_regime(nifty_drawdown_pct=8.0, india_vix=26.0, crude_change_30d_pct=3.0)
        assert result.regime == MarketRegime.CRASH

    def test_bear_on_moderate_drawdown(self):
        result = classify_regime(nifty_drawdown_pct=12.0, india_vix=16.0, crude_change_30d_pct=2.0)
        assert result.regime == MarketRegime.BEAR

    def test_bear_on_vix_and_crude(self):
        result = classify_regime(nifty_drawdown_pct=6.0, india_vix=19.0, crude_change_30d_pct=12.0)
        assert result.regime == MarketRegime.BEAR

    def test_bull_conditions(self):
        result = classify_regime(
            nifty_drawdown_pct=3.0,
            india_vix=15.0,
            crude_change_30d_pct=2.0,
            nifty_trend_up=True,
        )
        assert result.regime == MarketRegime.BULL

    def test_sideways_default(self):
        result = classify_regime(nifty_drawdown_pct=7.0, india_vix=16.0, crude_change_30d_pct=2.0)
        assert result.regime == MarketRegime.SIDEWAYS

    def test_disclaimer_present(self):
        result = classify_regime(nifty_drawdown_pct=3.0, india_vix=15.0, crude_change_30d_pct=1.0)
        assert "not a prediction" in result.disclaimer.lower()


class TestMarketApi:
    def test_market_pulse_requires_auth(self, client):
        response = client.get("/api/market-pulse")
        assert response.status_code == 401

    def test_market_regime_requires_auth(self, client):
        response = client.get("/api/market-regime")
        assert response.status_code == 401

    def test_gsec_requires_auth(self, client):
        response = client.get("/api/gsec")
        assert response.status_code == 401

    def test_market_pulse_unavailable_without_cache(self, client, auth_headers):
        response = client.get("/api/market-pulse", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["gsec_yield"]["status"] == "unavailable"
        assert data["fii_dii"]["status"] == "unavailable"
        assert all(item["status"] == "unavailable" for item in data["indices"])

    def test_market_regime_unavailable_without_nifty(self, client, auth_headers):
        response = client.get("/api/market-regime", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["regime"] == "UNAVAILABLE"
        assert data["data_status"] == "unavailable"

    def test_stale_snapshot_flagged(self, client, auth_headers, db_session):
        old_time = datetime.now(timezone.utc) - timedelta(hours=2)
        snap = save_snapshot(
            db_session,
            symbol="NIFTY50",
            source="yfinance",
            value=24000.0,
            meta={"drawdown_from_52w_high_pct": 4.0, "nifty_trend_up": True},
            fetch_success=True,
        )
        snap.fetched_at = old_time
        db_session.commit()

        save_snapshot(
            db_session,
            symbol="INDIA_VIX",
            source="yfinance",
            value=14.0,
            meta={},
            fetch_success=True,
        )

        response = client.get("/api/market-regime", headers=auth_headers)
        data = response.json()
        assert data["regime"] == "BULL"
        assert data["is_stale"] is True
        assert data["data_status"] == "stale"

    def test_admin_gsec_update(self, client, db_session):
        from app.core.config import settings

        login = client.post(
            "/api/v1/auth/login",
            json={"email": settings.ADMIN_EMAIL, "password": settings.ADMIN_PASSWORD},
        )
        admin_headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

        put_res = client.put("/api/v1/admin/gsec", json={"yield_pct": 7.15}, headers=admin_headers)
        assert put_res.status_code == 200
        assert put_res.json()["yield_pct"] == 7.15
        assert put_res.json()["status"] == "available"

        get_res = client.get("/api/gsec", headers=admin_headers)
        assert get_res.json()["yield_pct"] == 7.15

        status_res = client.get("/api/v1/admin/market/status", headers=admin_headers)
        assert status_res.status_code == 200
        assert "sources" in status_res.json()


class TestCacheService:
    def test_is_stale_respects_threshold(self, monkeypatch):
        from app.core import config

        monkeypatch.setattr(config.settings, "MARKET_DATA_STALE_MINUTES", 30)
        recent = datetime.now(timezone.utc) - timedelta(minutes=10)
        old = datetime.now(timezone.utc) - timedelta(minutes=45)
        assert is_stale(recent) is False
        assert is_stale(old) is True
