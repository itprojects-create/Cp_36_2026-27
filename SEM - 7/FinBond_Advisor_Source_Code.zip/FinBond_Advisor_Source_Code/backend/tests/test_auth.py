from tests.conftest import complete_onboarding


def test_register_and_login(client):
    email = "newuser@example.com"
    password = "SecurePass1"
    reg = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert reg.status_code == 201
    assert "access_token" in reg.json()

    login = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200

    bad = client.post("/api/v1/auth/login", json={"email": email, "password": "wrong"})
    assert bad.status_code == 401


def test_protected_route_requires_auth(client):
    res = client.get("/api/v1/auth/me")
    assert res.status_code == 401


def test_me_after_login(client, auth_headers):
    res = client.get("/api/v1/auth/me", headers=auth_headers)
    assert res.status_code == 200
    assert res.json()["email"] == "testuser@example.com"


def test_profile_requires_disclaimer(client, auth_headers):
    res = client.post(
        "/api/v1/user/profile",
        json={
            "age": 30,
            "occupation": "Analyst",
            "dependents": 0,
            "monthly_income": 80000,
            "monthly_expenses": 40000,
            "savings": 100000,
            "existing_investments": 50000,
            "emergency_fund_months": 4,
            "emi": 0,
            "monthly_sip": 5000,
            "investment_experience": "beginner",
        },
        headers=auth_headers,
    )
    assert res.status_code == 403


def test_full_onboarding_and_recommend(client, auth_headers):
    complete_onboarding(client, auth_headers)
    rec = client.post("/api/v1/recommend", headers=auth_headers)
    assert rec.status_code == 200
    data = rec.json()
    assert "portfolio" in data
    assert "explanation" in data
    total_pct = sum(seg["allocation_pct"] for seg in data["portfolio"])
    assert abs(total_pct - 100.0) < 0.1
