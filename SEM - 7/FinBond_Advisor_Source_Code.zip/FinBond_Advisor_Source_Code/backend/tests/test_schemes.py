"""Tests for government scheme matcher and API."""

from app.models import GovernmentScheme, UserProfile
from app.services.scheme_matcher import EligibilityClass, match_scheme


def _profile(**kwargs) -> UserProfile:
    defaults = {
        "user_id": 1,
        "age": 32,
        "occupation": "Software Engineer",
        "dependents": 0,
        "monthly_income": 100000,
        "monthly_expenses": 50000,
        "savings": 200000,
        "existing_investments": 100000,
        "emergency_fund_months": 6,
        "emi": 0,
        "monthly_sip": 10000,
    }
    defaults.update(kwargs)
    return UserProfile(**defaults)


def _scheme(**kwargs) -> GovernmentScheme:
    defaults = {
        "id": 1,
        "name": "Test Scheme",
        "department": "Test Dept",
        "description": "Test description",
        "benefits": "Test benefits",
        "official_portal_url": "https://example.gov.in",
        "last_updated": None,
        "is_active": True,
    }
    defaults.update(kwargs)
    s = GovernmentScheme(**{k: v for k, v in defaults.items() if k != "last_updated"})
    from datetime import datetime, timezone

    s.last_updated = datetime.now(timezone.utc)
    return s


class TestSchemeMatcher:
    def test_eligible_when_no_notes_and_criteria_pass(self):
        scheme = _scheme(
            name="Open Savings",
            eligibility_min_age=18,
            eligibility_max_age=65,
            eligibility_notes=None,
        )
        result = match_scheme(_profile(age=30), scheme)
        assert result.classification == EligibilityClass.ELIGIBLE
        assert "Verify eligibility" in result.reason

    def test_not_eligible_age_fail_scss(self):
        scheme = _scheme(
            name="Senior Citizens Savings Scheme (SCSS)",
            eligibility_min_age=60,
            eligibility_notes="Some note",
        )
        result = match_scheme(_profile(age=35), scheme)
        assert result.classification == EligibilityClass.NOT_ELIGIBLE
        assert "minimum age is 60" in result.reason

    def test_may_be_eligible_missing_gender_ssy(self):
        scheme = _scheme(
            name="Sukanya Samriddhi Yojana (SSY)",
            eligibility_gender="female",
            eligibility_notes="Girl child below 10 required",
        )
        result = match_scheme(_profile(age=30), scheme)
        assert result.classification == EligibilityClass.MAY_BE_ELIGIBLE
        assert "gender" in result.reason.lower()

    def test_may_be_eligible_when_notes_present(self):
        scheme = _scheme(
            name="Atal Pension Yojana (APY)",
            eligibility_min_age=18,
            eligibility_max_age=40,
            eligibility_notes="Must have savings bank account",
        )
        result = match_scheme(_profile(age=30), scheme)
        assert result.classification == EligibilityClass.MAY_BE_ELIGIBLE

    def test_pmvvy_closed_not_eligible(self):
        scheme = _scheme(
            name="Pradhan Mantri Vaya Vandana Yojana (PMVVY)",
            eligibility_min_age=60,
            eligibility_notes=(
                "CLOSED for new subscriptions since March 31, 2023 — fresh applications are not accepted. "
                "See Senior Citizens Savings Scheme (SCSS) as the active alternative."
            ),
        )
        result = match_scheme(_profile(age=65), scheme)
        assert result.classification == EligibilityClass.NOT_ELIGIBLE
        assert "closed" in result.reason.lower()
        assert "March 31, 2023" in result.reason or "2023" in result.reason


class TestSchemesApi:
    def test_list_schemes_requires_auth(self, client):
        assert client.get("/api/schemes").status_code == 401

    def test_check_eligibility_requires_auth(self, client):
        assert client.post("/api/schemes/check-eligibility").status_code == 401

    def test_list_schemes_authenticated(self, client, auth_headers):
        r = client.get("/api/schemes", headers=auth_headers)
        assert r.status_code == 200
        assert len(r.json()) >= 10

    def test_check_eligibility_needs_profile(self, client, auth_headers):
        r = client.post("/api/schemes/check-eligibility", headers=auth_headers)
        assert r.status_code == 400

    def test_admin_scheme_crud(self, client, db_session):
        from app.core.config import settings

        login = client.post(
            "/api/v1/auth/login",
            json={"email": settings.ADMIN_EMAIL, "password": settings.ADMIN_PASSWORD},
        )
        admin_h = {"Authorization": f"Bearer {login.json()['access_token']}"}

        create = client.post(
            "/api/v1/admin/schemes",
            json={
                "name": "Test Demo Scheme",
                "department": "Test Ministry",
                "description": "Demo scheme for CRUD test",
                "benefits": "Demo benefits",
                "official_portal_url": "https://example.gov.in/scheme",
                "eligibility_min_age": 18,
            },
            headers=admin_h,
        )
        assert create.status_code == 201
        scheme_id = create.json()["id"]

        update = client.put(
            f"/api/v1/admin/schemes/{scheme_id}",
            json={"description": "Updated description"},
            headers=admin_h,
        )
        assert update.status_code == 200
        assert update.json()["description"] == "Updated description"

        delete = client.delete(f"/api/v1/admin/schemes/{scheme_id}", headers=admin_h)
        assert delete.status_code == 204

        listed = client.get("/api/v1/admin/schemes", headers=admin_h)
        row = next(s for s in listed.json() if s["id"] == scheme_id)
        assert row["is_active"] is False

    def test_eligibility_after_onboarding(self, client, auth_headers):
        from tests.conftest import complete_onboarding

        complete_onboarding(client, auth_headers)
        r = client.post("/api/schemes/check-eligibility", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        assert len(data["results"]) >= 10
        pmvvy = next(x for x in data["results"] if "PMVVY" in x["scheme_name"] or "Vaya Vandana" in x["scheme_name"])
        assert pmvvy["classification"] == "NOT ELIGIBLE"
        assert "Verify eligibility" in pmvvy["reason"]
