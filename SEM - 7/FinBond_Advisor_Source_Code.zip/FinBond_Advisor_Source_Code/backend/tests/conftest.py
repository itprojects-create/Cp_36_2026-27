import os

os.environ.setdefault("MARKET_REFRESH_ENABLED", "false")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.deps import get_db
from app.db.base import Base
from app.main import app
from app.seed.government_schemes import seed_government_schemes
from app.seed.instruments import seed_instruments
from app.seed import seed_admin

SQLALCHEMY_DATABASE_URL = "sqlite://"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=engine)
    session = TestingSessionLocal()
    seed_instruments(session)
    seed_government_schemes(session)
    seed_admin(session)
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers(client):
    email = "testuser@example.com"
    password = "TestPass123"
    client.post("/api/v1/auth/register", json={"email": email, "password": password})
    login = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    token = login.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="session")
def ml_artifacts(tmp_path_factory):
    """Generate a small dataset and train a model for ML API tests."""
    from ml.generate_dataset import NOISE_STD, generate_dataset
    from ml.train_model import train

    base = tmp_path_factory.mktemp("ml")
    data_path = base / "synthetic_training_data.csv"
    models_dir = base / "models"
    os.environ["FINBOND_MODELS_DIR"] = str(models_dir)

    generate_dataset(size=300, noise_std=NOISE_STD, output_path=data_path, seed=42)
    metadata = train(
        data_path=data_path,
        models_dir=models_dir,
        sample_size=200,
        noise_std=NOISE_STD,
        version="v1",
    )
    yield {"data_path": data_path, "models_dir": models_dir, "metadata": metadata}
    os.environ.pop("FINBOND_MODELS_DIR", None)


def complete_onboarding(client, headers):
    client.post("/api/v1/user/disclaimer", json={"accepted": True}, headers=headers)
    client.post(
        "/api/v1/user/profile",
        json={
            "age": 32,
            "occupation": "Software Engineer",
            "dependents": 1,
            "monthly_income": 120000,
            "monthly_expenses": 60000,
            "savings": 200000,
            "existing_investments": 300000,
            "emergency_fund_months": 5,
            "emi": 15000,
            "monthly_sip": 10000,
            "investment_experience": "intermediate",
        },
        headers=headers,
    )
    client.post(
        "/api/v1/user/goals",
        json={
            "goals": [
                {
                    "goal_type": "retirement",
                    "target_amount": 5000000,
                    "target_year": 2045,
                    "priority": 1,
                    "current_saved": 300000,
                }
            ]
        },
        headers=headers,
    )
    risk_responses = {
        "portfolio_drop_reaction": 3,
        "income_stability": 4,
        "emergency_fund_presence": 3,
        "debt_load": 3,
        "investment_horizon": 4,
        "capital_preservation": 3,
        "investment_experience": 3,
        "preferred_style": 3,
        "dependents_obligations": 3,
        "volatility_tolerance": 3,
    }
    client.post(
        "/api/v1/user/risk-assessment",
        json={"responses": risk_responses},
        headers=headers,
    )
