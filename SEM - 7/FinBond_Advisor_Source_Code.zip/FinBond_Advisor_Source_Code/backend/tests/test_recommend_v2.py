import joblib

from ml.predict import load_active_model, predict_segment_allocation
from ml.train_model import train
from tests.conftest import complete_onboarding
from tests.test_allocation_engine import _make_goal, _make_profile, _make_risk


def test_train_model_end_to_end(ml_artifacts):
    models_dir = ml_artifacts["models_dir"]
    model_path = models_dir / "allocation_model_v1.joblib"
    assert model_path.exists()

    pipeline, metadata = load_active_model()
    assert metadata["version"] == "v1"
    assert metadata["metrics"]["overall_mae"] >= 0

    profile = _make_profile()
    goals = [_make_goal()]
    risk = _make_risk()
    allocation = predict_segment_allocation(profile, goals, risk)
    assert abs(sum(allocation.values()) - 100.0) < 0.2


def test_train_model_can_reload_and_predict(ml_artifacts):
    pipeline, _ = load_active_model()
    saved = joblib.load(ml_artifacts["models_dir"] / "allocation_model_v1.joblib")
    assert saved is not None


def test_v1_recommend_unchanged(client, auth_headers):
    complete_onboarding(client, auth_headers)
    rec = client.post("/api/v1/recommend", headers=auth_headers)
    assert rec.status_code == 200
    data = rec.json()
    assert data["engine"] == "rule_based"
    total = sum(seg["allocation_pct"] for seg in data["portfolio"])
    assert abs(total - 100.0) < 0.15


def test_v2_recommend_returns_ml_engine(client, auth_headers, ml_artifacts):
    complete_onboarding(client, auth_headers)
    rec = client.post("/api/v2/recommend", headers=auth_headers)
    assert rec.status_code == 200
    data = rec.json()
    assert data["engine"].startswith("ml_")
    seg_total = sum(seg["allocation_pct"] for seg in data["portfolio"])
    inst_total = sum(
        inst["allocation_pct"] for seg in data["portfolio"] for inst in seg["instruments"]
    )
    assert abs(seg_total - 100.0) < 0.2
    assert abs(inst_total - 100.0) < 0.25


def test_v2_returns_503_without_model(client, auth_headers, monkeypatch):
    monkeypatch.setenv("FINBOND_MODELS_DIR", "/nonexistent/finbond_models")

    complete_onboarding(client, auth_headers)
    rec = client.post("/api/v2/recommend", headers=auth_headers)
    assert rec.status_code == 503
    assert "ML model not yet trained" in rec.json()["detail"]


def test_v1_v2_directionally_similar(client, auth_headers, ml_artifacts):
    complete_onboarding(client, auth_headers)
    v1 = client.post("/api/v1/recommend", headers=auth_headers).json()
    v2 = client.post("/api/v2/recommend", headers=auth_headers).json()

    v1_map = {s["segment"]: s["allocation_pct"] for s in v1["portfolio"]}
    v2_map = {s["segment"]: s["allocation_pct"] for s in v2["portfolio"]}

    max_diff = max(abs(v1_map.get(seg, 0) - v2_map.get(seg, 0)) for seg in v1_map)
    assert max_diff <= 20.0  # loose bound: noise + model smoothing
