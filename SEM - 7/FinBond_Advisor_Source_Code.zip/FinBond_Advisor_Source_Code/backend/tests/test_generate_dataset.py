from app.recommendation.constants import SEGMENT_TO_TARGET
from ml.generate_dataset import generate_dataset


def test_generate_dataset_row_count_and_targets(tmp_path):
    output = tmp_path / "synthetic_training_data.csv"
    size = 100
    df = generate_dataset(size=size, noise_std=4.0, output_path=output, seed=123)

    assert len(df) == size
    target_cols = list(SEGMENT_TO_TARGET.values())
    row_sums = df[target_cols].sum(axis=1)
    assert abs(row_sums.mean() - 100.0) < 0.5
    assert (row_sums >= 99.0).all() and (row_sums <= 101.0).all()
