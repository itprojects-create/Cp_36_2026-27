"""Unit and API tests for Phase 4 crash/dip and rebalancing engines."""

from app.market.cache_service import save_snapshot
from app.market.crash_engine import generate_crash_signal
from app.models import RiskAssessment, RiskCategory, UserProfile
from app.recommendation.rebalancing_engine import check_rebalancing


def _make_risk(category: RiskCategory, user_id: int = 1) -> RiskAssessment:
    return RiskAssessment(
        user_id=user_id,
        responses={},
        risk_score=50.0,
        risk_category=category,
    )


def _make_profile(user_id: int = 1, savings: float = 500000, investments: float = 300000) -> UserProfile:
    return UserProfile(user_id=user_id, savings=savings, existing_investments=investments)


def _seed_drawdown(db_session, drawdown_pct: float):
    save_snapshot(
        db_session,
        symbol="NIFTY50",
        source="yfinance",
        value=24000.0,
        meta={"drawdown_from_52w_high_pct": drawdown_pct},
        fetch_success=True,
    )


class TestCrashEngine:
    def test_no_active_correction_below_threshold(self, db_session):
        _seed_drawdown(db_session, 4.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        assert result.status == "no_active_correction"
        assert result.correction_tier is None
        assert result.suggested_deployment_amount is None

    def test_mild_tier_at_6_6_drawdown_matches_regime(self, db_session):
        """Regression: 6.6% drawdown must trigger mild correction, same figure regime uses."""
        from app.market.regime_detector import classify_regime

        _seed_drawdown(db_session, 6.6)
        crash = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        regime = classify_regime(nifty_drawdown_pct=6.6, india_vix=12.0, crude_change_30d_pct=0)
        assert crash.drawdown_pct == 6.6
        assert crash.status == "active_correction"
        assert crash.correction_tier == "mild"
        assert regime.inputs["nifty_drawdown_pct"] == crash.drawdown_pct
        assert regime.regime.value == "SIDEWAYS"

    def test_boundary_exactly_5_pct_triggers_mild(self, db_session):
        _seed_drawdown(db_session, 5.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        assert result.correction_tier == "mild"
        assert result.status == "active_correction"

    def test_mild_tier_moderate_risk(self, db_session):
        _seed_drawdown(db_session, 7.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        assert result.status == "active_correction"
        assert result.correction_tier == "mild"
        assert result.deployment_pct_of_cash == 20.0
        assert result.suggested_deployment_amount == 160000.0  # 20% of 800k
        _seed_drawdown(db_session, 7.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        assert result.status == "active_correction"
        assert result.correction_tier == "mild"
        assert result.deployment_pct_of_cash == 20.0
        assert result.suggested_deployment_amount == 160000.0  # 20% of 800k

    def test_deep_tier_low_risk(self, db_session):
        _seed_drawdown(db_session, 12.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.LOW), []
        )
        assert result.correction_tier == "deep"
        assert result.deployment_pct_of_cash == 15.0

    def test_major_tier_high_risk_capped_at_50_pct(self, db_session):
        _seed_drawdown(db_session, 18.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.HIGH), []
        )
        assert result.correction_tier == "major"
        assert result.deployment_pct_of_cash == 50.0
        assert result.suggested_deployment_amount == 400000.0
        assert "not an all-in deployment" in result.explanation.lower()

    def test_low_risk_major_still_debt_heavy(self, db_session):
        _seed_drawdown(db_session, 18.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.LOW), []
        )
        debt_pct = next(s["allocation_pct"] for s in result.segment_split if s["segment"] == "G-Sec/Debt")
        segment_names = [s["segment"] for s in result.segment_split]
        assert debt_pct >= 40.0
        assert "Small Cap" not in segment_names

    def test_insufficient_cash_zero_profile(self, db_session):
        _seed_drawdown(db_session, 12.0)
        profile = UserProfile(user_id=1, savings=0, existing_investments=0)
        result = generate_crash_signal(
            db_session, 1, profile, _make_risk(RiskCategory.HIGH), []
        )
        assert result.status == "insufficient_cash"
        assert result.available_cash == 0.0
        assert result.suggested_deployment_amount is None
        assert result.deployment_pct_of_cash is None

    def test_disclaimer_non_predictive(self, db_session):
        _seed_drawdown(db_session, 8.0)
        result = generate_crash_signal(
            db_session, 1, _make_profile(), _make_risk(RiskCategory.MODERATE), []
        )
        combined = (result.explanation + result.disclaimer).lower()
        assert "phased deployment" in combined
        assert "not a bottom call" in combined or "continue declining" in combined
        assert "buying opportunity" not in combined
        assert "guaranteed" not in combined


class TestRebalancingEngine:
    def _portfolio(self, **segments):
        return {
            "portfolio": [
                {"segment": k, "allocation_pct": v, "amount": 0, "instruments": []}
                for k, v in segments.items()
            ]
        }

    def test_insufficient_history_single_recommendation(self, db_session):
        from app.models import Recommendation

        db_session.add(
            Recommendation(
                user_id=1,
                input_snapshot={},
                allocation=self._portfolio(**{"Large Cap": 30, "G-Sec/Debt": 70}),
                explanation="test",
            )
        )
        db_session.commit()
        result = check_rebalancing(db_session, 1)
        assert result.status == "insufficient_history"
        assert "two stored recommendations" in result.explanation.lower()

    def test_drift_calculation_and_flagging(self, db_session):
        from datetime import datetime, timedelta, timezone

        from app.models import Recommendation

        now = datetime.now(timezone.utc)
        db_session.add(
            Recommendation(
                user_id=1,
                input_snapshot={},
                allocation=self._portfolio(**{"Large Cap": 40, "G-Sec/Debt": 60}),
                explanation="older",
                generated_at=now - timedelta(days=1),
            )
        )
        db_session.add(
            Recommendation(
                user_id=1,
                input_snapshot={},
                allocation=self._portfolio(**{"Large Cap": 30, "G-Sec/Debt": 70}),
                explanation="newer",
                generated_at=now,
            )
        )
        db_session.commit()
        result = check_rebalancing(db_session, 1, drift_threshold_pp=5.0)
        assert result.status == "rebalance_suggested"
        large = next(s for s in result.segments if s.segment == "Large Cap")
        assert large.current_pct == 40.0
        assert large.target_pct == 30.0
        assert large.drift_pp == 10.0
        assert large.flagged is True
        assert "new contributions" in (large.suggestion or "").lower()
        assert "forced selling" in (large.suggestion or "").lower()

    def test_within_target_range(self, db_session):
        from app.models import Recommendation

        alloc = self._portfolio(**{"Large Cap": 30, "G-Sec/Debt": 70})
        db_session.add(
            Recommendation(user_id=1, input_snapshot={}, allocation=alloc, explanation="a")
        )
        db_session.add(
            Recommendation(user_id=1, input_snapshot={}, allocation=alloc, explanation="b")
        )
        db_session.commit()
        result = check_rebalancing(db_session, 1)
        assert result.status == "within_target_range"


class TestInsightsApi:
    def test_crash_signal_requires_auth(self, client):
        assert client.get("/api/crash-signal").status_code == 401

    def test_rebalance_requires_auth(self, client):
        assert client.post("/api/rebalance-check").status_code == 401

    def test_crash_signal_no_correction(self, client, auth_headers, db_session):
        save_snapshot(
            db_session,
            symbol="NIFTY50",
            source="yfinance",
            value=24000.0,
            meta={"drawdown_from_52w_high_pct": 3.0},
            fetch_success=True,
        )
        r = client.get("/api/crash-signal", headers=auth_headers)
        assert r.status_code == 200
        assert r.json()["status"] == "no_active_correction"

    def test_admin_system_health_and_legacy_market_status(self, client, db_session):
        from app.core.config import settings

        login = client.post(
            "/api/v1/auth/login",
            json={"email": settings.ADMIN_EMAIL, "password": settings.ADMIN_PASSWORD},
        )
        admin_h = {"Authorization": f"Bearer {login.json()['access_token']}"}

        legacy = client.get("/api/v1/admin/market/status", headers=admin_h)
        health = client.get("/api/v1/admin/system-health", headers=admin_h)
        assert legacy.status_code == 200
        assert health.status_code == 200
        assert "sources" in legacy.json()
        assert "market_sources" in health.json()
        assert "thresholds" in health.json()
        assert health.json()["thresholds"]["crash_tier_mild_pct"] == 5.0
