#!/usr/bin/env python3
"""Compare rule-based (v1) vs ML (v2) recommendations for demo profiles."""

from __future__ import annotations

import os
import sys
import uuid
from datetime import datetime

import httpx

BASE_URL = os.getenv("BASE_URL", "http://127.0.0.1:8000").rstrip("/")
API_V1 = f"{BASE_URL}/api/v1"
API_V2 = f"{BASE_URL}/api/v2"
SEGMENTS = ["G-Sec/Debt", "Large Cap", "Mid Cap", "Small Cap", "Gold", "ETF"]

MODERATE_RISK = {
    "portfolio_drop_reaction": 3,
    "income_stability": 3,
    "emergency_fund_presence": 3,
    "debt_load": 3,
    "investment_horizon": 3,
    "capital_preservation": 3,
    "investment_experience": 3,
    "preferred_style": 3,
    "dependents_obligations": 3,
    "volatility_tolerance": 3,
}

SHARED_PROFILE = {
    "age": 40,
    "occupation": "Product Manager",
    "dependents": 2,
    "monthly_income": 120000,
    "monthly_expenses": 60000,
    "savings": 300000,
    "existing_investments": 400000,
    "emergency_fund_months": 5,
    "emi": 10000,
    "monthly_sip": 15000,
    "investment_experience": "intermediate",
}

PROFILES = [
    ("young_aggressive", {
        "profile": {**SHARED_PROFILE, "age": 25, "dependents": 0, "monthly_income": 80000, "monthly_expenses": 40000},
        "goals": [{"goal_type": "wealth_creation", "target_amount": 5000000, "target_year": datetime.now().year + 15, "priority": 1, "current_saved": 50000}],
        "risk": {k: 5 for k in MODERATE_RISK},
    }),
    ("older_conservative", {
        "profile": {**SHARED_PROFILE, "age": 55, "monthly_income": 150000, "monthly_expenses": 80000, "emi": 20000},
        "goals": [{"goal_type": "house", "target_amount": 3000000, "target_year": datetime.now().year + 3, "priority": 1, "current_saved": 800000}],
        "risk": {k: 1 if k == "capital_preservation" else 2 for k in MODERATE_RISK},
    }),
    ("house_10yr", {
        "profile": SHARED_PROFILE,
        "goals": [{"goal_type": "house", "target_amount": 4000000, "target_year": datetime.now().year + 10, "priority": 1, "current_saved": 400000}],
        "risk": MODERATE_RISK,
    }),
    ("wealth_10yr", {
        "profile": SHARED_PROFILE,
        "goals": [{"goal_type": "wealth_creation", "target_amount": 4000000, "target_year": datetime.now().year + 10, "priority": 1, "current_saved": 400000}],
        "risk": MODERATE_RISK,
    }),
]


def run_profile(client: httpx.Client, run_id: str, name: str, demo: dict) -> dict:
    email = f"{name}.{run_id}@example.com"
    password = "DemoPass123!"
    reg = client.post(f"{API_V1}/auth/register", json={"email": email, "password": password})
    reg.raise_for_status()
    headers = {"Authorization": f"Bearer {reg.json()['access_token']}"}

    client.post(f"{API_V1}/user/disclaimer", json={"accepted": True}, headers=headers).raise_for_status()
    client.post(f"{API_V1}/user/profile", json=demo["profile"], headers=headers).raise_for_status()
    client.post(f"{API_V1}/user/goals", json={"goals": demo["goals"]}, headers=headers).raise_for_status()
    client.post(f"{API_V1}/user/risk-assessment", json={"responses": demo["risk"]}, headers=headers).raise_for_status()

    v1 = client.post(f"{API_V1}/recommend", headers=headers)
    v2 = client.post(f"{API_V2}/recommend", headers=headers)
    v1.raise_for_status()
    v2.raise_for_status()
    return {"name": name, "v1": v1.json(), "v2": v2.json()}


def seg_map(rec):
    return {s["segment"]: s["allocation_pct"] for s in rec["portfolio"]}


def main():
    run_id = datetime.now().strftime("%Y%m%d%H%M%S") + uuid.uuid4().hex[:6]
    try:
        httpx.get(f"{BASE_URL}/health", timeout=5).raise_for_status()
    except httpx.HTTPError:
        print(f"ERROR: Backend not reachable at {BASE_URL}", file=sys.stderr)
        sys.exit(1)

    results = []
    with httpx.Client(timeout=30) as client:
        for name, demo in PROFILES:
            print(f"Running {name}...", flush=True)
            results.append(run_profile(client, run_id, name, demo))

    print("\n" + "=" * 140)
    print("V1 (rule_based) vs V2 (ML) — segment allocation comparison")
    print("=" * 140)
    header = f"{'Profile':<22} {'Engine':<12} " + " ".join(f"{s[:6]:>7}" for s in SEGMENTS) + f" {'MaxDiff':>8}"
    print(header)
    print("-" * 140)

    for r in results:
        for engine_key, label in [("v1", "rule_based"), ("v2", r["v2"]["engine"])]:
            sm = seg_map(r[engine_key])
            row = f"{r['name']:<22} {label:<12} " + " ".join(f"{sm.get(s, 0):7.1f}" for s in SEGMENTS)
            if engine_key == "v2":
                v1m, v2m = seg_map(r["v1"]), seg_map(r["v2"])
                max_diff = max(abs(v1m.get(s, 0) - v2m.get(s, 0)) for s in SEGMENTS)
                row += f" {max_diff:8.1f}"
            print(row)

    print("=" * 140)


if __name__ == "__main__":
    main()
