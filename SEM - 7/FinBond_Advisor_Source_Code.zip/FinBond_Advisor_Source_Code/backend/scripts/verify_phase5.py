"""Phase 5 live verification: re-seed + eligibility classification breakdown."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

import httpx

BACKEND = Path(__file__).resolve().parents[1]
BASE = "http://127.0.0.1:8000"


def wait_health(timeout: float = 60.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if httpx.get(f"{BASE}/health", timeout=2).status_code == 200:
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.5)
    return False


def main() -> int:
    sys.path.insert(0, str(BACKEND))
    from app.db.session import SessionLocal
    from app.models import GovernmentScheme
    from app.seed.government_schemes import seed_government_schemes

    db = SessionLocal()
    try:
        db.query(GovernmentScheme).delete()
        db.commit()
        seed_government_schemes(db)
        count = db.query(GovernmentScheme).filter(GovernmentScheme.is_active.is_(True)).count()
        print(f"Re-seeded {count} active schemes into dev DB")
        if count != 10:
            print(f"FAIL: expected 10 schemes, got {count}")
            return 1
    finally:
        db.close()

    import os

    env = os.environ.copy()
    env["MARKET_REFRESH_ENABLED"] = "false"
    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
        cwd=BACKEND,
        env=env,
    )
    try:
        if not wait_health(90):
            print("FAIL: backend did not start")
            return 1

        email = "phase5verify@example.com"
        password = "VerifyPass123!"
        c = httpx.Client(timeout=30)

        c.post(f"{BASE}/api/v1/auth/register", json={"email": email, "password": password})
        token = c.post(f"{BASE}/api/v1/auth/login", json={"email": email, "password": password}).json()["access_token"]
        h = {"Authorization": f"Bearer {token}"}

        schemes = c.get(f"{BASE}/api/schemes", headers=h)
        print(f"\nGET /api/schemes: {schemes.status_code}, count={len(schemes.json())}")

        # Complete onboarding (typical 32yo profile)
        c.post(f"{BASE}/api/v1/user/disclaimer", json={"accepted": True}, headers=h)
        c.post(
            f"{BASE}/api/v1/user/profile",
            json={
                "age": 32,
                "occupation": "Software Engineer",
                "dependents": 1,
                "monthly_income": 120000,
                "monthly_expenses": 60000,
                "savings": 200000,
                "existing_investments": 300000,
                "emergency_fund_months": 5,
                "emi": 15000,
                "monthly_sip": 10000,
                "investment_experience": "intermediate",
            },
            headers=h,
        )
        c.post(
            f"{BASE}/api/v1/user/goals",
            json={"goals": [{"goal_type": "retirement", "target_amount": 5000000, "target_year": 2045, "priority": 1, "current_saved": 300000}]},
            headers=h,
        )
        c.post(
            f"{BASE}/api/v1/user/risk-assessment",
            json={"responses": {k: 3 for k in [
                "portfolio_drop_reaction", "income_stability", "emergency_fund_presence",
                "debt_load", "investment_horizon", "capital_preservation",
                "investment_experience", "preferred_style", "dependents_obligations", "volatility_tolerance",
            ]}},
            headers=h,
        )

        elig = c.post(f"{BASE}/api/schemes/check-eligibility", headers=h)
        results = elig.json()["results"]
        by_class = {}
        for r in results:
            by_class.setdefault(r["classification"], []).append(r["scheme_name"])

        report = {
            "total_schemes": len(schemes.json()),
            "eligibility_breakdown": {k: len(v) for k, v in by_class.items()},
            "eligible": by_class.get("ELIGIBLE", []),
            "may_be_eligible": by_class.get("MAY BE ELIGIBLE", []),
            "not_eligible": by_class.get("NOT ELIGIBLE", []),
        }
        print(json.dumps(report, indent=2))

        ok = len(schemes.json()) == 10 and len(results) == 10
        ok = ok and len(by_class.get("ELIGIBLE", [])) >= 2
        ok = ok and any("PMVVY" in n or "Vaya Vandana" in n for n in by_class.get("NOT ELIGIBLE", []))

        if ok:
            print("\nPASS: 10 schemes seeded; ELIGIBLE and NOT ELIGIBLE classifications present")
        else:
            print("\nFAIL: verification criteria not met")
        return 0 if ok else 1
    finally:
        proc.terminate()
        proc.wait(timeout=15)


if __name__ == "__main__":
    sys.exit(main())
