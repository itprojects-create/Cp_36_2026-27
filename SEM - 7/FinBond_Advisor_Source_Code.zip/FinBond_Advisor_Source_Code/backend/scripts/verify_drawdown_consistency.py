"""Verify crash-signal and market-regime use the same drawdown and tier logic is consistent."""

from __future__ import annotations

import json
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

from app.db.session import SessionLocal
from app.market.cache_service import get_latest_snapshot, save_snapshot
from app.market.crash_engine import generate_crash_signal
from app.market.regime_detector import classify_regime
from app.models import InvestmentInstrument, RiskAssessment, RiskCategory, UserProfile


def main() -> int:
    db = SessionLocal()
    try:
        nifty = get_latest_snapshot(db, "NIFTY50")
        if nifty is None:
            print("No NIFTY50 snapshot in DB — seeding 6.6% for consistency check")
            save_snapshot(
                db,
                symbol="NIFTY50",
                source="yfinance",
                value=24000.0,
                meta={"drawdown_from_52w_high_pct": 6.6, "nifty_trend_up": False},
                fetch_success=True,
            )
            nifty = get_latest_snapshot(db, "NIFTY50")

        drawdown = (nifty.meta or {}).get("drawdown_from_52w_high_pct")
        vix_snap = get_latest_snapshot(db, "INDIA_VIX")
        vix = vix_snap.value if vix_snap else 12.2

        regime = classify_regime(
            nifty_drawdown_pct=drawdown,
            india_vix=vix,
            crude_change_30d_pct=0,
            nifty_trend_up=bool((nifty.meta or {}).get("nifty_trend_up")),
        )

        profile = UserProfile(user_id=999, savings=500000, existing_investments=300000)
        risk = RiskAssessment(
            user_id=999,
            responses={},
            risk_score=50,
            risk_category=RiskCategory.MODERATE,
        )
        instruments = db.query(InvestmentInstrument).all()
        crash = generate_crash_signal(db, 999, profile, risk, instruments)

        report = {
            "nifty_snapshot_drawdown": drawdown,
            "regime_classification": regime.regime.value,
            "regime_basis_snippet": regime.classification_basis[:100],
            "regime_inputs_drawdown": regime.inputs.get("nifty_drawdown_pct"),
            "crash_status": crash.status,
            "crash_drawdown": crash.drawdown_pct,
            "crash_tier": crash.correction_tier,
            "crash_explanation_snippet": crash.explanation[:120],
            "consistent_drawdown": drawdown == crash.drawdown_pct == regime.inputs.get("nifty_drawdown_pct"),
            "expected_mild_at_6_6": crash.status == "active_correction" and crash.correction_tier == "mild"
            if drawdown and float(drawdown) >= 5.0 and float(drawdown) < 10.0
            else None,
        }
        print(json.dumps(report, indent=2))

        ok = True
        if drawdown is not None and float(drawdown) >= 5.0:
            if crash.status == "no_active_correction":
                print("\nFAIL: drawdown >= 5% but crash says no_active_correction")
                ok = False
            elif float(drawdown) < 10.0 and crash.correction_tier != "mild":
                print(f"\nFAIL: expected mild tier at {drawdown}%, got {crash.correction_tier}")
                ok = False
            else:
                print(f"\nPASS: {drawdown}% correctly triggers {crash.correction_tier} / {crash.status}")

        if report["consistent_drawdown"]:
            print("PASS: regime and crash read the same drawdown value")
        else:
            print("FAIL: drawdown mismatch between endpoints")
            ok = False

        return 0 if ok else 1
    finally:
        db.close()


if __name__ == "__main__":
    sys.exit(main())
