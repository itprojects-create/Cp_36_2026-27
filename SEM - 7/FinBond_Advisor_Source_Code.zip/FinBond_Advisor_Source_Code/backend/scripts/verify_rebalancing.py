"""Verify rebalancing drift table with two stored recommendations."""

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))

from app.db.session import SessionLocal
from app.models import Recommendation
from app.recommendation.rebalancing_engine import check_rebalancing


def main() -> int:
    db = SessionLocal()
    try:
        db.query(Recommendation).filter(Recommendation.user_id == 8888).delete()
        db.commit()

        now = datetime.now(timezone.utc)
        db.add(
            Recommendation(
                user_id=8888,
                input_snapshot={"investable_amount": 800000},
                allocation={
                    "portfolio": [
                        {"segment": "Large Cap", "allocation_pct": 40, "amount": 0, "instruments": []},
                        {"segment": "G-Sec/Debt", "allocation_pct": 60, "amount": 0, "instruments": []},
                    ]
                },
                explanation="older",
                generated_at=now - timedelta(days=1),
            )
        )
        db.add(
            Recommendation(
                user_id=8888,
                input_snapshot={"investable_amount": 800000},
                allocation={
                    "portfolio": [
                        {"segment": "Large Cap", "allocation_pct": 30, "amount": 0, "instruments": []},
                        {"segment": "G-Sec/Debt", "allocation_pct": 70, "amount": 0, "instruments": []},
                    ]
                },
                explanation="newer",
                generated_at=now,
            )
        )
        db.commit()

        result = check_rebalancing(db, 8888)
        report = {
            "status": result.status,
            "flagged_count": len(result.flagged_segments),
            "segments": [
                {
                    "segment": s.segment,
                    "current_pct": s.current_pct,
                    "target_pct": s.target_pct,
                    "drift_pp": s.drift_pp,
                    "flagged": s.flagged,
                }
                for s in result.segments
                if s.segment in ("Large Cap", "G-Sec/Debt")
            ],
        }
        print(json.dumps(report, indent=2))

        ok = result.status == "rebalance_suggested" and len(result.flagged_segments) >= 1
        if ok:
            print("\nPASS: drift table populated with flagged segments")
        else:
            print("\nFAIL: expected rebalance_suggested with flagged segments")
        return 0 if ok else 1
    finally:
        db.query(Recommendation).filter(Recommendation.user_id == 8888).delete()
        db.commit()
        db.close()


if __name__ == "__main__":
    sys.exit(main())
