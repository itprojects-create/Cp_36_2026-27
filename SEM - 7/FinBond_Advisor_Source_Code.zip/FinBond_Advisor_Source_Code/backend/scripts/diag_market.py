#!/usr/bin/env python3
"""One-shot market layer diagnostic — system-health + DB snapshots."""

from __future__ import annotations

import json
import os

import httpx
from sqlalchemy import create_engine, text

from app.core.config import settings

BASE = os.getenv("BASE_URL", "http://127.0.0.1:8000").rstrip("/")


def main() -> None:
    print(f"MARKET_REFRESH_ENABLED (this shell): {settings.MARKET_REFRESH_ENABLED}")
    print(f"Env var raw: {os.environ.get('MARKET_REFRESH_ENABLED', '<unset>')}")

    login = httpx.post(
        f"{BASE}/api/v1/auth/login",
        json={"email": settings.ADMIN_EMAIL, "password": settings.ADMIN_PASSWORD},
        timeout=10,
    )
    login.raise_for_status()
    headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

    health = httpx.get(f"{BASE}/api/v1/admin/system-health", headers=headers, timeout=10)
    health.raise_for_status()
    print("\n=== GET /api/v1/admin/system-health ===")
    print(json.dumps(health.json(), indent=2))

    pulse = httpx.get(f"{BASE}/api/market-pulse", headers=headers, timeout=10)
    pulse.raise_for_status()
    print("\n=== GET /api/market-pulse (items) ===")
    data = pulse.json()
    items = data.get("items", data if isinstance(data, list) else [])
    for item in items:
        print(
            f"  {item.get('label')}: status={item.get('status')} "
            f"value={item.get('value')} last={item.get('last_updated')} "
            f"stale={item.get('is_stale')} msg={item.get('message')}"
        )

    engine = create_engine(settings.DATABASE_URL)
    with engine.connect() as conn:
        print("\n=== market_snapshots (all) ===")
        rows = conn.execute(
            text(
                "SELECT symbol, value, fetched_at, fetch_success FROM market_snapshots ORDER BY fetched_at DESC"
            )
        ).fetchall()
        for row in rows:
            print(" ", row)
        print("\n=== market_fetch_log (all) ===")
        try:
            logs = conn.execute(
                text(
                    "SELECT source, last_success_at, last_attempt_at, last_error, used_stale_fallback "
                    "FROM market_fetch_log ORDER BY source"
                )
            ).fetchall()
            for log in logs:
                print(" ", log)
        except Exception as exc:
            print(" ", exc)


if __name__ == "__main__":
    main()
