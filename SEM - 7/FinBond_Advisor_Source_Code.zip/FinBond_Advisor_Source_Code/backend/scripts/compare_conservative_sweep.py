#!/usr/bin/env python3
"""Conservative-profile v1 vs v2 sweep — debt-segment gap consistency check."""

from __future__ import annotations

import os
import sys
import uuid
from datetime import datetime

import httpx

BASE_URL = os.getenv("BASE_URL", "http://127.0.0.1:8000").rstrip("/")
API_V1 = f"{BASE_URL}/api/v1"
API_V2 = f"{BASE_URL}/api/v2"
SEGMENTS = ["G-Sec/Debt", "Large Cap", "Mid Cap", "Small Cap", "Gold", "ETF"]

ALL_LOW = {k: 1 for k in [
    "portfolio_drop_reaction", "income_stability", "emergency_fund_presence",
    "debt_load", "investment_horizon", "capital_preservation",
    "investment_experience", "preferred_style", "dependents_obligations", "volatility_tolerance",
]}

CONSERVATIVE_PROFILES = [
    ("older_conservative_house_3yr", {
        "profile": {"age": 55, "occupation": "Senior Manager", "dependents": 2, "monthly_income": 150000,
                    "monthly_expenses": 80000, "savings": 500000, "existing_investments": 1000000,
                    "emergency_fund_months": 4, "emi": 20000, "monthly_sip": 5000, "investment_experience": "intermediate"},
        "goals": [{"goal_type": "house", "target_amount": 3000000, "target_year": datetime.now().year + 3, "priority": 1, "current_saved": 800000}],
        "risk": ALL_LOW,
    }),
    ("long_horizon_low_risk_retirement", {
        "profile": {"age": 35, "occupation": "Teacher", "dependents": 1, "monthly_income": 100000,
                    "monthly_expenses": 60000, "savings": 100000, "existing_investments": 200000,
                    "emergency_fund_months": 1.5, "emi": 15000, "monthly_sip": 3000, "investment_experience": "beginner"},
        "goals": [{"goal_type": "retirement", "target_amount": 8000000, "target_year": datetime.now().year + 20, "priority": 1, "current_saved": 200000}],
        "risk": ALL_LOW,
    }),
    ("pre_retiree_emergency_fund", {
        "profile": {"age": 58, "occupation": "Bank Officer", "dependents": 0, "monthly_income": 90000,
                    "monthly_expenses": 55000, "savings": 800000, "existing_investments": 1200000,
                    "emergency_fund_months": 8, "emi": 0, "monthly_sip": 2000, "investment_experience": "beginner"},
        "goals": [{"goal_type": "emergency", "target_amount": 500000, "target_year": datetime.now().year + 2, "priority": 1, "current_saved": 400000}],
        "risk": ALL_LOW,
    }),
    ("young_low_risk_salaried", {
        "profile": {"age": 28, "occupation": "Government Employee", "dependents": 0, "monthly_income": 70000,
                    "monthly_expenses": 45000, "savings": 200000, "existing_investments": 100000,
                    "emergency_fund_months": 6, "emi": 0, "monthly_sip": 5000, "investment_experience": "beginner"},
        "goals": [{"goal_type": "education", "target_amount": 2000000, "target_year": datetime.now().year + 8, "priority": 1, "current_saved": 50000}],
        "risk": ALL_LOW,
    }),
]


def seg_map(rec):
    return {s["segment"]: s["allocation_pct"] for s in rec["portfolio"]}


def pct(m, segment):
    return m.get(segment, 0.0)


def run_one(client, run_id, name, demo):
    email = f"{name}.{run_id}@example.com"
    reg = client.post(f"{API_V1}/auth/register", json={"email": email, "password": "DemoPass123!"})
    reg.raise_for_status()
    h = {"Authorization": f"Bearer {reg.json()['access_token']}"}
    client.post(f"{API_V1}/user/disclaimer", json={"accepted": True}, headers=h).raise_for_status()
    client.post(f"{API_V1}/user/profile", json=demo["profile"], headers=h).raise_for_status()
    client.post(f"{API_V1}/user/goals", json={"goals": demo["goals"]}, headers=h).raise_for_status()
    client.post(f"{API_V1}/user/risk-assessment", json={"responses": demo["risk"]}, headers=h).raise_for_status()
    v1 = client.post(f"{API_V1}/recommend", headers=h).json()
    v2 = client.post(f"{API_V2}/recommend", headers=h).json()
    return v1, v2


def main():
    run_id = datetime.now().strftime("%Y%m%d%H%M%S") + uuid.uuid4().hex[:6]
    httpx.get(f"{BASE_URL}/health", timeout=5).raise_for_status()

    print("Conservative profile v1 vs v2 — debt segment focus")
    print("=" * 100)
    print(f"{'Profile':<35} {'Risk':>5} {'Cat':<8} {'Debt v1':>8} {'Debt v2':>8} {'Debt d':>8} {'MaxDiff':>8}")
    print("-" * 100)

    debt_gaps = []
    with httpx.Client(timeout=30) as client:
        for name, demo in CONSERVATIVE_PROFILES:
            v1, v2 = run_one(client, run_id, name, demo)
            m1, m2 = seg_map(v1), seg_map(v2)
            debt_d = pct(m2, "G-Sec/Debt") - pct(m1, "G-Sec/Debt")
            max_d = max(abs(pct(m1, s) - pct(m2, s)) for s in SEGMENTS)
            debt_gaps.append(debt_d)
            print(
                f"{name:<35} {v1['risk']['score']:5.1f} {v1['risk']['category']:<8} "
                f"{pct(m1, 'G-Sec/Debt'):8.1f} {pct(m2, 'G-Sec/Debt'):8.1f} {debt_d:+8.1f} {max_d:8.1f}"
            )
            print(f"  Segment deltas (ML - rule): ", end="")
            print(", ".join(f"{s[:6]}:{pct(m2, s)-pct(m1, s):+.1f}" for s in SEGMENTS))

    print("=" * 100)
    print(f"Debt gaps (ML - rule): {[round(g, 1) for g in debt_gaps]} pp")
    print(f"Range: {min(debt_gaps):+.1f} to {max(debt_gaps):+.1f} pp")


if __name__ == "__main__":
    main()
