"""Quick stale-flag check against temp DB with cached data."""
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
from app.models import MarketSnapshot

BASE = "http://127.0.0.1:8000"
DB = BACKEND / "phase3_verify_stale.db"


def main():
    if DB.exists():
        DB.unlink()

    env = os.environ.copy()
    env["DATABASE_URL"] = f"sqlite:///{DB.as_posix()}"
    env["MARKET_REFRESH_ENABLED"] = "true"

    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
        cwd=BACKEND, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    try:
        for _ in range(180):
            try:
                if httpx.get(f"{BASE}/health", timeout=2).status_code == 200:
                    break
            except httpx.HTTPError:
                pass
            time.sleep(0.5)

        email, pw = "stalecheck@example.com", "StalePass123!"
        c = httpx.Client(timeout=30)
        c.post(f"{BASE}/api/v1/auth/register", json={"email": email, "password": pw})
        h = {"Authorization": f"Bearer {c.post(f'{BASE}/api/v1/auth/login', json={'email': email, 'password': pw}).json()['access_token']}"}

        engine = create_engine(env["DATABASE_URL"])
        db = sessionmaker(bind=engine)()
        old = datetime.now(timezone.utc) - timedelta(hours=3)
        for sym in ("NIFTY50", "INDIA_VIX"):
            snaps = db.query(MarketSnapshot).filter(MarketSnapshot.symbol == sym).all()
            for snap in snaps:
                snap.fetched_at = old
        db.commit()
        db.close()

        regime = c.get(f"{BASE}/api/market-regime", headers=h).json()
        nifty = next(i for i in c.get(f"{BASE}/api/market-pulse", headers=h).json()["indices"] if i["symbol"] == "NIFTY50")
        ok = regime["is_stale"] and nifty["is_stale"] and regime["regime"] != "UNAVAILABLE"
        print(json.dumps({"regime_is_stale": regime["is_stale"], "nifty_is_stale": nifty["is_stale"], "regime": regime["regime"], "nifty_status": nifty["status"], "nifty_value": nifty["value"]}, indent=2))
        print("PASS" if ok else "FAIL")
        return 0 if ok else 1
    finally:
        proc.terminate()
        proc.wait(timeout=15)
        time.sleep(1)
        if DB.exists():
            try:
                DB.unlink()
            except OSError:
                pass


if __name__ == "__main__":
    sys.exit(main())
