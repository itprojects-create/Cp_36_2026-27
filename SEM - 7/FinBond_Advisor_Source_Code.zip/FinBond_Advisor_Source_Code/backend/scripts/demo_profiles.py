#!/usr/bin/env python3
"""
Automated demo profile comparison — drives the full FinBond API flow for test profiles.

Run:
    cd finbond-advisor/backend
    python scripts/demo_profiles.py

Requires a running backend at BASE_URL (default http://127.0.0.1:8000).
"""

from __future__ import annotations

import os
import sys
import uuid
from datetime import datetime

import httpx

BASE_URL = os.getenv("BASE_URL", "http://127.0.0.1:8000").rstrip("/")
API = f"{BASE_URL}/api/v1"
SEGMENTS = ["G-Sec/Debt", "Large Cap", "Mid Cap", "Small Cap", "Gold", "ETF"]

# Risk questionnaire answer sets (Likert 1–5)
AGGRESSIVE_RISK = {
    "portfolio_drop_reaction": 5,
    "income_stability": 5,
    "emergency_fund_presence": 5,
    "debt_load": 5,
    "investment_horizon": 5,
    "capital_preservation": 5,
    "investment_experience": 5,
    "preferred_style": 5,
    "dependents_obligations": 5,
    "volatility_tolerance": 5,
}

CONSERVATIVE_RISK = {
    "portfolio_drop_reaction": 1,
    "income_stability": 3,
    "emergency_fund_presence": 2,
    "debt_load": 2,
    "investment_horizon": 2,
    "capital_preservation": 1,
    "investment_experience": 1,
    "preferred_style": 1,
    "dependents_obligations": 2,
    "volatility_tolerance": 1,
}

MODERATE_RISK = {
    "portfolio_drop_reaction": 3,
    "income_stability": 3,
    "emergency_fund_presence": 3,
    "debt_load": 3,
    "investment_horizon": 3,
    "capital_preservation": 3,
    "investment_experience": 3,
    "preferred_style": 3,
    "dependents_obligations": 3,
    "volatility_tolerance": 3,
}

CURRENT_YEAR = datetime.now().year

# Shared base for house_10yr / wealth_10yr (only goal type differs)
SHARED_40YO_PROFILE = {
    "age": 40,
    "occupation": "Product Manager",
    "dependents": 2,
    "monthly_income": 120000,
    "monthly_expenses": 60000,
    "savings": 300000,
    "existing_investments": 400000,
    "emergency_fund_months": 5,
    "emi": 10000,
    "monthly_sip": 15000,
    "investment_experience": "intermediate",
}

DEMO_PROFILES = [
    {
        "name": "young_aggressive",
        "profile": {
            "age": 25,
            "occupation": "Software Developer",
            "dependents": 0,
            "monthly_income": 80000,
            "monthly_expenses": 40000,
            "savings": 150000,
            "existing_investments": 50000,
            "emergency_fund_months": 5,
            "emi": 0,
            "monthly_sip": 10000,
            "investment_experience": "advanced",
        },
        "goals": [
            {
                "goal_type": "wealth_creation",
                "target_amount": 5000000,
                "target_year": CURRENT_YEAR + 15,
                "priority": 1,
                "current_saved": 50000,
            }
        ],
        "risk_responses": AGGRESSIVE_RISK,
    },
    {
        "name": "older_conservative",
        "profile": {
            "age": 55,
            "occupation": "Senior Manager",
            "dependents": 2,
            "monthly_income": 150000,
            "monthly_expenses": 80000,
            "savings": 500000,
            "existing_investments": 1000000,
            "emergency_fund_months": 4,
            "emi": 20000,
            "monthly_sip": 5000,
            "investment_experience": "intermediate",
        },
        "goals": [
            {
                "goal_type": "house",
                "target_amount": 3000000,
                "target_year": CURRENT_YEAR + 3,
                "priority": 1,
                "current_saved": 800000,
            }
        ],
        "risk_responses": CONSERVATIVE_RISK,
    },
    {
        "name": "long_horizon_low_risk",
        "profile": {
            "age": 35,
            "occupation": "Teacher",
            "dependents": 1,
            "monthly_income": 100000,
            "monthly_expenses": 60000,
            "savings": 100000,
            "existing_investments": 200000,
            "emergency_fund_months": 1.5,
            "emi": 15000,
            "monthly_sip": 3000,
            "investment_experience": "beginner",
        },
        "goals": [
            {
                "goal_type": "retirement",
                "target_amount": 8000000,
                "target_year": CURRENT_YEAR + 20,
                "priority": 1,
                "current_saved": 200000,
            }
        ],
        "risk_responses": CONSERVATIVE_RISK,
    },
    {
        "name": "house_10yr",
        "profile": SHARED_40YO_PROFILE.copy(),
        "goals": [
            {
                "goal_type": "house",
                "target_amount": 4000000,
                "target_year": CURRENT_YEAR + 10,
                "priority": 1,
                "current_saved": 400000,
            }
        ],
        "risk_responses": MODERATE_RISK.copy(),
    },
    {
        "name": "wealth_10yr",
        "profile": SHARED_40YO_PROFILE.copy(),
        "goals": [
            {
                "goal_type": "wealth_creation",
                "target_amount": 4000000,
                "target_year": CURRENT_YEAR + 10,
                "priority": 1,
                "current_saved": 400000,
            }
        ],
        "risk_responses": MODERATE_RISK.copy(),
    },
]


def check_backend(client: httpx.Client) -> None:
    try:
        response = client.get(f"{BASE_URL}/health", timeout=5.0)
        response.raise_for_status()
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        print(
            f"ERROR: Cannot reach backend at {BASE_URL}\n"
            "Start the API first:\n"
            "  cd finbond-advisor/backend\n"
            "  uvicorn app.main:app --reload --host 127.0.0.1 --port 8000",
            file=sys.stderr,
        )
        raise SystemExit(1) from exc
    except httpx.HTTPError as exc:
        print(f"ERROR: Backend health check failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


def run_profile(client: httpx.Client, run_id: str, demo: dict) -> dict:
    email = f"{demo['name']}.{run_id}@example.com"
    password = "DemoPass123!"

    # Register
    reg = client.post(f"{API}/auth/register", json={"email": email, "password": password})
    reg.raise_for_status()
    token = reg.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # Full onboarding flow
    client.post(f"{API}/user/disclaimer", json={"accepted": True}, headers=headers).raise_for_status()
    client.post(f"{API}/user/profile", json=demo["profile"], headers=headers).raise_for_status()
    client.post(f"{API}/user/goals", json={"goals": demo["goals"]}, headers=headers).raise_for_status()
    client.post(
        f"{API}/user/risk-assessment",
        json={"responses": demo["risk_responses"]},
        headers=headers,
    ).raise_for_status()

    rec = client.post(f"{API}/recommend", headers=headers)
    rec.raise_for_status()
    data = rec.json()

    return {
        "name": demo["name"],
        "email": email,
        "recommendation": data,
    }


def segment_pct_map(portfolio: list[dict]) -> dict[str, float]:
    return {seg["segment"]: seg["allocation_pct"] for seg in portfolio}


def top_instrument_map(portfolio: list[dict]) -> dict[str, str]:
    tops = {}
    for seg in portfolio:
        if seg["instruments"]:
            tops[seg["segment"]] = seg["instruments"][0]["name"]
        else:
            tops[seg["segment"]] = "-"
    return tops


def print_comparison_table(results: list[dict], run_id: str) -> None:
    headers = (
        ["Profile", "Risk", "Category"]
        + [f"{s}%" for s in SEGMENTS]
        + ["Top Inst/Seg"]
    )

    rows = []
    for result in results:
        rec = result["recommendation"]
        segs = segment_pct_map(rec["portfolio"])
        tops = top_instrument_map(rec["portfolio"])
        top_summary = "; ".join(f"{k[:8]}:{v[:18]}" for k, v in tops.items() if v != "-")

        row = [
            result["name"],
            str(rec["risk"]["score"]),
            rec["risk"]["category"],
        ]
        for segment in SEGMENTS:
            row.append(f"{segs.get(segment, 0):.1f}")
        row.append(top_summary[:60] + ("..." if len(top_summary) > 60 else ""))
        rows.append(row)

    col_widths = [max(len(h), max(len(r[i]) for r in rows)) for i, h in enumerate(headers)]

    def fmt_row(cells):
        return " | ".join(c.ljust(col_widths[i]) for i, c in enumerate(cells))

    print("\n" + "=" * 120)
    print("FINBOND DEMO PROFILE COMPARISON")
    print(f"Backend: {BASE_URL}  |  Run ID: {run_id}")
    print("=" * 120)
    print(fmt_row(headers))
    print("-+-".join("-" * w for w in col_widths))
    for row in rows:
        print(fmt_row(row))
    print("=" * 120)


def print_explanations(results: list[dict]) -> None:
    print("\nEXPLANATIONS (why this was recommended)\n")
    for result in results:
        rec = result["recommendation"]
        print(f"--- {result['name']} ---")
        print(rec["explanation"])
        print()


def print_goal_comparison_note(results: list[dict]) -> None:
    by_name = {r["name"]: r["recommendation"] for r in results}
    if "house_10yr" not in by_name or "wealth_10yr" not in by_name:
        return

    house_segs = segment_pct_map(by_name["house_10yr"]["portfolio"])
    wealth_segs = segment_pct_map(by_name["wealth_10yr"]["portfolio"])

    print("GOAL-TYPE ISOLATION CHECK (house_10yr vs wealth_10yr - same horizon and risk answers)")
    diffs = []
    for segment in SEGMENTS:
        h = house_segs.get(segment, 0)
        w = wealth_segs.get(segment, 0)
        if abs(h - w) > 0.01:
            diffs.append(f"  {segment}: house={h:.2f}% vs wealth={w:.2f}% (diff {w - h:+.2f}%)")

    if diffs:
        print("  Allocations DIFFER (goal adjustment is working):")
        print("\n".join(diffs))
    else:
        print("  WARNING: Allocations are IDENTICAL — goal-adjustment logic may not be applied.")
    print()


def main() -> None:
    run_id = datetime.now().strftime("%Y%m%d%H%M%S") + uuid.uuid4().hex[:6]

    with httpx.Client(timeout=30.0) as client:
        check_backend(client)
        results = []
        for demo in DEMO_PROFILES:
            print(f"Running profile: {demo['name']}...", flush=True)
            results.append(run_profile(client, run_id, demo))

    print_comparison_table(results, run_id)
    print_goal_comparison_note(results)
    print_explanations(results)


if __name__ == "__main__":
    main()
