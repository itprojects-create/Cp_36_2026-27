"""
Phase 3 live verification script.
Run while backend is NOT running for cold-start checks, or against a running server for live data.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

BASE = "http://127.0.0.1:8000"
BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
USER_EMAIL = "phase3verify@example.com"
USER_PASS = "VerifyPass123!"


def wait_health(timeout: float = 120.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            r = httpx.get(f"{BASE}/health", timeout=2.0)
            if r.status_code == 200:
                return True
        except httpx.HTTPError:
            pass
        time.sleep(0.5)
    return False


def register_and_login(client: httpx.Client) -> dict:
    client.post(
        f"{BASE}/api/v1/auth/register",
        json={"email": USER_EMAIL, "password": USER_PASS},
    )
    r = client.post(
        f"{BASE}/api/v1/auth/login",
        json={"email": USER_EMAIL, "password": USER_PASS},
    )
    r.raise_for_status()
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def admin_login(client: httpx.Client) -> dict:
    email = os.environ.get("ADMIN_EMAIL", "admin@finbond.demo")
    password = os.environ.get("ADMIN_PASSWORD", "Admin@FinBond2024")
    r = client.post(
        f"{BASE}/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    r.raise_for_status()
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def print_section(title: str) -> None:
    print(f"\n{'=' * 60}\n{title}\n{'=' * 60}")


def check_unavailable_states(pulse: dict) -> list[str]:
    issues = []
    for item in pulse["indices"]:
        if item["value"] == 0:
            issues.append(f"{item['symbol']}: value is 0 (should be null/unavailable)")
        if item["status"] != "unavailable" and item["value"] is None:
            issues.append(f"{item['symbol']}: null value but status not unavailable")
    if pulse["gsec_yield"]["value"] == 0 and pulse["gsec_yield"]["status"] == "available":
        issues.append("G-Sec shows 0 as available")
    return issues


def main() -> int:
    results: list[tuple[str, bool, str]] = []

    # --- Check 1: unavailable with refresh disabled (fresh DB) ---
    print_section("CHECK 1: Unavailable states (no cache, refresh disabled)")
    cold_db = BACKEND / "phase3_verify_cold.db"
    if cold_db.exists():
        cold_db.unlink()

    env = os.environ.copy()
    env["DATABASE_URL"] = f"sqlite:///{cold_db.as_posix()}"
    env["MARKET_REFRESH_ENABLED"] = "false"

    proc = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
        cwd=BACKEND,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    try:
        if not wait_health(30):
            results.append(("Unavailable on cold start", False, "Server did not start"))
        else:
            with httpx.Client(timeout=30.0) as client:
                headers = register_and_login(client)
                r = client.get(f"{BASE}/api/market-pulse", headers=headers)
                r.raise_for_status()
                pulse = r.json()
                print(json.dumps(
                    {
                        "indices": [{k: i[k] for k in ("symbol", "value", "status")} for i in pulse["indices"]],
                        "gsec": {k: pulse["gsec_yield"][k] for k in ("value", "status", "source")},
                    },
                    indent=2,
                ))
                issues = check_unavailable_states(pulse)
                all_unavail = all(i["status"] == "unavailable" for i in pulse["indices"])
                null_not_zero = all(i["value"] is None for i in pulse["indices"])
                ok = all_unavail and null_not_zero and not issues
                msg = "All indices unavailable with null values" if ok else f"Issues: {issues or 'unexpected states'}"
                results.append(("Unavailable on cold start", ok, msg))
    finally:
        proc.terminate()
        proc.wait(timeout=10)
        time.sleep(1)

    # --- Check 2: Live fetch with refresh enabled ---
    print_section("CHECK 2: Live data population (refresh enabled, cold DB)")
    live_db = BACKEND / "phase3_verify_live.db"
    if live_db.exists():
        live_db.unlink()

    env2 = os.environ.copy()
    env2["DATABASE_URL"] = f"sqlite:///{live_db.as_posix()}"
    env2["MARKET_REFRESH_ENABLED"] = "true"

    proc2 = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "8000"],
        cwd=BACKEND,
        env=env2,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    try:
        print("Waiting for startup (includes yfinance + AMFI fetch)...")
        t0 = time.time()
        if not wait_health(180):
            results.append(("Live data population", False, "Server did not start within 180s"))
        else:
            startup_s = round(time.time() - t0, 1)
            print(f"Server ready after {startup_s}s")
            with httpx.Client(timeout=30.0) as client:
                headers = register_and_login(client)
                r = client.get(f"{BASE}/api/market-pulse", headers=headers)
                pulse = r.json()
                nifty = next((i for i in pulse["indices"] if i["symbol"] == "NIFTY50"), None)
                sensex = next((i for i in pulse["indices"] if i["symbol"] == "SENSEX"), None)
                vix = pulse.get("volatility")
                crude = pulse["commodities"][0] if pulse["commodities"] else None

                print(json.dumps(
                    {
                        "NIFTY50": {k: nifty[k] for k in ("value", "status", "is_stale")} if nifty else None,
                        "SENSEX": {k: sensex[k] for k in ("value", "status")} if sensex else None,
                        "VIX": {k: vix[k] for k in ("value", "status")} if vix else None,
                        "CRUDE": {k: crude[k] for k in ("value", "status")} if crude else None,
                        "mf_navs_available": sum(1 for n in pulse["mutual_fund_navs"] if n["status"] == "available"),
                        "mf_navs_total": len(pulse["mutual_fund_navs"]),
                    },
                    indent=2,
                ))

                ok = True
                notes = []
                if not nifty or nifty["status"] != "available" or nifty["value"] is None:
                    ok = False
                    notes.append("Nifty unavailable")
                elif nifty["value"] < 15000 or nifty["value"] > 40000:
                    ok = False
                    notes.append(f"Nifty value implausible: {nifty['value']}")
                else:
                    notes.append(f"Nifty={nifty['value']:,.2f}")

                if vix and vix["status"] == "available" and vix["value"] is not None:
                    notes.append(f"VIX={vix['value']:.2f}")
                    if vix["value"] < 5 or vix["value"] > 50:
                        notes.append(f"VIX looks unusual: {vix['value']}")

                if crude and crude["status"] == "available":
                    notes.append(f"Crude={crude['value']:.2f}")

                mf_ok = any(n["status"] == "available" for n in pulse["mutual_fund_navs"])
                if not mf_ok:
                    notes.append("No AMFI NAVs cached yet (network/parse issue?)")

                results.append(("Live data population", ok, "; ".join(notes)))

                # --- Check 3: Admin G-Sec ---
                print_section("CHECK 3: Admin G-Sec yield on user Market Pulse")
                admin_h = admin_login(client)
                client.put(f"{BASE}/api/v1/admin/gsec", json={"yield_pct": 7.15}, headers=admin_h)
                r2 = client.get(f"{BASE}/api/market-pulse", headers=headers)
                gsec = r2.json()["gsec_yield"]
                print(json.dumps(gsec, indent=2))
                gsec_ok = (
                    gsec["status"] == "available"
                    and gsec["value"] == 7.15
                    and gsec["source"] == "admin_manual"
                )
                results.append((
                    "Admin G-Sec on user pulse",
                    gsec_ok,
                    f"yield={gsec.get('value')}, source={gsec.get('source')}, status={gsec.get('status')}",
                ))

                # --- Check 5: Regime wording ---
                print_section("CHECK 5: Regime classification wording")
                regime_r = client.get(f"{BASE}/api/market-regime", headers=headers)
                regime = regime_r.json()
                print(json.dumps(
                    {k: regime[k] for k in ("regime", "classification_basis", "disclaimer", "data_status")},
                    indent=2,
                ))
                basis = regime.get("classification_basis", "")
                disclaimer = regime.get("disclaimer", "")
                wording_ok = (
                    "currently classified as" in basis.lower()
                    and "not a prediction" in disclaimer.lower()
                    and not any(w in basis.lower() for w in ("will be", "expect", "forecast", "predict"))
                )
                results.append((
                    "Regime non-predictive wording",
                    wording_ok,
                    f"regime={regime.get('regime')}; basis snippet: {basis[:80]}...",
                ))

                # --- Check 4: Stale fallback via DB manipulation ---
                print_section("CHECK 4: Stale cache fallback")
                from sqlalchemy import create_engine
                from sqlalchemy.orm import sessionmaker
                from app.models import MarketSnapshot

                engine = create_engine(env2["DATABASE_URL"])
                Session = sessionmaker(bind=engine)
                db = Session()
                old = datetime.now(timezone.utc) - timedelta(hours=3)
                for sym in ("NIFTY50", "INDIA_VIX"):
                    snap = (
                        db.query(MarketSnapshot)
                        .filter(MarketSnapshot.symbol == sym, MarketSnapshot.fetch_success.is_(True))
                        .order_by(MarketSnapshot.fetched_at.desc())
                        .first()
                    )
                    if snap:
                        snap.fetched_at = old
                db.commit()
                db.close()

                stale_r = client.get(f"{BASE}/api/market-regime", headers=headers)
                stale_data = stale_r.json()
                nifty_pulse = client.get(f"{BASE}/api/market-pulse", headers=headers).json()
                nifty_item = next(i for i in nifty_pulse["indices"] if i["symbol"] == "NIFTY50")
                stale_ok = stale_data.get("is_stale") is True and nifty_item.get("is_stale") is True
                results.append((
                    "Stale fallback flags",
                    stale_ok,
                    f"regime is_stale={stale_data.get('is_stale')}, nifty is_stale={nifty_item.get('is_stale')}, regime still={stale_data.get('regime')}",
                ))
    finally:
        proc2.terminate()
        proc2.wait(timeout=15)

    # Summary
    print_section("VERIFICATION SUMMARY")
    all_ok = True
    for name, ok, detail in results:
        mark = "PASS" if ok else "FAIL"
        print(f"[{mark}] {name}: {detail}")
        if not ok:
            all_ok = False

    # Cleanup temp DBs
    for p in (cold_db, live_db):
        if p.exists():
            try:
                p.unlink()
            except OSError:
                pass

    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
