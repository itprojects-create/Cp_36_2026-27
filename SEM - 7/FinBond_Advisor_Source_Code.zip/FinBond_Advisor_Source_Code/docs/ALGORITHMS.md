# FinBond Advisor — Algorithms (copy into paper)

These algorithms match the implemented code. Use IEEE Algorithm / “Algorithm 1” style. Source files are listed so you can cite them in a viva.

---

**Algorithm 1: Weighted Risk Scoring**  
*Source: `backend/app/recommendation/risk_scoring.py`*

**Input:** Questionnaire responses \( r_q \in \{1,2,3,4,5\} \) for 10 questions \( q \), with weights \( w_q \)  
**Output:** Risk score \( S \in [1,10] \) and category \( C \in \{\text{LOW}, \text{MODERATE}, \text{HIGH}\} \)

```
1.  total_weight ← 0
2.  weighted_sum ← 0
3.  for each question q with weight w_q do
4.      if r_q not in [1, 5] then
5.          raise error
6.      end if
7.      n_q ← 1 + (r_q − 1) × (9 / 4)     // map Likert 1–5 onto 1–10
8.      weighted_sum ← weighted_sum + n_q × w_q
9.      total_weight ← total_weight + w_q
10. end for
11. S ← round(weighted_sum / total_weight, 1)
12. S ← clamp(S, 1.0, 10.0)
13. if S ≤ 3.0 then C ← LOW
14. else if S ≤ 7.0 then C ← MODERATE
15. else C ← HIGH
16. return (S, C)
```

**Weights:** portfolio_drop 1.2, horizon 1.1, income_stability 1.0, debt_load 1.0, capital_preservation 1.0, volatility 1.0, emergency_fund 0.9, preferred_style 0.9, experience 0.8, dependents 0.7.

---

**Algorithm 2: Derived Financial Features**  
*Source: `backend/app/recommendation/derived_features.py`*

**Input:** monthly income \( I \), expenses \( E \), EMI \( D \), savings \( Sv \), existing investments \( Inv \), emergency-fund months \( M \)  
**Output:** feature vector \( F \)

```
1.  if I ≤ 0 then raise error
2.  surplus ← I − E − D
3.  savings_rate ← (surplus / I) × 100
4.  debt_burden_ratio ← (D / I) × 100
5.  emergency_fund_coverage ← M
6.  investable_assets ← Sv + Inv
7.  return F = {savings_rate, debt_burden_ratio, emergency_fund_coverage,
               investable_assets, net_monthly_surplus = surplus}
```

---

**Algorithm 3: Rule-Based Portfolio Allocation (v1 — default engine)**  
*Source: `backend/app/recommendation/allocation_engine.py`*

**Input:** profile, goals, risk category \( C \), derived features \( F \)  
**Output:** allocation vector \( A \) over 6 segments, summing to 100%

```
1.  goal ← primary goal  // lowest priority number, then earliest target_year
2.  H ← max(1, goal.target_year − current_year)
3.  A ← BASE_ALLOCATION[C]     // Table I
4.  A ← ApplyGoalAdjustments(A, goal.type)
5.  A ← ApplyHorizonAdjustments(A, H)
6.  A ← ApplyLiquidityAdjustments(A, F.emergency_fund_coverage, F.debt_burden_ratio)
7.  for each segment s do
8.      A[s] ← max(0, A[s])
9.  end for
10. return Normalize(A)          // Algorithm 4
```

**Table I — Base allocation (%)**

| Segment | LOW | MODERATE | HIGH |
|---|---|---|---|
| G-Sec/Debt | 50 | 30 | 15 |
| Large Cap | 25 | 30 | 30 |
| Mid Cap | 5 | 15 | 20 |
| Small Cap | 0 | 10 | 20 |
| Gold | 10 | 10 | 10 |
| ETF | 10 | 5 | 5 |

**Goal adjustments (ApplyGoalAdjustments):**
- Retirement: Debt +5, Large −3, Mid −2
- House / Car: shift 15 pp from equity (Large, Mid, Small, ETF, proportional) into Debt
- Wealth creation: Debt −10 (floor 0); Large +4, Mid +3, Small +3
- Emergency: shift 20 pp from equity+Gold into Debt

**Horizon adjustments:**
- Short (\( H < 3 \)): Debt +10; Small −5; Mid −5
- Medium (\( 3 \le H \le 7 \)): no change
- Long (\( H > 7 \)): Debt −10 (floor 5); Large +4, Mid +3, Small +3

**Liquidity adjustments:**
- Emergency fund \( < 3 \) months: Debt +10; Large −5; Mid −5
- Emergency fund \( \ge 6 \) months: Large +3; Debt −3 (floor 5)
- Debt burden \( > 40\% \): Debt +5; Small −5

---

**Algorithm 4: Allocation Normalization**  
*Source: `backend/app/recommendation/recommendation_builder.py`*

```
1.  T ← Σ A[s]
2.  if T ≤ 0 then return zeros
3.  for each segment s do
4.      A[s] ← round(A[s] / T × 100, 2)
5.  end for
6.  return A
```

---

**Algorithm 5: Instrument Ranking within a Segment**  
*Source: `backend/app/recommendation/instrument_ranker.py`*

**Input:** instruments in one category, user risk category \( C \)  
**Output:** top-2 instruments with score and reason text

```
1.  cagr_norm[i] ← MinMaxNormalize(cagr_3y[i], higher_is_better = true)
2.  exp_norm[i]  ← MinMaxNormalize(expense_ratio[i], higher_is_better = false)
3.  target_risk ← {LOW: 2, MODERATE: 3, HIGH: 4}[C]
4.  for each instrument i do
5.      risk_match ← max(0, 1 − |risk_level_i − target_risk| × 0.25)
6.      score_i ← 0.5 × cagr_norm[i] + 0.3 × exp_norm[i] + 0.2 × risk_match
7.  end for
8.  sort instruments by score_i descending
9.  return top 2
```

**Min–max (null → 0.5; equal min/max → 1.0):**  
\( \text{norm} = (v - v_{\min}) / (v_{\max} - v_{\min}) \); invert if lower is better.

**Rupee amount per instrument:**  
\( \text{amount} = \text{investable} \times \text{allocation\%} / 100 \), split across the top-2 funds in that segment.

If investable \( \le 0 \), the API uses \( \max(\text{savings}+\text{investments},\; 100000) \).

---

**Algorithm 6: Illustrative Growth Projection (pre-tax)**  
*Source: `frontend/src/charts/GrowthProjection.jsx`*

**Input:** lump sum \( P \), monthly SIP \( SIP \), years \( T \), assumed annual return \( R = 10\% \)  
**Output:** estimated value at each year (not guaranteed; **excludes tax**)

```
1.  r ← R / 100
2.  r_m ← r / 12
3.  for t = 0 to T do
4.      m ← 12 × t
5.      lump ← P × (1 + r)^t
6.      if SIP > 0 and r_m > 0 then
7.          sip ← SIP × [ ((1 + r_m)^m − 1) / r_m ] × (1 + r_m)
8.      else
9.          sip ← SIP × m
10.     end if
11.     FV(t) ← lump + sip
12. end for
13. estimated_gain(t) ← max(0, FV(t) − (P + SIP × 12 × t))
```

Paper sentence: *All projected gains are pre-tax and do not include STCG/LTCG, surcharge, cess, or TDS.*

---

**Algorithm 7: Market Regime Classification (display only)**  
*Source: `backend/app/market/regime_detector.py`*

**Input:** Nifty drawdown \( d \) from 52-week high, India VIX \( v \), crude 30-day change \( c \), Nifty 20-day trend-up flag \( u \)  
**Output:** regime ∈ {BULL, SIDEWAYS, BEAR, CRASH}

```
1.  d ← d if known else 0
2.  v ← v if known else 0
3.  c ← c if known else 0
4.  if d ≥ 20 OR v ≥ 25 then
5.      return CRASH
6.  else if d ≥ 10 OR (v ≥ 18 AND c ≥ 10) then
7.      return BEAR
8.  else if d < 5 AND v < 18 AND u = true then
9.      return BULL
10. else
11.     return SIDEWAYS
12. end if
```

**Drawdown:** \( d = (1 - P_{\text{last}} / P_{52w\text{-high}}) \times 100 \)  
This module **does not** feed v1 or v2 allocation.

---

**Algorithm 8: Crash / Dip Phased Deployment**  
*Source: `backend/app/market/crash_engine.py`*

```
1.  d ← cached Nifty drawdown from 52-week high
2.  if d is missing then return unavailable
3.  if d < 5 then return no_active_correction
4.  if d < 10 then tier ← mild
5.  else if d < 15 then tier ← deep
6.  else tier ← major
7.  cash ← investable_amount from latest recommendation
        (else savings + existing_investments)
8.  if cash ≤ 0 then return insufficient_cash
9.  deploy_pct ← DEPLOYMENT_PCT[tier][risk_category]   // max 50%
10. amount ← cash × deploy_pct / 100
11. split amount using CRASH_SEGMENT_SPLITS[tier][risk]
12. return phased deployment suggestion (not a bottom call)
```

**Deployment % of cash**

| Tier | LOW | MODERATE | HIGH |
|---|---|---|---|
| mild (5–10%) | 10 | 20 | 30 |
| deep (10–15%) | 15 | 30 | 40 |
| major (≥15%) | 20 | 40 | 50 |

---

**Algorithm 9: Rebalancing Drift Check**  
*Source: `backend/app/recommendation/rebalancing_engine.py`*

**Assumption:** “current” = previous stored recommendation; “target” = latest. Not brokerage holdings.

```
1.  load last 2 recommendations for the user
2.  if fewer than 2 then return insufficient_history
3.  current ← segment % from previous recommendation
4.  target  ← segment % from latest recommendation
5.  for each segment s do
6.      drift ← current[s] − target[s]
7.      if |drift| > 5 pp then
8.          flag s
9.          suggest changing future SIP mix (no forced selling)
10.     end if
11. end for
12. if no flags then return within_target_range
13. else return rebalance_suggested
```

---

**Algorithm 10: Government Scheme Eligibility Screening**  
*Source: `backend/app/services/scheme_matcher.py`*

```
1.  annual_income ← monthly_income × 12
2.  for each active scheme do
3.      if notes say “closed for new subscriptions” then
4.          class ← NOT ELIGIBLE
5.      else if age/income/occupation clearly fails a hard rule then
6.          class ← NOT ELIGIBLE
7.      else if gender/category required OR eligibility_notes present
            OR occupation cannot be determined then
8.          class ← MAY BE ELIGIBLE
9.      else
10.         class ← ELIGIBLE
11.     end if
12.     attach reason + official portal URL
13.     attach: “Verify on the official government portal before applying.”
14. end for
```

---

**Algorithm 11: Rule-Based Help Assistant (not an LLM)**  
*Source: `backend/app/services/faq_assistant.py`*

```
1.  q ← lowercase(question); strip punctuation
2.  if q empty then return fallback
3.  for each FAQ entry in order {personalized, navigation, safety, terms} do
4.      if any pattern of the entry is a substring of q then
5.          if entry needs auth/recommendation and user has none then
6.              return “complete onboarding first”
7.          end if
8.          return template filled with stored allocation / explanation
9.      end if
10. end for
11. return fallback with examples the bank can actually answer
```

---

**Algorithm 12: Synthetic Dataset + XGBoost Training (v2, comparison only)**  
*Source: `backend/ml/generate_dataset.py`, `backend/ml/train_model.py`*

```
1.  for i = 1 to N do                          // default ~7500 profiles
2.      sample realistic profile, goals, Likert answers
3.      compute features using Algorithm 2 (same live path)
4.      Y ← Algorithm 3 (rule engine labels, 6 segment %)
5.      for each segment s do
6.          Y[s] ← Y[s] + Gaussian(0, σ)       // default σ = 4 pp
7.      end for
8.      clamp Y[s] ← max(0, Y[s])              // asymmetric at 0% labels
9.      Y ← Normalize(Y)                       // Algorithm 4
10.     store (features, Y)
11. end for
12. train multi-output XGBoost regressor: features → 6 percentages
13. v2 is comparison/demo only; v1 remains the served default
```

**Known training artifact:** noise on a 0% label cannot go negative after clamp, so conservative Small/Mid Cap labels are biased **upward**.

---

**Algorithm 13: End-to-end recommendation request**

```
1.  Client sends JWT + POST /api/v1/recommend
2.  Load profile, goals, latest risk assessment, instrument registry
3.  investable ← savings + existing_investments
4.  if investable ≤ 0 then investable ← 100000
5.  A ← Algorithm 3
6.  for each segment with A[s] > 0 do
7.      pick top-2 funds via Algorithm 5
8.      amount_s ← investable × A[s] / 100
9.  end for
10. write explanation from age, goal, horizon, S, C, F
11. persist Recommendation snapshot
12. return portfolio JSON to Dashboard / PDF report
```

---

## Data flow (one paragraph for the paper)

User → React (JWT) → FastAPI. Onboarding stores Profile, Goals, RiskAssessment. `POST /api/v1/recommend` runs Algorithms 1–5 and saves a Recommendation. Dashboard charts and PDF use that snapshot. Market Pulse fetches yfinance/AMFI into cache (Algorithms 7–8 read cache only). Compare calls v1 and v2 on the same profile. Help Assistant matches keywords (Algorithm 11). Scheme matcher screens curated schemes (Algorithm 10). Allocation engines never consume live market prices.

---

## Suggested in-text citations

- Algorithm 1–5, 13 → Methodology (rule engine)  
- Algorithm 6 → Growth projection / PDF report  
- Algorithm 7–9 → Market and insights  
- Algorithm 10–11 → Schemes and explainability  
- Algorithm 12 → ML comparison and limitations  
