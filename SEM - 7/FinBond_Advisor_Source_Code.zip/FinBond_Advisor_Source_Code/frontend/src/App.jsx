import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import HelpAssistant from './components/HelpAssistant';
import Login from './pages/Login';
import Register from './pages/Register';
import Disclaimer from './pages/Disclaimer';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Compare from './pages/Compare';
import MarketPulse from './pages/MarketPulse';
import Insights from './pages/Insights';
import GovernmentSchemes from './pages/GovernmentSchemes';
import AdminUsers from './pages/admin/AdminUsers';
import AdminInstruments from './pages/admin/AdminInstruments';
import AdminModelMetrics from './pages/admin/AdminModelMetrics';
import AdminMarket from './pages/admin/AdminMarket';
import AdminSchemes from './pages/admin/AdminSchemes';

function HomeRedirect() {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex min-h-screen items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'admin') return <Navigate to="/admin/users" replace />;
  if (!user.disclaimer_accepted_at) return <Navigate to="/disclaimer" replace />;
  if (!user.has_profile || !user.has_goals || !user.has_risk_assessment) {
    return <Navigate to="/onboarding" replace />;
  }
  return <Navigate to="/dashboard" replace />;
}

function AuthenticatedHelpAssistant() {
  const { user, loading } = useAuth();
  const { pathname } = useLocation();

  if (loading || !user) return null;
  if (pathname === '/login' || pathname === '/register' || pathname === '/admin/login') {
    return null;
  }

  return <HelpAssistant />;
}

export default function App() {
  return (
    <AuthProvider>
      <AuthenticatedHelpAssistant />
      <Routes>
        <Route path="/" element={<HomeRedirect />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/disclaimer"
          element={
            <ProtectedRoute>
              <Disclaimer />
            </ProtectedRoute>
          }
        />
        <Route
          path="/onboarding"
          element={
            <ProtectedRoute>
              <Onboarding />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/compare"
          element={
            <ProtectedRoute>
              <Compare />
            </ProtectedRoute>
          }
        />
        <Route
          path="/market-pulse"
          element={
            <ProtectedRoute>
              <MarketPulse />
            </ProtectedRoute>
          }
        />
        <Route
          path="/insights"
          element={
            <ProtectedRoute>
              <Insights />
            </ProtectedRoute>
          }
        />
        <Route
          path="/government-schemes"
          element={
            <ProtectedRoute>
              <GovernmentSchemes />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/users"
          element={
            <ProtectedRoute requireAdmin>
              <AdminUsers />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/instruments"
          element={
            <ProtectedRoute requireAdmin>
              <AdminInstruments />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/model"
          element={
            <ProtectedRoute requireAdmin>
              <AdminModelMetrics />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/market"
          element={
            <ProtectedRoute requireAdmin>
              <AdminMarket />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/schemes"
          element={
            <ProtectedRoute requireAdmin>
              <AdminSchemes />
            </ProtectedRoute>
          }
        />
        <Route path="/admin/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  );
}
