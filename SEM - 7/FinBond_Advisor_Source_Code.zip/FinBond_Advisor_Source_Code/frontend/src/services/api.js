import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api/v1';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('finbond_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('finbond_token');
      if (!window.location.pathname.startsWith('/admin')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default api;

export const authApi = {
  register: (email, password) => api.post('/auth/register', { email, password }),
  login: (email, password) => api.post('/auth/login', { email, password }),
  me: () => api.get('/auth/me'),
};

export const userApi = {
  acceptDisclaimer: () => api.post('/user/disclaimer', { accepted: true }),
  getProfile: () => api.get('/user/profile'),
  saveProfile: (data) => api.post('/user/profile', data),
  getGoals: () => api.get('/user/goals'),
  saveGoals: (goals) => api.post('/user/goals', { goals }),
  getQuestionnaire: () => api.get('/user/risk-questionnaire'),
  submitRiskAssessment: (responses) => api.post('/user/risk-assessment', { responses }),
};

export const recommendApi = {
  generate: (investableAmount) =>
    api.post('/recommend', investableAmount ? { investable_amount: investableAmount } : {}),
  getLatest: () => api.get('/recommend/latest'),
  getById: (id) => api.get(`/recommend/${id}`),
};

export const recommendV2Api = {
  generate: (investableAmount) =>
    api.post('/recommend', investableAmount ? { investable_amount: investableAmount } : {}, {
      baseURL: '/api/v2',
    }),
};

export const adminApi = {
  getUsers: () => api.get('/admin/users'),
  toggleUser: (id) => api.patch(`/admin/users/${id}/toggle`),
  getInstruments: () => api.get('/admin/instruments'),
  createInstrument: (data) => api.post('/admin/instruments', data),
  updateInstrument: (id, data) => api.put(`/admin/instruments/${id}`, data),
  deleteInstrument: (id) => api.delete(`/admin/instruments/${id}`),
  getSchemes: () => api.get('/admin/schemes'),
  createScheme: (data) => api.post('/admin/schemes', data),
  updateScheme: (id, data) => api.put(`/admin/schemes/${id}`, data),
  deleteScheme: (id) => api.delete(`/admin/schemes/${id}`),
  getModelMetrics: () => api.get('/admin/model/metrics'),
  getMarketStatus: () => api.get('/admin/market/status'),
  getSystemHealth: () => api.get('/admin/system-health'),
  updateGsec: (yieldPct) => api.put('/admin/gsec', { yield_pct: yieldPct }),
  getGsec: () => api.get('/gsec', { baseURL: '/api' }),
};

export const marketApi = {
  getPulse: () => api.get('/market-pulse', { baseURL: '/api' }),
  getRegime: () => api.get('/market-regime', { baseURL: '/api' }),
  getGsec: () => api.get('/gsec', { baseURL: '/api' }),
};

export const insightsApi = {
  getCrashSignal: () => api.get('/crash-signal', { baseURL: '/api' }),
  getRebalanceCheck: () => api.post('/rebalance-check', {}, { baseURL: '/api' }),
};

export const schemesApi = {
  list: () => api.get('/schemes', { baseURL: '/api' }),
  checkEligibility: () => api.post('/schemes/check-eligibility', {}, { baseURL: '/api' }),
};

export const assistantApi = {
  ask: (question) => api.post('/assistant/ask', { question }, { baseURL: '/api' }),
};
