export default function InstrumentCard({ instrument, segment }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-slate-900">{instrument.name}</p>
          <p className="text-xs text-slate-500">{segment}</p>
        </div>
        <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700">
          {instrument.allocation_pct}%
        </span>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
        <div>
          <p className="text-slate-500">Allocation</p>
          <p className="font-medium">₹{(instrument.amount ?? 0).toLocaleString('en-IN')}</p>
        </div>
        <div>
          <p className="text-slate-500">3Y CAGR</p>
          <p className="font-medium">{instrument.cagr_3y != null ? `${instrument.cagr_3y}%` : 'N/A'}</p>
        </div>
        <div>
          <p className="text-slate-500">Expense Ratio</p>
          <p className="font-medium">{instrument.expense_ratio != null ? `${instrument.expense_ratio}%` : 'N/A'}</p>
        </div>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-slate-600">{instrument.reason}</p>
      {instrument.source && (
        <p className="mt-2 text-xs text-slate-400">
          Source: {instrument.source}
          {instrument.last_updated && ` · Last updated: ${new Date(instrument.last_updated).toLocaleDateString()}`}
        </p>
      )}
    </div>
  );
}
