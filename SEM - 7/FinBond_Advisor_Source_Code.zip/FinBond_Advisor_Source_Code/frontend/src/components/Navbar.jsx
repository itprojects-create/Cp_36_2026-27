import { Link, useNavigate } from 'react-router-dom';
import { LogOut, Shield, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link to={user?.role === 'admin' ? '/admin/users' : '/dashboard'} className="flex items-center gap-2">
          <div className="rounded-lg bg-emerald-600 p-2 text-white">
            <TrendingUp size={20} />
          </div>
          <div>
            <p className="font-bold text-slate-900">FinBond Advisor</p>
            <p className="text-xs text-slate-500">Phase 1 — Decision Support</p>
          </div>
        </Link>
        <div className="flex items-center gap-4">
          {user?.role === 'admin' ? (
            <>
              <Link to="/admin/users" className="text-sm text-slate-600 hover:text-emerald-700">
                Users
              </Link>
              <Link to="/admin/instruments" className="text-sm text-slate-600 hover:text-emerald-700">
                Instruments
              </Link>
              <Link to="/admin/model" className="text-sm text-slate-600 hover:text-emerald-700">
                Model Metrics
              </Link>
              <Link to="/admin/market" className="text-sm text-slate-600 hover:text-emerald-700">
                Market Data
              </Link>
              <Link to="/admin/schemes" className="text-sm text-slate-600 hover:text-emerald-700">
                Schemes
              </Link>
            </>
          ) : (
            <>
              <Link to="/dashboard" className="text-sm text-slate-600 hover:text-emerald-700">
                Dashboard
              </Link>
              <Link to="/compare" className="text-sm text-slate-600 hover:text-emerald-700">
                Compare
              </Link>
              <Link to="/market-pulse" className="text-sm text-slate-600 hover:text-emerald-700">
                Market Pulse
              </Link>
              <Link to="/insights" className="text-sm text-slate-600 hover:text-emerald-700">
                Insights
              </Link>
              <Link to="/government-schemes" className="text-sm text-slate-600 hover:text-emerald-700">
                Schemes
              </Link>
            </>
          )}
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Shield size={16} />
            {user?.email}
          </div>
          <button
            onClick={handleLogout}
            className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-sm hover:bg-slate-50"
          >
            <LogOut size={14} />
            Logout
          </button>
        </div>
      </div>
    </header>
  );
}
