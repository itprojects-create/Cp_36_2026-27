import { useEffect, useState } from 'react';
import { ExternalLink, Landmark } from 'lucide-react';
import Layout from '../components/Layout';
import DisclaimerBanner from '../components/DisclaimerBanner';
import { schemesApi } from '../services/api';

const BADGE = {
  ELIGIBLE: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'MAY BE ELIGIBLE': 'bg-amber-100 text-amber-800 border-amber-200',
  'NOT ELIGIBLE': 'bg-slate-100 text-slate-600 border-slate-200',
};

export default function GovernmentSchemes() {
  const [schemes, setSchemes] = useState([]);
  const [eligibility, setEligibility] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const [schemesRes, eligRes] = await Promise.all([
          schemesApi.list(),
          schemesApi.checkEligibility().catch((err) => {
            if (err.response?.status === 400) return { data: { results: [] } };
            throw err;
          }),
        ]);
        setSchemes(schemesRes.data);
        const map = {};
        for (const item of eligRes.data.results || []) {
          map[item.scheme_id] = item;
        }
        setEligibility(map);
      } catch (err) {
        setError(err.response?.data?.detail || 'Failed to load schemes');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Government Schemes</h1>
        <p className="text-sm text-slate-500">
          Manually curated registry — eligibility screening based on your profile
        </p>
      </div>

      <DisclaimerBanner
        compact
        text="Scheme data is manually curated and periodically updated — not live-fetched from government portals. Eligibility classifications are a screening aid only. Verify eligibility on the official government portal before applying."
      />

      {error && <p className="mt-4 text-red-600">{error}</p>}
      {loading && <p className="mt-4 text-slate-500">Loading schemes...</p>}

      <div className="mt-6 space-y-4">
        {schemes.map((scheme) => {
          const match = eligibility[scheme.id];
          const classification = match?.classification || 'MAY BE ELIGIBLE';
          const isClosed = scheme.eligibility_notes?.toLowerCase().includes('closed for new');
          return (
            <article
              key={scheme.id}
              className={`rounded-xl border bg-white p-5 shadow-sm ${isClosed ? 'border-red-200' : 'border-slate-200'}`}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="rounded-lg bg-emerald-50 p-2 text-emerald-700">
                    <Landmark size={20} />
                  </div>
                  <div>
                    <h2 className="font-semibold text-slate-900">{scheme.name}</h2>
                    <p className="text-xs text-slate-500">{scheme.department}</p>
                  </div>
                </div>
                {match && (
                  <span
                    className={`rounded-full border px-3 py-1 text-xs font-medium ${BADGE[classification] || BADGE['MAY BE ELIGIBLE']}`}
                  >
                    {classification}
                  </span>
                )}
              </div>

              {isClosed && (
                <p className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-800">
                  Closed for new subscriptions since March 31, 2023
                </p>
              )}

              <p className="mt-3 text-sm text-slate-700">{scheme.description}</p>
              <p className="mt-2 text-sm text-slate-600">
                <span className="font-medium">Benefits:</span> {scheme.benefits}
              </p>

              <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-500">
                {scheme.interest_or_return && (
                  <span>Return: {scheme.interest_or_return}</span>
                )}
                {scheme.lock_in_period && <span>Lock-in: {scheme.lock_in_period}</span>}
              </div>

              {match && (
                <p className="mt-3 text-sm text-slate-600">{match.reason}</p>
              )}

              {scheme.eligibility_notes && (
                <p className="mt-2 text-xs text-slate-500">{scheme.eligibility_notes}</p>
              )}

              <a
                href={scheme.official_portal_url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-emerald-700 hover:text-emerald-900"
              >
                Official portal <ExternalLink size={14} />
              </a>
            </article>
          );
        })}
      </div>
    </Layout>
  );
}
