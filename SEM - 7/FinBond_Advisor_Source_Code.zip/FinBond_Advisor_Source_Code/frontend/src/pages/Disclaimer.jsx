import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DisclaimerBanner, { DISCLAIMER_TEXT } from '../components/DisclaimerBanner';
import { userApi } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Disclaimer() {
  const navigate = useNavigate();
  const { refreshUser } = useAuth();
  const [checked, setChecked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAccept = async () => {
    if (!checked) return;
    setLoading(true);
    setError('');
    try {
      await userApi.acceptDisclaimer();
      await refreshUser();
      navigate('/onboarding');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to accept disclaimer');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 py-8">
      <div className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <h1 className="text-2xl font-bold text-slate-900">Before we begin</h1>
        <p className="mt-2 text-slate-600">
          Please read and acknowledge the following disclaimer to continue with onboarding.
        </p>
        <div className="mt-6">
          <DisclaimerBanner />
        </div>
        <div className="mt-6 rounded-lg bg-slate-50 p-4 text-sm leading-relaxed text-slate-700">
          {DISCLAIMER_TEXT}
        </div>
        <label className="mt-6 flex cursor-pointer items-start gap-3">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            className="mt-1 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
          />
          <span className="text-sm text-slate-700">
            I understand and agree to the disclaimer above. I acknowledge that FinBond Advisor provides
            educational decision-support only and is not a registered investment adviser.
          </span>
        </label>
        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
        <button
          onClick={handleAccept}
          disabled={!checked || loading}
          className="mt-6 w-full rounded-lg bg-emerald-600 py-3 font-medium text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {loading ? 'Processing...' : 'I Understand and Agree'}
        </button>
      </div>
    </div>
  );
}
