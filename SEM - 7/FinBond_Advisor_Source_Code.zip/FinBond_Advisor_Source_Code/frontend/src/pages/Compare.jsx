import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, RefreshCw } from 'lucide-react';
import Layout from '../components/Layout';
import DisclaimerBanner from '../components/DisclaimerBanner';
import AllocationDoughnut from '../charts/AllocationDoughnut';
import { recommendApi, recommendV2Api } from '../services/api';

const SEGMENTS = ['G-Sec/Debt', 'Large Cap', 'Mid Cap', 'Small Cap', 'Gold', 'ETF'];

function segmentMap(portfolio) {
  return Object.fromEntries((portfolio || []).map((s) => [s.segment, s.allocation_pct]));
}

function buildDiffSummary(v1Portfolio, v2Portfolio) {
  const v1 = segmentMap(v1Portfolio);
  const v2 = segmentMap(v2Portfolio);
  return SEGMENTS.map((segment) => {
    const rulePct = v1[segment] ?? 0;
    const mlPct = v2[segment] ?? 0;
    const diff = Math.round((mlPct - rulePct) * 10) / 10;
    return { segment, rulePct, mlPct, diff };
  }).filter((row) => row.rulePct > 0 || row.mlPct > 0);
}

function formatDiff(diff) {
  if (diff > 0) return `(+${diff}pp)`;
  if (diff < 0) return `(${diff}pp)`;
  return '(0pp)';
}

function diffColor(diff) {
  return Math.abs(diff) > 5 ? 'text-amber-700' : 'text-slate-700';
}

function EngineColumn({ title, badgeClass, recommendation, unavailableMessage }) {
  if (unavailableMessage) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
        <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${badgeClass}`}>{title}</span>
        <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {unavailableMessage}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${badgeClass}`}>{title}</span>

      <div className="mt-4">
        <h3 className="mb-3 text-sm font-semibold text-slate-700">Portfolio Allocation</h3>
        <AllocationDoughnut portfolio={recommendation.portfolio} />
      </div>

      <div className="mt-4">
        <h3 className="mb-2 text-sm font-semibold text-slate-700">Segment Breakdown</h3>
        <ul className="space-y-1 text-sm">
          {(recommendation.portfolio || []).map((seg) => (
            <li key={seg.segment} className="flex justify-between border-b border-slate-100 py-1.5 last:border-0">
              <span className="text-slate-600">{seg.segment}</span>
              <span className="font-medium text-slate-900">{seg.allocation_pct}%</span>
            </li>
          ))}
        </ul>
      </div>

      {recommendation.explanation && (
        <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
          <h3 className="text-sm font-semibold text-emerald-900">Why this was recommended</h3>
          <p className="mt-2 text-sm leading-relaxed text-emerald-800">{recommendation.explanation}</p>
        </div>
      )}
    </div>
  );
}

export default function Compare() {
  const [ruleRec, setRuleRec] = useState(null);
  const [mlRec, setMlRec] = useState(null);
  const [mlUnavailable, setMlUnavailable] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const loadComparison = async () => {
    setError('');
    setMlUnavailable(null);

    try {
      const v1Res = await recommendApi.generate();
      setRuleRec(v1Res.data);

      try {
        const v2Res = await recommendV2Api.generate();
        setMlRec(v2Res.data);
      } catch (err) {
        if (err.response?.status === 503) {
          setMlRec(null);
          setMlUnavailable(
            'ML model not yet available — train it via: cd finbond-advisor/backend && python ml/train_model.py'
          );
        } else {
          setMlRec(null);
          setMlUnavailable(err.response?.data?.detail || 'ML recommendation unavailable');
        }
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load comparison');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadComparison();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    loadComparison();
  };

  if (loading) {
    return (
      <Layout>
        <p className="text-slate-500">Loading engine comparison...</p>
      </Layout>
    );
  }

  if (error && !ruleRec) {
    return (
      <Layout>
        <p className="text-red-600">{error}</p>
      </Layout>
    );
  }

  const diffSummary = mlRec ? buildDiffSummary(ruleRec?.portfolio, mlRec?.portfolio) : [];

  return (
    <Layout>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link to="/dashboard" className="mb-2 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-emerald-700">
            <ArrowLeft size={14} />
            Back to Dashboard
          </Link>
          <h1 className="text-2xl font-bold text-slate-900">Compare Rule-Based vs ML</h1>
          <p className="text-sm text-slate-500">Same profile, two engines — for demo and report screenshots</p>
        </div>
        <button
          onClick={handleRefresh}
          disabled={refreshing}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50 disabled:opacity-50"
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          Refresh Comparison
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <EngineColumn
          title="Rule-Based Engine"
          badgeClass="bg-slate-100 text-slate-800"
          recommendation={ruleRec}
        />
        <EngineColumn
          title="ML Engine (XGBoost)"
          badgeClass="bg-emerald-100 text-emerald-800"
          recommendation={mlRec}
          unavailableMessage={mlUnavailable}
        />
      </div>

      {diffSummary.length > 0 && (
        <div className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold text-slate-900">Segment Difference Summary</h2>
          <p className="mb-4 text-sm text-slate-500">
            Percentage-point difference (ML minus Rule-Based) per segment
          </p>
          <ul className="space-y-2">
            {diffSummary.map(({ segment, rulePct, mlPct, diff }) => (
              <li key={segment} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-slate-50 px-4 py-2.5 text-sm">
                <span className="font-medium text-slate-800">{segment}</span>
                <span className={diffColor(diff)}>
                  Rule {rulePct}% → ML {mlPct}% {formatDiff(diff)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-6">
        <DisclaimerBanner compact />
      </div>
    </Layout>
  );
}
