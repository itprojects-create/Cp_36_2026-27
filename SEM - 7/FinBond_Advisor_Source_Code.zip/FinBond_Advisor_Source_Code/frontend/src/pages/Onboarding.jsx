import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { userApi, recommendApi } from '../services/api';
import ProfileStep from './onboarding/ProfileStep';
import GoalsStep from './onboarding/GoalsStep';
import RiskQuestionnaire from './onboarding/RiskQuestionnaire';

const STEPS = ['Profile', 'Goals', 'Risk Assessment'];

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState(null);
  const [goals, setGoals] = useState([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleProfile = async (data) => {
    setError('');
    setSubmitting(true);
    try {
      await userApi.saveProfile(data);
      setProfile(data);
      setStep(1);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save profile');
    } finally {
      setSubmitting(false);
    }
  };

  const handleGoals = async (data) => {
    setError('');
    setSubmitting(true);
    try {
      await userApi.saveGoals(data);
      setGoals(data);
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save goals');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRisk = async (responses) => {
    setError('');
    setSubmitting(true);
    try {
      await userApi.submitRiskAssessment(responses);
      await recommendApi.generate();
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to complete onboarding');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Onboarding</h1>
        <div className="mt-4 flex gap-2">
          {STEPS.map((label, idx) => (
            <div
              key={label}
              className={`rounded-full px-4 py-1 text-sm font-medium ${
                idx === step
                  ? 'bg-emerald-600 text-white'
                  : idx < step
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-slate-100 text-slate-500'
              }`}
            >
              {idx + 1}. {label}
            </div>
          ))}
        </div>
      </div>
      {error && <p className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      {submitting && <p className="mb-4 text-sm text-slate-500">Saving...</p>}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        {step === 0 && <ProfileStep onNext={handleProfile} initialData={profile || {}} />}
        {step === 1 && (
          <GoalsStep onNext={handleGoals} onBack={() => setStep(0)} initialGoals={goals} />
        )}
        {step === 2 && (
          <RiskQuestionnaire onSubmit={handleRisk} onBack={() => setStep(1)} />
        )}
      </div>
    </Layout>
  );
}
