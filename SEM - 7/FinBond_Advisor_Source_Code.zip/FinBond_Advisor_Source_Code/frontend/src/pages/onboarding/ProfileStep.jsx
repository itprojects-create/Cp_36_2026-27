import { useState } from 'react';

const EXPERIENCE_OPTIONS = [
  { value: 'none', label: 'No experience' },
  { value: 'beginner', label: 'Beginner (< 1 year)' },
  { value: 'intermediate', label: 'Intermediate (1–5 years)' },
  { value: 'advanced', label: 'Advanced (5+ years)' },
];

export default function ProfileStep({ onNext, initialData = {} }) {
  const [form, setForm] = useState({
    age: initialData.age || 30,
    occupation: initialData.occupation || '',
    dependents: initialData.dependents ?? 0,
    monthly_income: initialData.monthly_income || '',
    monthly_expenses: initialData.monthly_expenses || '',
    savings: initialData.savings || '',
    existing_investments: initialData.existing_investments || '',
    emergency_fund_months: initialData.emergency_fund_months ?? 3,
    emi: initialData.emi || 0,
    monthly_sip: initialData.monthly_sip || 0,
    investment_experience: initialData.investment_experience || 'beginner',
  });

  const update = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onNext({
      ...form,
      age: Number(form.age),
      dependents: Number(form.dependents),
      monthly_income: Number(form.monthly_income),
      monthly_expenses: Number(form.monthly_expenses),
      savings: Number(form.savings),
      existing_investments: Number(form.existing_investments),
      emergency_fund_months: Number(form.emergency_fund_months),
      emi: Number(form.emi),
      monthly_sip: Number(form.monthly_sip),
    });
  };

  const fieldClass =
    'w-full rounded-lg border border-slate-300 px-3 py-2 focus:border-emerald-500 focus:outline-none';

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-semibold">Financial Profile</h2>
      <p className="text-sm text-slate-500">Tell us about your current financial situation.</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm font-medium">Age</label>
          <input type="number" required min={18} max={100} value={form.age} onChange={(e) => update('age', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Occupation</label>
          <input required value={form.occupation} onChange={(e) => update('occupation', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Dependents</label>
          <input type="number" min={0} value={form.dependents} onChange={(e) => update('dependents', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Investment Experience</label>
          <select value={form.investment_experience} onChange={(e) => update('investment_experience', e.target.value)} className={fieldClass}>
            {EXPERIENCE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Monthly Income (₹)</label>
          <input type="number" required min={1} value={form.monthly_income} onChange={(e) => update('monthly_income', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Monthly Expenses (₹)</label>
          <input type="number" required min={0} value={form.monthly_expenses} onChange={(e) => update('monthly_expenses', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Current Savings (₹)</label>
          <input type="number" required min={0} value={form.savings} onChange={(e) => update('savings', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Existing Investments (₹)</label>
          <input type="number" required min={0} value={form.existing_investments} onChange={(e) => update('existing_investments', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Emergency Fund (months of expenses)</label>
          <input type="number" required min={0} max={24} step={0.5} value={form.emergency_fund_months} onChange={(e) => update('emergency_fund_months', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Monthly EMI (₹)</label>
          <input type="number" min={0} value={form.emi} onChange={(e) => update('emi', e.target.value)} className={fieldClass} />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium">Monthly SIP (₹)</label>
          <input type="number" min={0} value={form.monthly_sip} onChange={(e) => update('monthly_sip', e.target.value)} className={fieldClass} />
        </div>
      </div>
      <button type="submit" className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700">
        Continue to Goals
      </button>
    </form>
  );
}
