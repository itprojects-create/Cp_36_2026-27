import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';

const GOAL_TYPES = [
  { value: 'retirement', label: 'Retirement' },
  { value: 'house', label: 'House Purchase' },
  { value: 'car', label: 'Car Purchase' },
  { value: 'education', label: 'Education' },
  { value: 'wealth_creation', label: 'Wealth Creation' },
  { value: 'emergency', label: 'Emergency Fund' },
];

const emptyGoal = () => ({
  goal_type: 'retirement',
  target_amount: '',
  target_year: new Date().getFullYear() + 10,
  priority: 1,
  current_saved: 0,
});

export default function GoalsStep({ onNext, onBack, initialGoals = [] }) {
  const [goals, setGoals] = useState(initialGoals.length ? initialGoals : [emptyGoal()]);

  const updateGoal = (index, key, value) => {
    setGoals((prev) => prev.map((g, i) => (i === index ? { ...g, [key]: value } : g)));
  };

  const addGoal = () => setGoals((prev) => [...prev, emptyGoal()]);
  const removeGoal = (index) => setGoals((prev) => prev.filter((_, i) => i !== index));

  const handleSubmit = (e) => {
    e.preventDefault();
    onNext(
      goals.map((g) => ({
        ...g,
        target_amount: Number(g.target_amount),
        target_year: Number(g.target_year),
        priority: Number(g.priority),
        current_saved: Number(g.current_saved),
      }))
    );
  };

  const fieldClass =
    'w-full rounded-lg border border-slate-300 px-3 py-2 focus:border-emerald-500 focus:outline-none';

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-xl font-semibold">Financial Goals</h2>
      <p className="text-sm text-slate-500">Define at least one goal to guide your allocation.</p>
      {goals.map((goal, index) => (
        <div key={index} className="rounded-xl border border-slate-200 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-medium">Goal {index + 1}</h3>
            {goals.length > 1 && (
              <button type="button" onClick={() => removeGoal(index)} className="text-red-500 hover:text-red-700">
                <Trash2 size={16} />
              </button>
            )}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium">Goal Type</label>
              <select value={goal.goal_type} onChange={(e) => updateGoal(index, 'goal_type', e.target.value)} className={fieldClass}>
                {GOAL_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Target Amount (₹)</label>
              <input type="number" required min={1} value={goal.target_amount} onChange={(e) => updateGoal(index, 'target_amount', e.target.value)} className={fieldClass} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Target Year</label>
              <input type="number" required min={2024} max={2070} value={goal.target_year} onChange={(e) => updateGoal(index, 'target_year', e.target.value)} className={fieldClass} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Priority (1 = highest)</label>
              <input type="number" min={1} max={5} value={goal.priority} onChange={(e) => updateGoal(index, 'priority', e.target.value)} className={fieldClass} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Already Saved (₹)</label>
              <input type="number" min={0} value={goal.current_saved} onChange={(e) => updateGoal(index, 'current_saved', e.target.value)} className={fieldClass} />
            </div>
          </div>
        </div>
      ))}
      <button type="button" onClick={addGoal} className="inline-flex items-center gap-1 text-sm text-emerald-700 hover:underline">
        <Plus size={16} /> Add another goal
      </button>
      <div className="flex gap-3">
        <button type="button" onClick={onBack} className="rounded-lg border border-slate-300 px-6 py-2.5 hover:bg-slate-50">
          Back
        </button>
        <button type="submit" className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700">
          Continue to Risk Assessment
        </button>
      </div>
    </form>
  );
}
