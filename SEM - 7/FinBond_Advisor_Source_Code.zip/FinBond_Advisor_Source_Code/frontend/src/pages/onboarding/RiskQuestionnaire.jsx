import { useEffect, useState } from 'react';
import { userApi } from '../../services/api';

export default function RiskQuestionnaire({ onSubmit, onBack }) {
  const [questions, setQuestions] = useState([]);
  const [responses, setResponses] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    userApi
      .getQuestionnaire()
      .then(({ data }) => setQuestions(data.questions))
      .catch(() => setError('Failed to load questionnaire'))
      .finally(() => setLoading(false));
  }, []);

  const allAnswered = questions.length > 0 && questions.every((q) => responses[q.id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(responses);
  };

  if (loading) return <p className="text-slate-500">Loading questionnaire...</p>;
  if (error) return <p className="text-red-600">{error}</p>;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Risk Assessment</h2>
        <p className="text-sm text-slate-500">Answer honestly — this shapes your portfolio allocation.</p>
      </div>
      {questions.map((q, idx) => (
        <div key={q.id} className="rounded-xl border border-slate-200 p-4">
          <p className="mb-3 font-medium">
            {idx + 1}. {q.text}
          </p>
          <div className="space-y-2">
            {q.options.map((opt) => (
              <label
                key={opt.value}
                className={`flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition ${
                  responses[q.id] === opt.value
                    ? 'border-emerald-500 bg-emerald-50'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name={q.id}
                  value={opt.value}
                  checked={responses[q.id] === opt.value}
                  onChange={() => setResponses((prev) => ({ ...prev, [q.id]: opt.value }))}
                  className="text-emerald-600"
                />
                <span className="text-sm">{opt.label}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
      <div className="flex gap-3">
        <button type="button" onClick={onBack} className="rounded-lg border border-slate-300 px-6 py-2.5 hover:bg-slate-50">
          Back
        </button>
        <button
          type="submit"
          disabled={!allAnswered}
          className="rounded-lg bg-emerald-600 px-6 py-2.5 font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
        >
          Complete & Generate Recommendation
        </button>
      </div>
    </form>
  );
}
