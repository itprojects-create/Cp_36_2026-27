import { useEffect, useState } from 'react';
import { AlertTriangle, Scale, TrendingDown } from 'lucide-react';
import Layout from '../components/Layout';
import DisclaimerBanner from '../components/DisclaimerBanner';
import { insightsApi } from '../services/api';

function CrashSection({ data, loading }) {
  if (loading) return <p className="text-slate-500">Loading crash signal...</p>;
  if (!data) return null;

  const active = data.status === 'active_correction';

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-2">
        <TrendingDown className="text-amber-600" size={20} />
        <h2 className="text-lg font-semibold">Crash / Dip — Phased Deployment</h2>
      </div>

      {active ? (
        <div className="space-y-4">
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
            <p className="font-medium text-amber-900">
              {data.correction_tier?.toUpperCase()} correction — Nifty {data.drawdown_pct?.toFixed(1)}% below 52-week high
            </p>
            <p className="mt-2 text-sm text-amber-800">{data.explanation}</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Stat label="Risk profile" value={data.risk_category} />
            <Stat label="Suggested deployment" value={`${data.deployment_pct_of_cash}% of cash`} />
            <Stat label="Amount" value={`₹${Number(data.suggested_deployment_amount || 0).toLocaleString('en-IN')}`} />
          </div>
          {data.segment_split?.length > 0 && (
            <div>
              <h3 className="mb-2 font-medium">Suggested segment split</h3>
              <div className="grid gap-3 sm:grid-cols-2">
                {data.segment_split.map((seg) => (
                  <div key={seg.segment} className="rounded-lg border border-slate-100 p-3 text-sm">
                    <p className="font-medium">{seg.segment}</p>
                    <p className="text-slate-600">{seg.allocation_pct}% · ₹{seg.amount?.toLocaleString('en-IN')}</p>
                    {seg.instruments?.map((inst) => (
                      <p key={inst.name} className="mt-1 text-xs text-slate-500">{inst.name}</p>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-lg border border-slate-100 bg-slate-50 p-4 text-sm text-slate-700">
          <p className="font-medium capitalize">{data.status.replace(/_/g, ' ')}</p>
          <p className="mt-2">{data.explanation}</p>
          {data.drawdown_pct != null && (
            <p className="mt-1 text-xs text-slate-500">Current Nifty drawdown: {data.drawdown_pct.toFixed(1)}%</p>
          )}
        </div>
      )}
      <p className="mt-4 text-xs text-slate-500">{data.disclaimer}</p>
    </section>
  );
}

function RebalanceSection({ data, loading }) {
  if (loading) return <p className="text-slate-500">Checking rebalancing...</p>;
  if (!data) return null;

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-2">
        <Scale className="text-emerald-600" size={20} />
        <h2 className="text-lg font-semibold">Rebalancing Check</h2>
      </div>

      <p className="mb-3 text-xs text-slate-500">{data.assumption_note}</p>
      <p className="mb-4 text-sm text-slate-700">{data.explanation}</p>

      {data.status === 'insufficient_history' ? (
        <div className="rounded-lg border border-slate-100 bg-slate-50 p-4 text-sm">
          Generate at least two recommendations to enable drift analysis.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-slate-100">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-50 text-left text-xs text-slate-500">
              <tr>
                <th className="px-4 py-2">Segment</th>
                <th className="px-4 py-2">Prior target %</th>
                <th className="px-4 py-2">Latest target %</th>
                <th className="px-4 py-2">Drift (pp)</th>
                <th className="px-4 py-2">Flagged</th>
              </tr>
            </thead>
            <tbody>
              {data.segments?.map((row) => (
                <tr
                  key={row.segment}
                  className={`border-t border-slate-100 ${row.flagged ? 'bg-amber-50' : ''}`}
                >
                  <td className="px-4 py-2 font-medium">{row.segment}</td>
                  <td className="px-4 py-2">{row.current_pct.toFixed(1)}</td>
                  <td className="px-4 py-2">{row.target_pct.toFixed(1)}</td>
                  <td className="px-4 py-2">{row.drift_pp > 0 ? '+' : ''}{row.drift_pp.toFixed(1)}</td>
                  <td className="px-4 py-2">{row.flagged ? 'Yes' : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {data.flagged_segments?.length > 0 && (
        <div className="mt-4 space-y-2">
          <h3 className="font-medium text-sm">Suggestions</h3>
          {data.flagged_segments.map((row) => (
            <p key={row.segment} className="rounded-lg border border-amber-100 bg-amber-50 p-3 text-sm text-amber-900">
              {row.suggestion}
            </p>
          ))}
        </div>
      )}
    </section>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-lg border border-slate-100 p-3">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="font-semibold">{value ?? '—'}</p>
    </div>
  );
}

export default function Insights() {
  const [crash, setCrash] = useState(null);
  const [rebalance, setRebalance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([insightsApi.getCrashSignal(), insightsApi.getRebalanceCheck()])
      .then(([crashRes, rebRes]) => {
        setCrash(crashRes.data);
        setRebalance(rebRes.data);
      })
      .catch((err) => setError(err.response?.data?.detail || 'Failed to load insights'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Portfolio Insights</h1>
        <p className="text-sm text-slate-500">
          Crash/dip phased deployment and rebalancing suggestions — decision support only
        </p>
      </div>

      {error && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle size={16} />
          {error}
        </div>
      )}

      <div className="space-y-6">
        <CrashSection data={crash} loading={loading} />
        <RebalanceSection data={rebalance} loading={loading} />
        <DisclaimerBanner compact />
      </div>
    </Layout>
  );
}
