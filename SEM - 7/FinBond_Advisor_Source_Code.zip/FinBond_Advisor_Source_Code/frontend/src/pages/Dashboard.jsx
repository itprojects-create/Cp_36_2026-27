import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { IndianRupee, Shield, TrendingUp, RefreshCw, GitCompare, Activity, Lightbulb, Landmark, Download } from 'lucide-react';
import Layout from '../components/Layout';
import StatCard from '../components/StatCard';
import InstrumentCard from '../components/InstrumentCard';
import DisclaimerBanner from '../components/DisclaimerBanner';
import AllocationDoughnut from '../charts/AllocationDoughnut';
import GrowthProjection from '../charts/GrowthProjection';
import { recommendApi, userApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { downloadPortfolioReport } from '../utils/downloadReport';

export default function Dashboard() {
  const { user } = useAuth();
  const [recommendation, setRecommendation] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [regenerating, setRegenerating] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError] = useState('');

  const loadData = async () => {
    setError('');
    try {
      const profileRes = await userApi.getProfile();
      setProfile(profileRes.data);
      try {
        const recRes = await recommendApi.getLatest();
        setRecommendation(recRes.data);
      } catch {
        const recRes = await recommendApi.generate();
        setRecommendation(recRes.data);
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDownloadReport = async () => {
    if (!recommendation) return;
    setDownloading(true);
    setError('');
    try {
      await downloadPortfolioReport({ profile, recommendation, user });
    } catch (err) {
      setError(err.message || 'Failed to generate PDF report');
    } finally {
      setDownloading(false);
    }
  };

  const handleRegenerate = async () => {
    setRegenerating(true);
    try {
      const { data } = await recommendApi.generate();
      setRecommendation(data);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to regenerate');
    } finally {
      setRegenerating(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <p className="text-slate-500">Loading your dashboard...</p>
      </Layout>
    );
  }

  if (error && !recommendation) {
    return (
      <Layout>
        <p className="text-red-600">{error}</p>
      </Layout>
    );
  }

  const totalInvestment =
    (profile?.savings || 0) + (profile?.existing_investments || 0);
  const snapshotInvestable = Number(recommendation?.input_snapshot?.investable_amount) || 0;
  const usedAllocationFallback = totalInvestment <= 0 && snapshotInvestable > 0;
  const primaryGoalYear = recommendation?.input_snapshot?.goals?.[0]?.target_year;
  const horizonYears = primaryGoalYear
    ? Math.max(1, primaryGoalYear - new Date().getFullYear())
    : 10;

  const allInstruments = (recommendation?.portfolio || []).flatMap((seg) =>
    seg.instruments.map((inst) => ({ ...inst, segment: seg.segment }))
  );

  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Your Dashboard</h1>
          <p className="text-sm text-slate-500">Rule-based portfolio recommendation (Phase 1)</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            to="/market-pulse"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
          >
            <Activity size={16} />
            Market Pulse
          </Link>
          <Link
            to="/government-schemes"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
          >
            <Landmark size={16} />
            Schemes
          </Link>
          <Link
            to="/insights"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
          >
            <Lightbulb size={16} />
            Insights
          </Link>
          <Link
            to="/compare"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
          >
            <GitCompare size={16} />
            Compare Engines
          </Link>
          <Link
            to="/onboarding"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
          >
            Try another plan
          </Link>
          <button
            onClick={handleRegenerate}
            disabled={regenerating}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50 disabled:opacity-50"
          >
            <RefreshCw size={16} className={regenerating ? 'animate-spin' : ''} />
            Regenerate
          </button>
        </div>      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard
          title="Total Investment"
          value={`₹${totalInvestment.toLocaleString('en-IN')}`}
          subtitle="Savings + existing investments"
          icon={IndianRupee}
        />
        <StatCard
          title="Risk Score"
          value={recommendation?.risk?.score ?? '—'}
          subtitle="From your questionnaire"
          icon={TrendingUp}
        />
        <StatCard
          title="Risk Category"
          value={recommendation?.risk?.category ?? '—'}
          subtitle="LOW / MODERATE / HIGH"
          icon={Shield}
        />
      </div>

      {usedAllocationFallback && (
        <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <p className="font-semibold">Allocation uses a ₹1,00,000 illustration amount</p>
          <p className="mt-1 leading-relaxed">
            Your saved profile shows ₹0 savings and ₹0 existing investments, so the Total Investment
            card is ₹0. The recommendation engine still needs a positive amount to show segment rupee
            figures, so it used ₹{snapshotInvestable.toLocaleString('en-IN')} for this allocation
            only. This is an illustration fallback, not additional money in your account. Update
            savings and existing investments in onboarding, then regenerate, to size the portfolio
            to your figures.
          </p>
        </div>
      )}

      <div className="mb-6 grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold">Portfolio Allocation</h2>
          <AllocationDoughnut portfolio={recommendation?.portfolio} />
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold">Growth Projection (Estimate)</h2>
          <GrowthProjection
            lumpSum={totalInvestment}
            monthlySip={profile?.monthly_sip || 0}
            years={horizonYears}
            annualReturnPct={recommendation?.assumed_annual_return_pct || 10}
          />
        </div>
      </div>

      {recommendation?.explanation && (
        <div className="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 p-5">
          <h2 className="font-semibold text-emerald-900">Why this was recommended</h2>
          <p className="mt-2 leading-relaxed text-emerald-800">{recommendation.explanation}</p>
        </div>
      )}

      <div className="mb-6">
        <h2 className="mb-4 text-lg font-semibold">Recommended Instruments</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {allInstruments.map((inst, idx) => (
            <InstrumentCard
              key={`${inst.name}-${idx}`}
              instrument={inst}
              segment={inst.segment}
            />
          ))}
        </div>
      </div>

      <DisclaimerBanner />
      {recommendation?.disclaimer && (
        <p className="mt-3 text-xs text-slate-500">{recommendation.disclaimer}</p>
      )}
      {error && recommendation && (
        <p className="mt-3 text-sm text-red-600">{error}</p>
      )}

      <div className="mt-8 border-t border-slate-200 pt-6">
        <button
          type="button"
          onClick={handleDownloadReport}
          disabled={downloading || !recommendation}
          className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-600 px-5 py-3 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50 sm:w-auto"
        >
          <Download size={16} />
          {downloading ? 'Preparing PDF...' : 'Download Report'}
        </button>
        <p className="mt-2 text-xs text-slate-500">
          PDF includes client details, allocation, where and how much to invest, pie chart, year-by-year estimated gains, and a note that gains exclude taxation.
        </p>
      </div>
    </Layout>
  );
}
