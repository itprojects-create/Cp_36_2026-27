import { useEffect, useState } from 'react';
import { Activity, AlertTriangle, RefreshCw, TrendingDown, TrendingUp } from 'lucide-react';
import Layout from '../components/Layout';
import DisclaimerBanner from '../components/DisclaimerBanner';
import { marketApi } from '../services/api';

const REGIME_STYLES = {
  BULL: { bg: 'bg-emerald-100', text: 'text-emerald-800', icon: TrendingUp },
  BEAR: { bg: 'bg-red-100', text: 'text-red-800', icon: TrendingDown },
  CRASH: { bg: 'bg-red-200', text: 'text-red-900', icon: AlertTriangle },
  SIDEWAYS: { bg: 'bg-amber-100', text: 'text-amber-800', icon: Activity },
  UNAVAILABLE: { bg: 'bg-slate-100', text: 'text-slate-600', icon: Activity },
};

function PulseCard({ item, suffix = '' }) {
  const unavailable = item.status === 'unavailable';
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-xs text-slate-500">{item.label}</p>
      <p className="mt-1 text-xl font-semibold text-slate-900">
        {unavailable ? '—' : `${Number(item.value).toLocaleString(undefined, { maximumFractionDigits: 2 })}${suffix}`}
      </p>
      <div className="mt-2 flex flex-wrap gap-2 text-xs">
        <span className={`rounded px-2 py-0.5 ${unavailable ? 'bg-slate-100 text-slate-500' : 'bg-slate-100 text-slate-600'}`}>
          {item.status}
        </span>
        {item.is_stale && (
          <span className="rounded bg-amber-100 px-2 py-0.5 text-amber-800">stale cache</span>
        )}
      </div>
      {item.message && <p className="mt-2 text-xs text-slate-500">{item.message}</p>}
      {item.last_updated && (
        <p className="mt-1 text-xs text-slate-400">
          Updated {new Date(item.last_updated).toLocaleString()}
        </p>
      )}
    </div>
  );
}

export default function MarketPulse() {
  const [pulse, setPulse] = useState(null);
  const [regime, setRegime] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadData = async () => {
    setError('');
    setLoading(true);
    try {
      const [pulseRes, regimeRes] = await Promise.all([
        marketApi.getPulse(),
        marketApi.getRegime(),
      ]);
      setPulse(pulseRes.data);
      setRegime(regimeRes.data);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load market data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const regimeStyle = REGIME_STYLES[regime?.regime] || REGIME_STYLES.UNAVAILABLE;
  const RegimeIcon = regimeStyle.icon;

  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Market Pulse</h1>
          <p className="text-sm text-slate-500">
            Live market context — display only, not used in allocation engines (Phase 3)
          </p>
        </div>
        <button
          onClick={loadData}
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm hover:bg-slate-50 disabled:opacity-50"
        >
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {error && <p className="mb-4 text-red-600">{error}</p>}

      {regime && (
        <div className={`mb-6 rounded-xl border p-5 ${regimeStyle.bg}`}>
          <div className="flex items-center gap-3">
            <RegimeIcon size={24} className={regimeStyle.text} />
            <div>
              <p className={`text-sm font-medium ${regimeStyle.text}`}>Current Environment</p>
              <p className={`text-2xl font-bold ${regimeStyle.text}`}>{regime.regime}</p>
            </div>
            {regime.is_stale && (
              <span className="ml-auto rounded bg-white/70 px-2 py-1 text-xs text-amber-800">
                Based on stale data
              </span>
            )}
          </div>
          <p className="mt-3 text-sm text-slate-700">{regime.classification_basis}</p>
          <p className="mt-2 text-xs text-slate-500">{regime.disclaimer}</p>
        </div>
      )}

      {loading && !pulse && <p className="text-slate-500">Loading market data...</p>}

      {pulse && (
        <div className="space-y-8">
          <section>
            <h2 className="mb-3 font-semibold">Indices</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {pulse.indices.map((item) => (
                <PulseCard key={item.symbol} item={item} />
              ))}
            </div>
          </section>

          <section>
            <h2 className="mb-3 font-semibold">Volatility & Commodities</h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {pulse.volatility && <PulseCard item={pulse.volatility} />}
              {pulse.commodities.map((item) => (
                <PulseCard key={item.symbol} item={item} suffix=" USD" />
              ))}
              <PulseCard item={pulse.gsec_yield} suffix="%" />
            </div>
          </section>

          <section>
            <h2 className="mb-3 font-semibold">Registry Mutual Fund NAVs (AMFI)</h2>
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-50 text-left text-xs text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Fund</th>
                    <th className="px-4 py-3">AMFI Code</th>
                    <th className="px-4 py-3">NAV</th>
                    <th className="px-4 py-3">NAV Date</th>
                    <th className="px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {pulse.mutual_fund_navs.map((row) => (
                    <tr key={row.amfi_code} className="border-t border-slate-100">
                      <td className="px-4 py-3">{row.instrument_name}</td>
                      <td className="px-4 py-3 font-mono text-xs">{row.amfi_code}</td>
                      <td className="px-4 py-3">
                        {row.status === 'available' ? `₹${Number(row.nav).toFixed(4)}` : '—'}
                      </td>
                      <td className="px-4 py-3">{row.nav_date || '—'}</td>
                      <td className="px-4 py-3">
                        <span className="rounded bg-slate-100 px-2 py-0.5 text-xs">
                          {row.is_stale ? 'stale' : row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
            <p className="font-medium">FII / DII Flows</p>
            <p className="mt-1">{pulse.fii_dii.message}</p>
          </section>

          <DisclaimerBanner text={pulse.disclaimer} />
        </div>
      )}
    </Layout>
  );
}
