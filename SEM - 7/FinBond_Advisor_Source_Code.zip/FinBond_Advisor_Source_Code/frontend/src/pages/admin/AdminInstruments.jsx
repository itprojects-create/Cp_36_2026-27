import { useEffect, useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import Layout from '../../components/Layout';
import { adminApi } from '../../services/api';

const CATEGORIES = ['Debt', 'Large Cap', 'Mid Cap', 'Small Cap', 'Gold', 'ETF'];

const emptyForm = {
  name: '',
  category: 'Large Cap',
  subtype: '',
  ticker: '',
  amfi_code: '',
  cagr_3y: '',
  expense_ratio: '',
  risk_level: 3,
  liquidity: 'T+3',
  minimum_investment: 500,
  is_active: true,
};

export default function AdminInstruments() {
  const [instruments, setInstruments] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data } = await adminApi.getInstruments();
    setInstruments(data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (inst) => {
    setForm({
      name: inst.name,
      category: inst.category,
      subtype: inst.subtype || '',
      ticker: inst.ticker || '',
      amfi_code: inst.amfi_code || '',
      cagr_3y: inst.cagr_3y ?? '',
      expense_ratio: inst.expense_ratio ?? '',
      risk_level: inst.risk_level,
      liquidity: inst.liquidity || '',
      minimum_investment: inst.minimum_investment ?? 500,
      is_active: inst.is_active,
    });
    setEditingId(inst.id);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      cagr_3y: form.cagr_3y === '' ? null : Number(form.cagr_3y),
      expense_ratio: form.expense_ratio === '' ? null : Number(form.expense_ratio),
      risk_level: Number(form.risk_level),
      minimum_investment: Number(form.minimum_investment),
    };
    if (editingId) {
      await adminApi.updateInstrument(editingId, payload);
    } else {
      await adminApi.createInstrument(payload);
    }
    setShowForm(false);
    load();
  };

  const handleDelete = async (id) => {
    if (!confirm('Deactivate this instrument?')) return;
    await adminApi.deleteInstrument(id);
    load();
  };

  const fieldClass =
    'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none';

  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Instrument Registry</h1>
          <p className="text-sm text-slate-500">
            Manually curated demo data — not live market feeds
          </p>
        </div>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-4 py-2 text-sm text-white hover:bg-emerald-700"
        >
          <Plus size={16} /> Add Instrument
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold">{editingId ? 'Edit' : 'New'} Instrument</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <input required placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={fieldClass} />
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={fieldClass}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <input placeholder="Subtype" value={form.subtype} onChange={(e) => setForm({ ...form, subtype: e.target.value })} className={fieldClass} />
            <input placeholder="Ticker" value={form.ticker} onChange={(e) => setForm({ ...form, ticker: e.target.value })} className={fieldClass} />
            <input placeholder="AMFI Code" value={form.amfi_code} onChange={(e) => setForm({ ...form, amfi_code: e.target.value })} className={fieldClass} />
            <input type="number" step="0.01" placeholder="3Y CAGR %" value={form.cagr_3y} onChange={(e) => setForm({ ...form, cagr_3y: e.target.value })} className={fieldClass} />
            <input type="number" step="0.01" placeholder="Expense Ratio %" value={form.expense_ratio} onChange={(e) => setForm({ ...form, expense_ratio: e.target.value })} className={fieldClass} />
            <input type="number" min={1} max={5} placeholder="Risk Level" value={form.risk_level} onChange={(e) => setForm({ ...form, risk_level: e.target.value })} className={fieldClass} />
            <input placeholder="Liquidity" value={form.liquidity} onChange={(e) => setForm({ ...form, liquidity: e.target.value })} className={fieldClass} />
          </div>
          <div className="mt-4 flex gap-2">
            <button type="submit" className="rounded-lg bg-emerald-600 px-4 py-2 text-sm text-white">Save</button>
            <button type="button" onClick={() => setShowForm(false)} className="rounded-lg border px-4 py-2 text-sm">Cancel</button>
          </div>
        </form>
      )}

      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="border-b bg-slate-50 text-slate-600">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">CAGR</th>
                <th className="px-4 py-3">Expense</th>
                <th className="px-4 py-3">Active</th>
                <th className="px-4 py-3">Updated</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {instruments.map((inst) => (
                <tr key={inst.id} className="border-b last:border-0">
                  <td className="px-4 py-3 font-medium">{inst.name}</td>
                  <td className="px-4 py-3">{inst.category}</td>
                  <td className="px-4 py-3">{inst.cagr_3y != null ? `${inst.cagr_3y}%` : '—'}</td>
                  <td className="px-4 py-3">{inst.expense_ratio != null ? `${inst.expense_ratio}%` : '—'}</td>
                  <td className="px-4 py-3">{inst.is_active ? 'Yes' : 'No'}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {new Date(inst.last_updated).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(inst)} className="text-emerald-700 hover:text-emerald-900">
                        <Pencil size={16} />
                      </button>
                      <button onClick={() => handleDelete(inst.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
