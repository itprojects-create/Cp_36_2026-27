import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import { adminApi } from '../../services/api';

export default function AdminMarket() {
  const [status, setStatus] = useState(null);
  const [gsecYield, setGsecYield] = useState('');
  const [currentGsec, setCurrentGsec] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    setError('');
    try {
      const [healthRes, gsecRes] = await Promise.all([
        adminApi.getSystemHealth(),
        adminApi.getGsec(),
      ]);
      setStatus(healthRes.data);
      setCurrentGsec(gsecRes.data);
      if (gsecRes.data.yield_pct != null) {
        setGsecYield(String(gsecRes.data.yield_pct));
      }
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to load market admin data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveGsec = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');
    setError('');
    try {
      const { data } = await adminApi.updateGsec(Number(gsecYield));
      setCurrentGsec(data);
      setMessage('G-Sec yield updated successfully');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to update G-Sec yield');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Layout>
      <h1 className="mb-2 text-2xl font-bold">Market Data Admin</h1>
      <p className="mb-6 text-sm text-slate-500">
        Configure G-Sec yield and monitor live API fetch status
      </p>

      {loading && <p className="text-slate-500">Loading...</p>}
      {error && <p className="mb-4 text-red-600">{error}</p>}
      {message && <p className="mb-4 text-emerald-700">{message}</p>}

      <div className="grid gap-6 lg:grid-cols-2">
        <form
          onSubmit={handleSaveGsec}
          className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
        >
          <h2 className="mb-3 font-semibold">10-Year G-Sec Yield</h2>
          <p className="mb-4 text-xs text-slate-500">
            Admin-entered only — no free reliable G-Sec API for this demo.
          </p>
          {currentGsec?.updated_at && (
            <p className="mb-3 text-xs text-slate-500">
              Last updated: {new Date(currentGsec.updated_at).toLocaleString()}
            </p>
          )}
          <label className="block text-sm font-medium text-slate-700">
            Yield (%)
            <input
              type="number"
              step="0.01"
              min="0"
              max="20"
              required
              value={gsecYield}
              onChange={(e) => setGsecYield(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2"
              placeholder="e.g. 7.15"
            />
          </label>
          <button
            type="submit"
            disabled={saving}
            className="mt-4 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save G-Sec Yield'}
          </button>
        </form>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-3 font-semibold">Live API Status</h2>
          {status?.market_sources?.length ? (
            <ul className="space-y-3 text-sm">
              {status.market_sources.map((src) => (
                <li key={src.source} className="rounded-lg border border-slate-100 p-3">
                  <p className="font-medium capitalize">{src.source}</p>
                  <p className="text-xs text-slate-500">
                    Last success:{' '}
                    {src.last_success_at
                      ? new Date(src.last_success_at).toLocaleString()
                      : 'Never'}
                  </p>
                  <p className="text-xs text-slate-500">
                    Last attempt:{' '}
                    {src.last_attempt_at
                      ? new Date(src.last_attempt_at).toLocaleString()
                      : 'Never'}
                  </p>
                  {src.last_error && (
                    <p className="mt-1 text-xs text-red-600">{src.last_error}</p>
                  )}
                  {src.used_stale_fallback && (
                    <p className="mt-1 text-xs text-amber-700">Serving stale fallback</p>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-500">No fetch attempts logged yet.</p>
          )}
          <p className="mt-4 text-xs text-slate-500">{status?.note}</p>
          {status?.thresholds && (
            <div className="mt-4 rounded-lg border border-slate-100 bg-slate-50 p-3 text-xs text-slate-600">
              <p className="font-medium text-slate-700">Phase 4 thresholds (env-configurable)</p>
              <p>Crash tiers: {status.thresholds.crash_tier_mild_pct}% / {status.thresholds.crash_tier_deep_pct}% / {status.thresholds.crash_tier_major_pct}%</p>
              <p>Rebalance drift: ±{status.thresholds.rebalance_drift_threshold_pp} pp</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
