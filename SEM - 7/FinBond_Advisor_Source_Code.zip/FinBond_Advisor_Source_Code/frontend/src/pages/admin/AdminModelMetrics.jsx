import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import { adminApi } from '../../services/api';

export default function AdminModelMetrics() {
  const [metrics, setMetrics] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminApi
      .getModelMetrics()
      .then(({ data }) => setMetrics(data))
      .catch((err) => setError(err.response?.data?.detail || 'Failed to load model metrics'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Layout>
      <h1 className="mb-2 text-2xl font-bold">ML Model Metrics</h1>
      <p className="mb-6 text-sm text-slate-500">
        Active allocation model metadata (XGBoost, trained on synthetic data)
      </p>

      {loading && <p className="text-slate-500">Loading...</p>}
      {error && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {error}
          <p className="mt-2 text-xs">
            Train a model with: <code className="rounded bg-amber-100 px-1">python ml/train_model.py</code>
          </p>
        </div>
      )}

      {metrics && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <MetricCard label="Version" value={metrics.version} />
            <MetricCard label="Engine" value={metrics.engine} />
            <MetricCard label="Dataset Size" value={metrics.dataset_size?.toLocaleString() ?? 'N/A'} />
            <MetricCard label="Noise Std (pp)" value={metrics.noise_std_used ?? 'N/A'} />
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="mb-3 font-semibold">Evaluation Metrics</h2>
            <div className="grid gap-3 sm:grid-cols-3">
              <MetricCard label="MAE" value={metrics.metrics?.overall_mae ?? 'N/A'} />
              <MetricCard label="RMSE" value={metrics.metrics?.overall_rmse ?? 'N/A'} />
              <MetricCard label="R²" value={metrics.metrics?.overall_r2 ?? 'N/A'} />
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm text-sm">
            <p><span className="font-medium">Training date:</span> {new Date(metrics.training_date).toLocaleString()}</p>
            <p className="mt-1"><span className="font-medium">Model file:</span> {metrics.model_file}</p>
            <p className="mt-1"><span className="font-medium">Status:</span> {metrics.status}</p>
          </div>

          <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600">
            This model was trained on synthetically generated data using the rule-based engine as label source
            with added Gaussian noise. It approximates programmed logic — not independent historical ground truth.
          </div>
        </div>
      )}
    </Layout>
  );
}

function MetricCard({ label, value }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="mt-1 text-lg font-semibold text-slate-900">{value}</p>
    </div>
  );
}
