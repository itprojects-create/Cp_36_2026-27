import { useEffect, useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import Layout from '../../components/Layout';
import { adminApi } from '../../services/api';

const emptyForm = {
  name: '',
  department: '',
  description: '',
  eligibility_min_age: '',
  eligibility_max_age: '',
  eligibility_min_income: '',
  eligibility_max_income: '',
  eligibility_occupation: 'any',
  eligibility_gender: 'any',
  eligibility_category: 'any',
  eligibility_notes: '',
  benefits: '',
  interest_or_return: '',
  lock_in_period: '',
  official_portal_url: '',
  is_active: true,
};

export default function AdminSchemes() {
  const [schemes, setSchemes] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    const { data } = await adminApi.getSchemes();
    setSchemes(data);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (scheme) => {
    setForm({
      name: scheme.name,
      department: scheme.department,
      description: scheme.description,
      eligibility_min_age: scheme.eligibility_min_age ?? '',
      eligibility_max_age: scheme.eligibility_max_age ?? '',
      eligibility_min_income: scheme.eligibility_min_income ?? '',
      eligibility_max_income: scheme.eligibility_max_income ?? '',
      eligibility_occupation: scheme.eligibility_occupation || 'any',
      eligibility_gender: scheme.eligibility_gender || 'any',
      eligibility_category: scheme.eligibility_category || 'any',
      eligibility_notes: scheme.eligibility_notes || '',
      benefits: scheme.benefits,
      interest_or_return: scheme.interest_or_return || '',
      lock_in_period: scheme.lock_in_period || '',
      official_portal_url: scheme.official_portal_url,
      is_active: scheme.is_active,
    });
    setEditingId(scheme.id);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...form,
      eligibility_min_age: form.eligibility_min_age === '' ? null : Number(form.eligibility_min_age),
      eligibility_max_age: form.eligibility_max_age === '' ? null : Number(form.eligibility_max_age),
      eligibility_min_income: form.eligibility_min_income === '' ? null : Number(form.eligibility_min_income),
      eligibility_max_income: form.eligibility_max_income === '' ? null : Number(form.eligibility_max_income),
    };
    if (editingId) {
      await adminApi.updateScheme(editingId, payload);
    } else {
      await adminApi.createScheme(payload);
    }
    setShowForm(false);
    load();
  };

  const handleDelete = async (id) => {
    if (!confirm('Deactivate this scheme?')) return;
    await adminApi.deleteScheme(id);
    load();
  };

  const fieldClass =
    'w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none';

  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Government Schemes Registry</h1>
          <p className="text-sm text-slate-500">Manually curated — not live-fetched from government portals</p>
        </div>
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-4 py-2 text-sm text-white hover:bg-emerald-700"
        >
          <Plus size={16} /> Add Scheme
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 font-semibold">{editingId ? 'Edit' : 'New'} Scheme</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <input required placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={fieldClass} />
            <input required placeholder="Department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className={fieldClass} />
            <textarea required placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={`${fieldClass} sm:col-span-2`} rows={2} />
            <textarea required placeholder="Benefits" value={form.benefits} onChange={(e) => setForm({ ...form, benefits: e.target.value })} className={`${fieldClass} sm:col-span-2`} rows={2} />
            <input type="number" placeholder="Min age" value={form.eligibility_min_age} onChange={(e) => setForm({ ...form, eligibility_min_age: e.target.value })} className={fieldClass} />
            <input type="number" placeholder="Max age" value={form.eligibility_max_age} onChange={(e) => setForm({ ...form, eligibility_max_age: e.target.value })} className={fieldClass} />
            <input placeholder="Occupation (any/salaried/self-employed)" value={form.eligibility_occupation} onChange={(e) => setForm({ ...form, eligibility_occupation: e.target.value })} className={fieldClass} />
            <input placeholder="Gender (any/female)" value={form.eligibility_gender} onChange={(e) => setForm({ ...form, eligibility_gender: e.target.value })} className={fieldClass} />
            <textarea placeholder="Eligibility notes" value={form.eligibility_notes} onChange={(e) => setForm({ ...form, eligibility_notes: e.target.value })} className={`${fieldClass} sm:col-span-2`} rows={2} />
            <input placeholder="Interest / return" value={form.interest_or_return} onChange={(e) => setForm({ ...form, interest_or_return: e.target.value })} className={fieldClass} />
            <input placeholder="Lock-in period" value={form.lock_in_period} onChange={(e) => setForm({ ...form, lock_in_period: e.target.value })} className={fieldClass} />
            <input required placeholder="Official portal URL" value={form.official_portal_url} onChange={(e) => setForm({ ...form, official_portal_url: e.target.value })} className={`${fieldClass} sm:col-span-2`} />
          </div>
          <div className="mt-4 flex gap-2">
            <button type="submit" className="rounded-lg bg-emerald-600 px-4 py-2 text-sm text-white">Save</button>
            <button type="button" onClick={() => setShowForm(false)} className="rounded-lg border px-4 py-2 text-sm">Cancel</button>
          </div>
        </form>
      )}

      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full text-left text-sm">
            <thead className="border-b bg-slate-50 text-slate-600">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Department</th>
                <th className="px-4 py-3">Active</th>
                <th className="px-4 py-3">Updated</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {schemes.map((scheme) => (
                <tr key={scheme.id} className="border-b last:border-0">
                  <td className="px-4 py-3 font-medium">{scheme.name}</td>
                  <td className="px-4 py-3">{scheme.department}</td>
                  <td className="px-4 py-3">{scheme.is_active ? 'Yes' : 'No'}</td>
                  <td className="px-4 py-3 text-xs text-slate-500">
                    {new Date(scheme.last_updated).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(scheme)} className="text-emerald-700 hover:text-emerald-900">
                        <Pencil size={16} />
                      </button>
                      <button onClick={() => handleDelete(scheme.id)} className="text-red-500 hover:text-red-700">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
