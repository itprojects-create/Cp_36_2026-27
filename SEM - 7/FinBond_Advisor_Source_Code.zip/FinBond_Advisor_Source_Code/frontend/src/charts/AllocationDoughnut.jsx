import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

const COLORS = ['#059669', '#0d9488', '#0891b2', '#0284c7', '#ca8a04', '#64748b'];

export default function AllocationDoughnut({ portfolio }) {
  if (!portfolio?.length) {
    return <p className="text-sm text-slate-500">No allocation data</p>;
  }

  const data = {
    labels: portfolio.map((s) => s.segment),
    datasets: [
      {
        data: portfolio.map((s) => s.allocation_pct),
        backgroundColor: COLORS,
        borderWidth: 2,
        borderColor: '#fff',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'bottom' },
      tooltip: {
        callbacks: {
          label: (ctx) => `${ctx.label}: ${ctx.parsed}%`,
        },
      },
    },
  };

  return <Doughnut data={data} options={options} />;
}
