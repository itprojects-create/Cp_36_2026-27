import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, Filler);

/**
 * Basic compound growth projection — illustrative estimate only, not live market data.
 * FV = P*(1+r)^t + SIP * [((1+r/12)^(12*t) - 1) / (r/12)] * (1+r/12)
 */
export function projectGrowth(lumpSum, monthlySip, years, annualReturnPct = 10) {
  const r = annualReturnPct / 100;
  const monthlyRate = r / 12;
  const horizon = Math.max(1, Math.floor(years));
  const labels = [];
  const values = [];

  for (let t = 0; t <= horizon; t += 1) {
    const m = t * 12;
    const lumpGrowth = lumpSum * (1 + r) ** t;
    let sipGrowth = 0;
    if (monthlySip > 0 && monthlyRate > 0) {
      sipGrowth = monthlySip * (((1 + monthlyRate) ** m - 1) / monthlyRate) * (1 + monthlyRate);
    } else if (monthlySip > 0) {
      sipGrowth = monthlySip * m;
    }
    labels.push(`Year ${t}`);
    values.push(Math.round(lumpGrowth + sipGrowth));
  }

  return { labels, values };
}

export default function GrowthProjection({ lumpSum, monthlySip, years, annualReturnPct = 10 }) {
  const { labels, values } = projectGrowth(lumpSum, monthlySip, years, annualReturnPct);

  const data = {
    labels,
    datasets: [
      {
        label: 'Projected Value (₹)',
        data: values,
        borderColor: '#059669',
        backgroundColor: 'rgba(5, 150, 105, 0.1)',
        fill: true,
        tension: 0.3,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx) => `₹${ctx.parsed.y.toLocaleString('en-IN')}`,
        },
      },
    },
    scales: {
      x: {
        ticks: {
          autoSkip: false,
          maxRotation: 0,
          minRotation: 0,
        },
      },
      y: {
        ticks: {
          callback: (v) => `₹${(v / 100000).toFixed(1)}L`,
        },
      },
    },
  };

  return (
    <div>
      <Line data={data} options={options} />
      <p className="mt-2 text-xs text-slate-500">
        Illustrative estimate using {annualReturnPct}% assumed annual return — not guaranteed, not live market data.
      </p>
    </div>
  );
}
