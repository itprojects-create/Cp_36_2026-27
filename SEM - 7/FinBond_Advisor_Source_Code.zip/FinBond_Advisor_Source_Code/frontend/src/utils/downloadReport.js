import {
  Chart,
  ArcElement,
  BarElement,
  BarController,
  DoughnutController,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from 'chart.js';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { DISCLAIMER_TEXT } from '../components/DisclaimerBanner';
import { projectGrowth } from '../charts/GrowthProjection';

Chart.register(
  ArcElement,
  BarElement,
  BarController,
  DoughnutController,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

const PIE_COLORS = ['#059669', '#0d9488', '#0891b2', '#0284c7', '#ca8a04', '#64748b'];

const TAX_NOTE =
  'All estimated gains shown in this report are pre-tax illustrations only. ' +
  'They do not include income tax, capital gains tax (STCG/LTCG), surcharge, cess, TDS, ' +
  'or any other tax, fee, or expense. Actual post-tax returns will differ.';

function inr(value) {
  const n = Number(value) || 0;
  return `Rs. ${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function wrapText(doc, text, x, y, maxWidth, lineHeight = 5) {
  const lines = doc.splitTextToSize(text || '', maxWidth);
  doc.text(lines, x, y);
  return y + lines.length * lineHeight;
}

function renderChartImage(config, width = 720, height = 400) {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    const chart = new Chart(ctx, {
      ...config,
      options: {
        ...config.options,
        animation: false,
        responsive: false,
        maintainAspectRatio: false,
      },
    });

    requestAnimationFrame(() => {
      const dataUrl = canvas.toDataURL('image/png');
      chart.destroy();
      resolve(dataUrl);
    });
  });
}

export async function downloadPortfolioReport({ profile, recommendation, user }) {
  const snapshot = recommendation?.input_snapshot || {};
  const snapshotProfile = snapshot.profile || {};
  const client = {
    email: user?.email || '—',
    age: profile?.age ?? snapshotProfile.age ?? '—',
    occupation: profile?.occupation || snapshotProfile.occupation || '—',
    dependents: profile?.dependents ?? snapshotProfile.dependents ?? 0,
    monthly_income: profile?.monthly_income ?? snapshotProfile.monthly_income ?? 0,
    monthly_expenses: profile?.monthly_expenses ?? snapshotProfile.monthly_expenses ?? 0,
    savings: profile?.savings ?? snapshotProfile.savings ?? 0,
    existing_investments: profile?.existing_investments ?? snapshotProfile.existing_investments ?? 0,
    emergency_fund_months: profile?.emergency_fund_months ?? snapshotProfile.emergency_fund_months ?? 0,
    emi: profile?.emi ?? snapshotProfile.emi ?? 0,
    monthly_sip: profile?.monthly_sip ?? snapshotProfile.monthly_sip ?? 0,
    investment_experience: profile?.investment_experience || snapshotProfile.investment_experience || '—',
  };

  const totalInvestment = (Number(client.savings) || 0) + (Number(client.existing_investments) || 0);
  const investable =
    snapshot.investable_amount ||
    (totalInvestment > 0 ? totalInvestment : 100000);
  const lumpSum = totalInvestment > 0 ? totalInvestment : investable;
  const annualReturnPct = recommendation?.assumed_annual_return_pct || 10;
  const goals = snapshot.goals || [];
  const primaryGoalYear = goals[0]?.target_year;
  const horizonYears = primaryGoalYear
    ? Math.max(1, primaryGoalYear - new Date().getFullYear())
    : 10;

  const portfolio = recommendation?.portfolio || [];
  const instruments = portfolio.flatMap((seg) =>
    (seg.instruments || []).map((inst) => ({ ...inst, segment: seg.segment }))
  );

  const growth = projectGrowth(lumpSum, Number(client.monthly_sip) || 0, horizonYears, annualReturnPct);
  const yearlyRows = growth.labels.map((label, i) => {
    const value = growth.values[i];
    const contributed = lumpSum + (Number(client.monthly_sip) || 0) * 12 * i;
    const gain = Math.max(0, value - contributed);
    return { label, value, contributed, gain };
  });

  const pieImage = await renderChartImage(
    {
      type: 'doughnut',
      data: {
        labels: portfolio.map((s) => s.segment),
        datasets: [
          {
            data: portfolio.map((s) => s.allocation_pct),
            backgroundColor: PIE_COLORS,
            borderColor: '#ffffff',
            borderWidth: 2,
          },
        ],
      },
      options: {
        plugins: {
          legend: { position: 'right', labels: { color: '#0f172a', font: { size: 12 } } },
        },
      },
    },
    720,
    360
  );

  const barImage = await renderChartImage(
    {
      type: 'bar',
      data: {
        labels: yearlyRows.map((r) => r.label),
        datasets: [
          {
            label: 'Estimated portfolio value (pre-tax)',
            data: yearlyRows.map((r) => r.value),
            backgroundColor: '#059669',
          },
        ],
      },
      options: {
        plugins: {
          legend: { display: true, labels: { color: '#0f172a' } },
        },
        scales: {
          y: {
            ticks: {
              color: '#475569',
              callback: (v) => `Rs. ${(v / 100000).toFixed(1)}L`,
            },
          },
          x: { ticks: { color: '#475569' } },
        },
      },
    },
    800,
    380
  );

  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 14;
  let y = 16;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(5, 150, 105);
  doc.text('FinBond Advisor', margin, y);
  y += 7;
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('Personalized Portfolio Recommendation Report', margin, y);
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(`Generated on ${new Date().toLocaleString('en-IN')}  |  Rule-based engine (v1)`, margin, y);
  y += 8;

  doc.setDrawColor(5, 150, 105);
  doc.setLineWidth(0.4);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('1. Client details', margin, y);
  y += 4;

  autoTable(doc, {
    startY: y,
    theme: 'grid',
    head: [['Field', 'Value']],
    body: [
      ['Email', client.email],
      ['Age', String(client.age)],
      ['Occupation', String(client.occupation)],
      ['Dependents', String(client.dependents)],
      ['Investment experience', String(client.investment_experience)],
      ['Monthly income', inr(client.monthly_income)],
      ['Monthly expenses', inr(client.monthly_expenses)],
      ['Current savings', inr(client.savings)],
      ['Existing investments', inr(client.existing_investments)],
      ['Total investable (savings + existing)', inr(totalInvestment)],
      ['Amount used for this allocation', inr(investable)],
      ['Monthly SIP', inr(client.monthly_sip)],
      ['Monthly EMI', inr(client.emi)],
      ['Emergency fund (months)', String(client.emergency_fund_months)],
      ['Risk score', String(recommendation?.risk?.score ?? '—')],
      ['Risk category', String(recommendation?.risk?.category ?? '—')],
    ],
    styles: { fontSize: 8, cellPadding: 1.6 },
    headStyles: { fillColor: [5, 150, 105], textColor: 255 },
    columnStyles: { 0: { cellWidth: 70, fontStyle: 'bold' } },
    margin: { left: margin, right: margin },
  });
  y = doc.lastAutoTable.finalY + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('2. Goals', margin, y);
  y += 4;

  const goalRows =
    goals.length > 0
      ? goals.map((g, i) => [
          String(i + 1),
          String(g.goal_type || '—').replaceAll('_', ' '),
          inr(g.target_amount),
          String(g.target_year || '—'),
          String(g.priority ?? '—'),
        ])
      : [['—', 'No goals stored on this recommendation', '—', '—', '—']];

  autoTable(doc, {
    startY: y,
    theme: 'grid',
    head: [['#', 'Goal', 'Target amount', 'Target year', 'Priority']],
    body: goalRows,
    styles: { fontSize: 8, cellPadding: 1.6 },
    headStyles: { fillColor: [5, 150, 105], textColor: 255 },
    margin: { left: margin, right: margin },
  });
  y = doc.lastAutoTable.finalY + 8;

  if (recommendation?.explanation) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('3. Why this portfolio was recommended', margin, y);
    y += 6;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(51, 65, 85);
    y = wrapText(doc, recommendation.explanation, margin, y, pageWidth - margin * 2, 4.5);
    y += 6;
    doc.setTextColor(15, 23, 42);
  }

  doc.addPage();
  y = 16;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('4. Portfolio allocation', margin, y);
  y += 4;

  autoTable(doc, {
    startY: y,
    theme: 'grid',
    head: [['Segment', 'Allocation %', 'Amount to invest']],
    body: portfolio.map((s) => [s.segment, `${Number(s.allocation_pct).toFixed(1)}%`, inr(s.amount)]),
    styles: { fontSize: 8, cellPadding: 1.8 },
    headStyles: { fillColor: [5, 150, 105], textColor: 255 },
    margin: { left: margin, right: margin },
  });
  y = doc.lastAutoTable.finalY + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Allocation pie chart', margin, y);
  y += 4;
  doc.addImage(pieImage, 'PNG', margin, y, 182, 78);
  y += 86;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('5. Where to invest and how much (instrument script)', margin, y);
  y += 4;

  autoTable(doc, {
    startY: y,
    theme: 'grid',
    head: [['#', 'Instrument', 'Segment', '%', 'Amount', 'Why this fund']],
    body: instruments.map((inst, i) => [
      String(i + 1),
      inst.name,
      inst.segment,
      `${Number(inst.allocation_pct).toFixed(1)}%`,
      inr(inst.amount),
      inst.reason || '—',
    ]),
    styles: { fontSize: 7.5, cellPadding: 1.6, overflow: 'linebreak' },
    headStyles: { fillColor: [5, 150, 105], textColor: 255 },
    columnStyles: {
      0: { cellWidth: 10 },
      1: { cellWidth: 48 },
      2: { cellWidth: 26 },
      3: { cellWidth: 16 },
      4: { cellWidth: 28 },
      5: { cellWidth: 54 },
    },
    margin: { left: margin, right: margin },
  });

  doc.addPage();
  y = 16;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('6. Estimated gains year by year (illustrative, pre-tax)', margin, y);
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  y = wrapText(
    doc,
    `Assumed annual return: ${annualReturnPct}%. Horizon: ${horizonYears} years. ` +
      `Starting amount: ${inr(lumpSum)}. Monthly SIP: ${inr(client.monthly_sip)}. ` +
      'This is an estimate, not a guarantee, and is not live market data.',
    margin,
    y,
    pageWidth - margin * 2,
    4
  );
  y += 4;

  autoTable(doc, {
    startY: y,
    theme: 'grid',
    head: [['Year', 'Estimated value', 'Amount contributed', 'Estimated gain (pre-tax)']],
    body: yearlyRows.map((r) => [r.label, inr(r.value), inr(r.contributed), inr(r.gain)]),
    styles: { fontSize: 8, cellPadding: 1.6 },
    headStyles: { fillColor: [5, 150, 105], textColor: 255 },
    margin: { left: margin, right: margin },
  });
  y = doc.lastAutoTable.finalY + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('Year-by-year estimated value (bar chart)', margin, y);
  y += 4;
  doc.addImage(barImage, 'PNG', margin, y, 182, 78);
  y += 86;

  if (y > 230) {
    doc.addPage();
    y = 16;
  }

  doc.setFillColor(254, 243, 199);
  doc.rect(margin, y, pageWidth - margin * 2, 28, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(146, 64, 14);
  doc.text('Taxation notice', margin + 3, y + 6);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  wrapText(doc, TAX_NOTE, margin + 3, y + 12, pageWidth - margin * 2 - 6, 4);
  y += 34;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text('Important disclaimer', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  wrapText(doc, recommendation?.disclaimer || DISCLAIMER_TEXT, margin, y, pageWidth - margin * 2, 4);

  const filename = `FinBond-Portfolio-Report-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}
