# FinBond Advisor

**FinBond Advisor** is an AI-based financial planning and investment recommendation system for individual investors. Phase 1 delivers auth, onboarding, a rule-based allocation engine, curated instrument registry, dashboard, and admin portal. **Phase 2** adds an ML-based allocation engine (XGBoost). **Phase 3** adds live market data + regime classification. **Phase 4** adds crash/dip and rebalancing suggestions. **Phase 5** adds a government scheme registry with profile-based eligibility screening.

> **Academic demo notice:** Instrument data (CAGR, expense ratios) is manually curated for demonstration. It is **not** live market data. The ML model is trained on **synthetically generated** data — see [ML Model & Dataset](#ml-model--dataset).

## Tech Stack

| Layer | Stack |
|---|---|
| Frontend | React, Vite, Tailwind CSS, React Router, Axios, Chart.js, Lucide |
| Backend | Python 3.11+, FastAPI, SQLAlchemy, Pydantic, JWT |
| Database | SQLite (default) or PostgreSQL |

## Project Structure

```
finbond-advisor/
├── backend/          # FastAPI API + rule-based allocation engine
├── frontend/         # React SPA
└── README.md
```

## Prerequisites

- Python 3.11+
- Node.js 18+
- (Optional) PostgreSQL 14+ for production-style deployment

## Backend Setup

```bash
cd finbond-advisor/backend
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux
```

Start the API:

```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs  
Health check: http://127.0.0.1:8000/health

> **First startup note:** The backend may take up to ~100 seconds on a cold start while yfinance and AMFI market data are fetched during application startup. This is normal — wait for `Application startup complete` before opening the frontend.

## Frontend Setup

```bash
cd finbond-advisor/frontend
npm install
npm run dev
```

App: http://localhost:5173 (proxies `/api` to the backend)

## Database: SQLite vs PostgreSQL

**Default (SQLite)** — zero setup, file created at `backend/finbond.db`:

```env
DATABASE_URL=sqlite:///./finbond.db
```

**PostgreSQL** — change only the connection string in `.env`:

```env
DATABASE_URL=postgresql://postgres:password@localhost:5432/finbond
```

Models use SQLAlchemy generic `JSON` types (not Postgres-only JSONB), so switching databases is a one-line config change.

## Demo Credentials

**Admin (env-seeded, non-production):**

| Field | Value |
|---|---|
| Email | `admin@finbond.demo` |
| Password | `Admin@FinBond2024` |

Configure via `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `backend/.env`.

Regular users register at `/register`. There is **no** public admin registration endpoint.

## User Flow

1. Register → Accept mandatory disclaimer
2. Onboarding: Financial profile → Goals → 10-question risk assessment
3. Rule-based engine generates allocation + explainability text
4. Dashboard: stat cards, allocation doughnut, growth projection (estimate), instrument cards

## API Routes (v1)

| Method | Path | Description |
|---|---|---|
| POST | `/api/v1/auth/register` | Register user |
| POST | `/api/v1/auth/login` | Login, returns JWT |
| GET | `/api/v1/auth/me` | Current user + onboarding status |
| POST | `/api/v1/user/disclaimer` | Accept disclaimer |
| GET/POST | `/api/v1/user/profile` | Profile |
| GET/POST | `/api/v1/user/goals` | Goals |
| GET | `/api/v1/user/risk-questionnaire` | Questionnaire metadata |
| POST | `/api/v1/user/risk-assessment` | Submit questionnaire |
| POST | `/api/v1/recommend` | Generate recommendation |
| GET | `/api/v1/recommend/latest` | Latest recommendation |
| GET | `/api/v1/recommend/{id}` | Recommendation by ID |
| GET | `/api/v1/admin/users` | List users (admin) |
| PATCH | `/api/v1/admin/users/{id}/toggle` | Enable/disable user |
| GET/POST/PUT/DELETE | `/api/v1/admin/instruments[/{id}]` | Instrument CRUD |
| GET | `/api/v1/admin/model/metrics` | Active ML model metadata (admin) |
| PUT | `/api/v1/admin/gsec` | Set 10Y G-Sec yield (admin) |
| GET | `/api/v1/admin/market/status` | Market fetch log status (admin) |

## API Routes (market — authenticated, Phase 3)

All market endpoints require JWT (same as recommendations).

| Method | Path | Description |
|---|---|---|
| GET | `/api/market-pulse` | Indices, VIX, crude, G-Sec, AMFI NAVs |
| GET | `/api/market-regime` | BULL / SIDEWAYS / BEAR / CRASH classification |
| GET | `/api/gsec` | Current admin-entered G-Sec yield |

## API Routes (insights — authenticated, Phase 4)

| Method | Path | Description |
|---|---|---|
| GET | `/api/crash-signal` | Risk-adjusted phased deployment suggestion during corrections |
| POST | `/api/rebalance-check` | Drift between last two recommendation snapshots |

Admin: `GET /api/v1/admin/system-health` (market fetch status + threshold values). Legacy alias: `/api/v1/admin/market/status`.

## API Routes (government schemes — authenticated, Phase 5)

| Method | Path | Description |
|---|---|---|
| GET | `/api/schemes` | List active schemes (no eligibility run) |
| POST | `/api/schemes/check-eligibility` | Eligibility screening for logged-in user |
| GET/POST/PUT/DELETE | `/api/v1/admin/schemes[/{id}]` | Admin scheme CRUD (soft-delete) |

### Government Schemes (Phase 5)

User page: **`/government-schemes`**. Admin CRUD: **`/admin/schemes`**.

**Eligibility logic (screening aid only):**
- Compares profile age, annual income (monthly × 12), and occupation against structured scheme criteria
- Gender/category not collected in onboarding → schemes restricting these → **MAY BE ELIGIBLE**
- Schemes with `eligibility_notes` → **MAY BE ELIGIBLE** (unverifiable conditions remain)
- **PMVVY** seeded with note: closed for new subscriptions since **March 31, 2023** — see SCSS for active alternative

Every result includes: *"Verify eligibility on the official government portal before applying."*

## Help Assistant (rule-based FAQ)

Floating widget on authenticated pages (including admin and during onboarding). **Not an LLM** — deterministic keyword matching against a hard-coded question bank in `backend/app/services/faq_assistant.py`.

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/assistant/ask` | Optional JWT | Answer FAQ; personalized responses use stored recommendation data |

**Categories:** term definitions (CAGR, expense ratio, liquidity, etc.), personalized “why” answers (from stored `explanation` + allocation %), navigation/how-to, and platform safety (reuses existing disclaimer language).

**Future enhancements:** admin-editable question bank; shared glossary constants module if InstrumentCard copy diverges from assistant definitions.

## API Routes (v2 — ML engine)

| Method | Path | Description |
|---|---|---|
| POST | `/api/v2/recommend` | ML-based recommendation (requires trained model) |

Returns `503` if no model is trained. Does **not** silently fall back to the rule engine.

## ML Model & Dataset

There is **no public dataset** mapping user financial profiles to portfolio allocations. For Phase 2, training data is **synthetically generated**:

1. Random realistic user profiles are sampled (age, income, goals, questionnaire answers)
2. Derived features are computed using the **same code path** as live inference
3. The **rule-based engine** produces label allocations (segment %)
4. Controlled Gaussian noise (default ±4 pp per segment) is added and renormalized to 100%
5. XGBoost learns to approximate these noisy rule-based labels

This means the ML model learns to **smooth and generalize the project's own programmed logic**, not independent historical ground truth. Disclose this clearly in reports and viva.

### Regenerate dataset and train model

```bash
cd finbond-advisor/backend
pip install -r requirements.txt

# Generate synthetic CSV (~7500 rows by default)
python ml/generate_dataset.py

# Train XGBoost model (saved to models/)
python ml/train_model.py

# Quick test run on 200 rows
python ml/train_model.py --sample 200
```

Artifacts (gitignored by default):
- `data/synthetic_training_data.csv`
- `models/allocation_model_v1.joblib`
- `models/allocation_model_v1_metadata.json`
- `models/active_model.json`

### Compare rule-based vs ML engines

```bash
cd finbond-advisor/backend
python scripts/compare_engines.py
```

Calls `/api/v1/recommend` and `/api/v2/recommend` for the same profiles and prints segment allocations side by side.

### Comparison UI (Phase 2.5)

Side-by-side rule-based vs ML view at **`/compare`** (linked from the dashboard "Compare Engines" button).

Useful for report/viva screenshots showing both engines on the same profile, with a per-segment percentage-point difference summary.

**Manual verification:**
1. Log in as a user with completed onboarding
2. Ensure ML model is trained (`python ml/train_model.py`)
3. Open http://localhost:5173/compare — both columns should show doughnut charts, segment breakdowns, and explanations
4. Difference summary should list each segment as e.g. `Rule 35.5% → ML 25.1% (-10.4pp)`
5. To test 503 handling: rename/remove `backend/models/active_model.json` and refresh — v1 column should still render, v2 shows training instructions

### Market Pulse (Phase 3)

Live market context at **`/market-pulse`** (linked from dashboard and navbar). Regime badge shows BULL / SIDEWAYS / BEAR / CRASH using rule-based thresholds on Nifty drawdown, India VIX, and crude oil trends.

**Data sources:**
- **yfinance:** Nifty 50 (`^NSEI`), Sensex (`^BSESN`), India VIX (`^INDIAVIX`), Crude WTI (`CL=F`)
- **AMFI:** Daily NAV file matched to registry `amfi_code`
- **G-Sec yield:** Admin-entered at `/admin/market`
- **FII/DII:** Not integrated (no reliable free API — documented in UI)

**Caching:** Fetched on startup + interval refresh. On failure, serves last cache with `is_stale: true`. No cache → explicit `unavailable` status (never zero/null masquerading as real data).

**Important:** Market data and regime classification are **display only** in Phase 3 — allocation engines (v1/v2) are unchanged.

**Env vars** (optional, defaults shown):

```env
YFINANCE_REFRESH_MINUTES=30
AMFI_REFRESH_HOURS=24
MARKET_DATA_STALE_MINUTES=60
MARKET_REFRESH_ENABLED=true
```

Disable background fetches in tests with `MARKET_REFRESH_ENABLED=false`.

### Portfolio Insights (Phase 4)

Combined page at **`/insights`** — crash/dip phased deployment + rebalancing drift.

**Crash engine:** Uses Nifty drawdown from Phase 3 cache (not recomputed). Tiers at 5% / 10% / 15% below 52-week high. Deployment capped at 50% of available cash even for HIGH risk (phased, not all-in). Language: "phased deployment suggestion" — never "buying opportunity."

**Rebalancing simplification:** Without brokerage integration, "current allocation" = target from your **previous** recommendation; "target" = your **latest** recommendation. Requires ≥2 stored recommendations. Suggestions use "adjust future contributions" framing — no forced selling.

**Threshold env vars:**

```env
CRASH_TIER_MILD_PCT=5
CRASH_TIER_DEEP_PCT=10
CRASH_TIER_MAJOR_PCT=15
REBALANCE_DRIFT_THRESHOLD_PP=5
```

## Running Tests

```bash
cd finbond-advisor/backend
pytest tests -v
```

## Demo Profile Comparison Script

Compare multiple test profiles against the live API without using the UI:

```bash
cd finbond-advisor/backend
python scripts/demo_profiles.py
```

Requires the backend running at `http://127.0.0.1:8000` (override with `BASE_URL` env var). Prints a side-by-side allocation table and full explainability text per profile.

Covers: auth, risk scoring, derived features, allocation engine (normalization, horizon, risk categories).

## Allocation Engines

| Engine | Endpoint | Module |
|---|---|---|
| Rule-based (default) | `POST /api/v1/recommend` | `backend/app/recommendation/allocation_engine.py` |
| ML (XGBoost) | `POST /api/v2/recommend` | `backend/ml/predict.py` + shared pipeline |

Both engines share instrument ranking, explanation generation, and response shape via `recommendation_builder.py`. Only segment allocation differs.

## Instrument Seed Data

19 real Indian mutual funds/ETFs are seeded on first startup (Mirae Large Cap, HDFC Mid-Cap, Nippon Gold ETF, SBI Gilt, etc.). Values are approximate and manually curated — see comments in `backend/app/seed/instruments.py`.

## Known Limitations

This section consolidates intentional boundaries across all phases. The system is designed as an **academic decision-support demo**, not a production financial platform.

### Data & curation (Phases 1, 3, 5)

- **Instrument registry** (CAGR, expense ratios) is manually curated with fixed `last_updated` dates — not live-fetched. Live AMFI NAVs appear separately on Market Pulse where available.
- **Government schemes** are manually curated and admin-managed — not scraped from government portals. Rates, issuance windows, and enrollment status can change; verify on official portals before acting.
- **PMVVY** is seeded with an explicit note: closed for new subscriptions since **March 31, 2023**; SCSS is documented as the active senior-citizen alternative.
- **G-Sec yield** is admin-entered only — no free reliable API in demo scope.
- **FII/DII flows** are not integrated (no reliable free source documented in UI).

### Market data (Phase 3)

- **yfinance** is an unofficial Yahoo Finance wrapper — may break or delay without notice.
- Market fetch blocks cold startup (~35–100s) while initial data is retrieved.
- On fetch failure, stale cache is served with explicit `is_stale` / `unavailable` flags — never fake zeros.
- Regime classification uses simplified thresholds — **not validated trading signals**; non-predictive language only.
- Market data and regime are **display only** — allocation engines (v1/v2) do not consume them.

### ML engine (Phase 2)

- **No public ground-truth dataset** exists for profile → allocation mapping. Training data is **synthetically generated** from the rule engine + Gaussian noise per segment, then negative values are clamped to zero and allocations renormalized to 100%.
- **Asymmetric noise near zero labels:** For conservative profiles, rule-engine segments like Small Cap are often 0%. Gaussian noise can only push those labels *up* after clamping (never below zero). Across thousands of synthetic LOW-risk samples, this creates a systematic upward bias in mid/small-cap training columns — XGBoost learns that biased average, not symmetric noise around the rule label.
- **ML/rule divergence is largest at the conservative end** of the risk spectrum for this reason. Example: a LOW-risk profile may show ~20pp less debt under ML than v1, with offsetting equity increases in segments the rule engine assigned near 0%. A four-profile conservative sweep (`scripts/compare_conservative_sweep.py`) shows debt gaps of **14–24pp** (consistent, not a single outlier). **v1 remains the default recommendation engine**; v2 is comparison/demo only — by design, not oversight.
- The ML model approximates programmed logic — it does not learn from independent historical allocations.
- No automated retraining pipeline — retrain manually via `train_model.py`.

### Portfolio features (Phase 4)

- **Rebalancing** compares stored recommendation snapshots (previous vs latest target) — not real brokerage holdings. No holdings integration.
- **Crash/dip suggestions** are phased deployment ideas only — not bottom calls; capped below 100% of available cash.
- Gender/category are not collected in onboarding — schemes requiring them default to **MAY BE ELIGIBLE**.

### Scope exclusions (Phase 6 targets)

- Dashboard **Download Report** generates a client PDF (allocation, invest-where amounts, pie chart, year-by-year estimated gains). Gains are labelled **pre-tax** — taxation is not modelled.
- No Alembic migrations yet — schema via SQLAlchemy `create_all` (planned Phase 6).
- No Docker deployment bundle yet (planned Phase 6).
- No trade execution or custody — decision-support only.
- Growth projections use a fixed assumed return (~10%) — estimates, not guarantees.

### Compliance posture

- Platform does **not** claim SEBI registration or guaranteed returns.
- Scheme eligibility is a **screening aid**, not a legal determination.
- Disclaimers shown at onboarding, dashboard, recommendations, market views, and scheme pages.

## Report & Viva Assets

### Screenshot matrix (capture from `http://localhost:5173`)

| Phase | Route / moment | What to show |
|---|---|---|
| 1 | `/disclaimer` | Mandatory disclaimer gate before onboarding |
| 1 | `/onboarding` (risk step) | 10-question risk questionnaire |
| 1 | `/dashboard` | Allocation doughnut + explainability text referencing user numbers |
| 2.5 | `/compare` | Rule vs ML side-by-side + per-segment pp difference summary |
| 3 | `/market-pulse` | Live Nifty/VIX values + regime badge (SIDEWAYS/BULL/etc.) |
| 4 | `/insights` | Active mild correction OR rebalancing drift table (regenerate rec twice) |
| 5 | `/government-schemes` | **PMVVY closed badge** + mix of ELIGIBLE / MAY BE ELIGIBLE / NOT ELIGIBLE |
| Admin | `/admin/schemes` or `/admin/market` | Curated registry / system-health (optional) |

Save screenshots to `docs/screenshots/` for your report appendix.

### Demo script appendix (locked output)

Re-run anytime:

```bash
cd finbond-advisor/backend
python scripts/demo_profiles.py      # 5 profiles, goal-isolation check
python scripts/compare_engines.py    # v1 vs v2 segment diff table
```

**Latest captured output:** [`docs/APPENDIX_DEMO_OUTPUT.txt`](docs/APPENDIX_DEMO_OUTPUT.txt) (2026-08-12)

Key evidence in that file:
- **Risk differentiation:** HIGH young aggressive (4.5% debt) vs LOW older conservative (66.4% debt)
- **Goal isolation:** house_10yr vs wealth_10yr differ by 25.55pp on debt despite identical risk scores
- **ML vs rule:** directionally similar on wealth_10yr (max diff 1.6pp); larger divergence on conservative profile (expected — ML smooths labels)

## Safety & Compliance Notes

- Platform does **not** claim SEBI registration or guaranteed returns
- Disclaimer shown before onboarding and on dashboard/recommendation views
- All instrument cards show source / last updated labels
- Recommendations reference the user's actual profile numbers in explainability text

## License

Academic / final-year project use.
